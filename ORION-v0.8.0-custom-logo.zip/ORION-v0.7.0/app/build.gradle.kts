plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.orion.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.orion.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.7.0"
    }
}

kotlin { jvmToolchain(17) }


dependencies {
    implementation("ai.picovoice:porcupine-android:4.0.2")
}
