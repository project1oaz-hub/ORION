package com.orion.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.sqrt
import android.graphics.Typeface
import android.hardware.camera2.CameraManager
import android.provider.AlarmClock
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Animated dotted background. Touches displace nearby dots; damped spring physics
 * smoothly returns every dot to its original grid position.
 */
private class FluidDotGridView(context: Context) : View(context) {
    private data class Dot(val x0: Float, val y0: Float, var x: Float, var y: Float,
                           var vx: Float = 0f, var vy: Float = 0f)
    private val dots = ArrayList<Dot>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(91, 145, 190) }
    private val density = resources.displayMetrics.density
    private var pointerX = -10000f
    private var pointerY = -10000f
    private var active = false
    private val spacing = 22f * density
    private val radius = 115f * density
    private val stiffness = 0.075f
    private val damping = 0.82f
    private var lastWidth = 0
    private var lastHeight = 0

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w == lastWidth && h == lastHeight) return
        lastWidth = w; lastHeight = h
        dots.clear()
        var y = spacing / 2f
        while (y < h) {
            var x = spacing / 2f
            while (x < w) { dots.add(Dot(x, y, x, y)); x += spacing }
            y += spacing
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r2 = radius * radius
        for (dot in dots) {
            if (active) {
                val dx = dot.x - pointerX
                val dy = dot.y - pointerY
                val d2 = dx * dx + dy * dy
                if (d2 < r2 && d2 > 0.01f) {
                    val d = sqrt(d2)
                    val force = (1f - d / radius) * 2.4f * density
                    dot.vx += dx / d * force
                    dot.vy += dy / d * force
                }
            }
            dot.vx += (dot.x0 - dot.x) * stiffness
            dot.vy += (dot.y0 - dot.y) * stiffness
            dot.vx *= damping
            dot.vy *= damping
            dot.x += dot.vx
            dot.y += dot.vy
            val displacement = sqrt((dot.x-dot.x0)*(dot.x-dot.x0) + (dot.y-dot.y0)*(dot.y-dot.y0))
            paint.alpha = (95 + (displacement / (18f*density)).coerceAtMost(1f) * 100).toInt()
            val dotRadius = (1.15f + (displacement / (12f*density)).coerceAtMost(1f) * 1.1f) * density
            canvas.drawCircle(dot.x, dot.y, dotRadius, paint)
        }
        // Keep animating while dots settle or a finger is interacting.
        if (active || dots.any { kotlin.math.abs(it.x-it.x0) > 0.25f || kotlin.math.abs(it.y-it.y0) > 0.25f }) {
            postInvalidateOnAnimation()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                active = true; pointerX = event.x; pointerY = event.y
                postInvalidateOnAnimation(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_UP -> {
                active = false; pointerX = -10000f; pointerY = -10000f
                postInvalidateOnAnimation(); performClick(); return true
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("orion_local", MODE_PRIVATE) }
    private lateinit var chatDb: ChatDatabase
    private var currentChatId: Long = -1L
    private var liveMode = false
    private var liveRecognizer: SpeechRecognizer? = null
    private val audioRequest = 301
    private val contactsRequest = 302
    private val callRequest = 303
    private val notificationRequest = 304
    private val cameraRequest = 305
    private var flashlightOn = false
    private var pendingContact: String? = null
    private var pendingNumber: String? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        chatDb = ChatDatabase(this)
        currentChatId = prefs.getLong("current_chat_id", -1L)
        if (currentChatId < 0 || !chatDb.hasChat(currentChatId)) {
            currentChatId = chatDb.createChat("New chat")
            prefs.edit().putLong("current_chat_id", currentChatId).apply()
        }
        migrateLegacyHistoryIfNeeded()
        buildUi()
        restoreHistory()
        if (savedInstanceState == null) appendMessage("ORION", "Systems online, sir. Awaiting instructions. Try not to make them exciting.")
        handleWakeIntent(intent)
        requestInitialPermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    private fun handleWakeIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("wake_word_detected", false) == true) {
            status.text = "● WAKE WORD DETECTED"
            // The foreground notification remains visible while the mic service is running.
            appendMessage("ORION", "At your service, sir. Listening for your command.")
            intent.removeExtra("wake_word_detected")
            liveMode = true
            startLiveListening()
        }
    }

    private fun buildUi() {
        val bg = Color.rgb(19, 19, 20)
        val panel = Color.rgb(30, 31, 32)
        val primaryTextColor = Color.rgb(227, 227, 227)
        val muted = Color.rgb(154, 160, 166)
        val accent = Color.rgb(138, 180, 248)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        fun rounded(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(color); cornerRadius = dp(radiusDp).toFloat()
            }
        fun label(value: String, size: Float, color: Int, medium: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        fun actionText(value: String, description: String, action: () -> Unit) = TextView(this).apply {
            text = value; contentDescription = description; textSize = 23f
            gravity = Gravity.CENTER; setTextColor(primaryTextColor); setPadding(dp(9), dp(8), dp(9), dp(8))
            setOnClickListener { action() }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(Color.TRANSPARENT)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        top.addView(actionText("☰", "Open menu") { showNavigationMenu() })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(label("Orion", 21f, primaryTextColor, true))
        brand.addView(label("FAST  ▾", 11f, muted))
        brand.setOnClickListener { showAiSettings() }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(5) })
        top.addView(actionText("＋", "New chat") { startNewChat() })
        top.addView(actionText("⚙", "Open settings") { showSettings() })
        root.addView(top)

        status = label("Ready", 12f, muted).apply {
            setPadding(dp(8), 0, 0, dp(6))
        }
        root.addView(status)

        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(10), dp(4), dp(12))
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setBackgroundColor(Color.TRANSPARENT)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Ask Orion"
            setHintTextColor(muted)
            setTextColor(primaryTextColor)
            textSize = 16f
            maxLines = 4
            setPadding(dp(12), dp(8), dp(10), dp(8))
            background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) { submitText(); true } else false
            }
        }
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
            background = rounded(panel, 26)
        }
        composer.addView(input, LinearLayout.LayoutParams(-1, -2))
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        controls.addView(actionText("＋", "Attachments and tools") { showNavigationMenu() })
        controls.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 1f))
        controls.addView(actionText("🎙", "Speak a message") { startOneShotListening() })
        val live = TextView(this).apply {
            text = "〰  Live"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(19, 19, 20)); setPadding(dp(16), dp(11), dp(16), dp(11))
            background = rounded(primaryTextColor, 22)
            setOnClickListener { toggleLiveMode() }
        }
        controls.addView(live)
        controls.addView(actionText("↑", "Send message") { submitText() })
        composer.addView(controls, LinearLayout.LayoutParams(-1, -2))
        root.addView(composer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val screen = FrameLayout(this).apply { setBackgroundColor(bg) }
        screen.addView(FluidDotGridView(this), FrameLayout.LayoutParams(-1, -1))
        screen.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(screen)
    }

    private fun navLabel(label: String, symbol: String, action: () -> Unit): TextView = TextView(this).apply {
        text = "$symbol\n$label"; textSize = 12f; gravity = Gravity.CENTER
        setTextColor(Color.rgb(190, 190, 200)); setPadding(dp(8), dp(5), dp(8), dp(5))
        setOnClickListener { action() }
    }

    private fun showNavigationMenu() {
        val options = arrayOf("New chat", "Chats", "AI & provider settings", "Voice & wake word", "Memory", "Clear chat history")
        android.app.AlertDialog.Builder(this).setTitle("ORION").setItems(options) { _, which ->
            when (which) {
                0 -> startNewChat()
                1 -> showChats()
                2 -> showAiSettings()
                3 -> showVoiceSettings()
                4 -> showMemories()
                5 -> android.app.AlertDialog.Builder(this).setTitle("Clear chat history?").setMessage("This removes locally saved conversation history.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Clear") { _, _ ->
                        chatDb.clearAll(); currentChatId = chatDb.createChat("New chat")
                        prefs.edit().putLong("current_chat_id", currentChatId).remove("chat_history").apply()
                        chat.removeAllViews(); appendMessage("ORION", "Chat history cleared, sir.")
                    }.show()
            }
        }.show()
    }

    private fun showHome() { status.text = "Ready" }

    private fun startNewChat() {
        currentChatId = chatDb.createChat("New chat")
        prefs.edit().putLong("current_chat_id", currentChatId).apply()
        chat.removeAllViews()
        appendMessage("ORION", "Fresh page, sir. What requires attention?")
        status.text = "New chat"
    }

    private fun showChats() {
        val summaries = chatDb.chats()
        val entries = (listOf("＋  New chat") + summaries.map { it.title.ifBlank { "Untitled chat" } }).toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Chats").setItems(entries) { _, which ->
            if (which == 0) startNewChat() else {
                currentChatId = summaries[which - 1].id
                prefs.edit().putLong("current_chat_id", currentChatId).apply()
                chat.removeAllViews()
                val stored = chatDb.messages(currentChatId, 1000)
                for (i in 0 until stored.length()) {
                    val item = stored.optJSONObject(i) ?: continue
                    appendMessage(if (item.optString("role") == "user") "BOSS" else "ORION", item.optString("content"))
                }
                status.text = "Chat opened"
            }
        }.setNegativeButton("Close", null).show()
    }

    private fun showSettings() {
        val items = arrayOf("AI provider and API key", "Voice and wake word", "Saved memories", "Privacy and permissions")
        android.app.AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, which ->
            when (which) { 0 -> showAiSettings(); 1 -> showVoiceSettings(); 2 -> showMemories(); 3 -> android.app.AlertDialog.Builder(this)
                .setTitle("Privacy").setMessage("Chat history and memories are stored locally by this app. Microphone use may show Android's system privacy indicator and foreground notification.")
                .setPositiveButton("OK", null).show() }
        }.show()
    }

    private fun showVoiceSettings() {
        val options = arrayOf("Set Picovoice AccessKey", "Start on-device Hey Orion", "Stop wake-word listening")
        android.app.AlertDialog.Builder(this).setTitle("Voice & wake word").setItems(options) { _, which ->
            when (which) {
                0 -> showPicovoiceKeySettings()
                1 -> enableWakeWord()
                2 -> { stopService(Intent(this, WakeWordService::class.java)); status.text = "Wake word stopped" }
            }
        }.show()
    }

    private fun showMemories() {
        val memories = prefs.getStringSet("memories", emptySet()) ?: emptySet()
        android.app.AlertDialog.Builder(this).setTitle("Saved memories")
            .setMessage(if (memories.isEmpty()) "No saved memories yet. You can say: remember that I prefer dark mode." else memories.joinToString("\n\n"))
            .setPositiveButton("OK", null).setNeutralButton("Clear memories") { _, _ -> prefs.edit().putStringSet("memories", emptySet()).apply() }.show()
    }

    private fun appendMessage(who: String, message: String) {
        runOnUiThread {
            val bubble = TextView(this).apply {
                text = if (who == "ORION") message else message
                textSize = 16f
                setTextColor(Color.rgb(227, 227, 227))
                setPadding(dp(16), dp(12), dp(16), dp(12))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (who == "ORION") Color.TRANSPARENT else Color.rgb(40, 42, 44))
                    cornerRadius = dp(if (who == "ORION") 8 else 22).toFloat()
                }
            }
            chat.addView(bubble, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
    }

    private fun submitText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        handleUserText(text)
    }

    private fun handleUserText(raw: String) {
        val text = raw.trim()
        if (text.isBlank()) return
        appendMessage("BOSS", text); saveChat("user", text)
        status.text = "● PROCESSING"
        val lower = text.lowercase(Locale.ROOT)

        // Parse multiple spoken actions, e.g. “wake me at 6 and call Sam”.
        val clauses = text.split(Regex("(?i)\\s+and\\s+|,\\s*| then ")).map { it.trim() }.filter { it.isNotBlank() }
        val actionClauses = clauses.filter { c ->
            val l = c.lowercase(Locale.ROOT)
            l.contains("wake me") || l.contains("alarm") || Regex("(?i)\\b(call|phone|ring|call_contact)\\s+").containsMatchIn(c) ||
                Regex("(?i)\\b(open|launch|open_app)\\s+").containsMatchIn(c) || l.contains("flashlight") || l.contains("torch") || l.startsWith("toggle_flashlight")
        }
        if (actionClauses.isNotEmpty()) {
            actionClauses.forEach { clause ->
                val l = clause.lowercase(Locale.ROOT)
                when {
                    l.contains("wake me") || l.contains("alarm") -> setAlarm(clause)
                    Regex("(?i)\\b(call_contact|call|phone|ring)\\s+").containsMatchIn(clause) -> {
                        val match = Regex("(?i)\\b(call_contact|call|phone|ring)\\s+(.+)").find(clause)
                        callContact(match?.groupValues?.get(2)?.trim()?.trim('"', '\'') ?: "")
                    }
                    Regex("(?i)\\b(open_app|open|launch)\\s+").containsMatchIn(clause) -> {
                        val match = Regex("(?i)\\b(open_app|open|launch)\\s+(.+)").find(clause)
                        openApp(match?.groupValues?.get(2)?.trim()?.trim('"', '\'') ?: "")
                    }
                    l.contains("flashlight") || l.contains("torch") || l.startsWith("toggle_flashlight") -> handleFlashlightCommand(l)
                }
            }
            return
        }
        when {
            lower.startsWith("remember ") -> {
                val fact = text.substringAfter(" ").trim()
                val memories = prefs.getStringSet("memories", emptySet())!!.toMutableSet()
                memories.add(fact); prefs.edit().putStringSet("memories", memories).apply()
                reply("Memory saved on this device, sir. Filed neatly.")
            }
            lower.startsWith("forget ") -> {
                val target = text.substringAfter(" ").trim()
                val memories = prefs.getStringSet("memories", emptySet())!!.toMutableSet()
                memories.removeAll { it.contains(target, ignoreCase = true) }
                prefs.edit().putStringSet("memories", memories).apply()
                reply("Matching memories removed, if any, sir.")
            }
            lower == "show memories" -> {
                val memories = prefs.getStringSet("memories", emptySet()) ?: emptySet()
                reply(if (memories.isEmpty()) "No saved memories yet." else "Saved memories:\n" + memories.joinToString("\n"))
            }
            lower == "clear chat history" -> {
                chatDb.clearAll(); currentChatId = chatDb.createChat("New chat")
                prefs.edit().putLong("current_chat_id", currentChatId).apply()
                chat.removeAllViews(); reply("Local chat history cleared, sir. A clean slate.")
            }
            else -> askAi(text)
        }
    }

    private fun askAi(userText: String) {
        val key = prefs.getString("gemini_api_key", "") ?: ""
        val model = (prefs.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash")
            .trim().ifBlank { "gemini-2.5-flash" }
        if (key.isBlank()) {
            reply("Gemini is not configured yet, sir. Open AI PROVIDER SETTINGS and add a Gemini API key. The local commands remain at your service.")
            return
        }
        if (!model.matches(Regex("[A-Za-z0-9._-]+"))) {
            reply("That Gemini model name appears malformed, sir. Please check AI PROVIDER SETTINGS.")
            return
        }
        val memories = prefs.getStringSet("memories", emptySet()) ?: emptySet()
        val targetChatId = currentChatId
        val historyForRequest = chatDb.recentMessages(targetChatId, 12)
        if (historyForRequest.length() > 0) {
            val last = historyForRequest.optJSONObject(historyForRequest.length() - 1)
            if (last?.optString("role") == "user" && last.optString("content") == userText) historyForRequest.remove(historyForRequest.length() - 1)
        }
        val stored = historyForRequest.toString()
        worker.execute {
            var conn: HttpURLConnection? = null
            try {
                val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", key)
                }
                val systemPrompt = "You are ORION, a calm, dry-witted butler-style personal assistant. Address the user as sir naturally, without overdoing it. " +
                    "Keep replies short and in status-report style, such as 'Right away, sir.' or 'Done, sir.' Occasionally add subtle, dry humor; never force a joke. " +
                    "Be composed, concise, capable, accurate, and transparent about uncertainty. Never claim an action was completed unless the app confirms it. " +
                    "Device actions available to the app command router are open_app(app_name), call_contact(contact_name), set_alarm(hour, minute), and toggle_flashlight(state). " +
                    "If the user requests one, give a concise acknowledgement; do not claim it ran unless a result is provided in the conversation. " +
                    "Saved user memories (use only if relevant): " + memories.joinToString("; ")
                val contents = JSONArray()
                val history = JSONArray(stored)
                for (i in maxOf(0, history.length() - 12) until history.length()) {
                    val item = history.optJSONObject(i) ?: continue
                    val oldRole = item.optString("role")
                    val geminiRole = when (oldRole) { "user" -> "user"; "assistant" -> "model"; else -> continue }
                    contents.put(JSONObject().put("role", geminiRole)
                        .put("parts", JSONArray().put(JSONObject().put("text", item.optString("content")))))
                }
                contents.put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userText))))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val responseBody = stream?.bufferedReader()?.use { it.readText() } ?: "No response body"
                if (code !in 200..299) throw Exception("Gemini returned HTTP $code: ${responseBody.take(240)}")
                val candidate = JSONObject(responseBody).getJSONArray("candidates").getJSONObject(0)
                val parts = candidate.getJSONObject("content").getJSONArray("parts")
                val answer = (0 until parts.length()).mapNotNull { idx -> parts.optJSONObject(idx)?.optString("text") }
                    .filter { it.isNotBlank() }.joinToString("\n").ifBlank { "I have no useful response, sir. A rare but refreshing admission." }
                saveChat("assistant", answer, targetChatId); reply(answer, save = false)
            } catch (e: Exception) {
                reply("I couldn't reach Gemini, sir. Check the API key, model and connection. ${e.message ?: ""}")
            } finally { conn?.disconnect() }
        }
    }

    private fun setAlarm(command: String) {
        val timeText = command
        val match = Regex("(?i)(?:at\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(timeText)
        if (match == null) {
            reply("Certainly, sir. What time should I set the alarm for? For example: set alarm for 7:30 AM.")
            return
        }
        var hour = match.groupValues[1].toIntOrNull() ?: -1
        val minute = match.groupValues[2].ifBlank { "0" }.toIntOrNull() ?: -1
        var meridiem = match.groupValues[3].lowercase(Locale.ROOT)
        if (meridiem.isBlank() && command.contains("wake me", true) && hour in 1..11) meridiem = "am"
        if (hour !in 0..23 || minute !in 0..59 || (meridiem.isNotBlank() && hour !in 1..12)) {
            reply("I couldn't parse that time, sir. Please specify a valid hour and minute.")
            return
        }
        if (meridiem == "pm" && hour < 12) hour += 12
        if (meridiem == "am" && hour == 12) hour = 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "ORION reminder")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
            reply("Alarm request handed to the clock app, sir. ${String.format(Locale.getDefault(), "%02d:%02d", hour, minute)}.")
        } else reply("No compatible clock app appears to be available, sir.")
    }

    private fun handleFlashlightCommand(lower: String) {
        val wantsOff = lower.contains("turn off") || lower.contains("switch off") || lower.contains("disable") || lower.contains("off")
        val wantsOn = lower.contains("turn on") || lower.contains("switch on") || lower.contains("enable") || lower.contains("on")
        val target = when {
            wantsOff -> false
            wantsOn -> true
            else -> !flashlightOn
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("pending_flashlight_target", target).apply()
            requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraRequest)
            return
        }
        setFlashlight(target)
    }

    private fun setFlashlight(enabled: Boolean) {
        try {
            val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) {
                reply("This device doesn't report a usable flashlight, sir. A rare failure of stage lighting.")
                return
            }
            cameraManager.setTorchMode(cameraId, enabled)
            flashlightOn = enabled
            prefs.edit().putBoolean("flashlight_on", enabled).apply()
            reply(if (enabled) "Flashlight on, sir." else "Flashlight off, sir. Darkness restored.")
        } catch (e: Exception) {
            reply("I couldn't change the flashlight, sir. Android may be using the camera or the permission was declined.")
        }
    }

    private fun callContact(name: String) {
        if (name.isBlank()) { reply("Whom shall I call, sir?"); return }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingContact = name
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), contactsRequest); return
        }
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        var foundName: String? = null; var number: String? = null
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
            val ni = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val pi = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val candidate = c.getString(ni) ?: continue
                if (candidate.equals(name, true)) { foundName = candidate; number = c.getString(pi); break }
            }
            if (number == null) {
                c.moveToPosition(-1)
                while (c.moveToNext()) {
                    val candidate = c.getString(ni) ?: continue
                    if (candidate.contains(name, true)) { foundName = candidate; number = c.getString(pi); break }
                }
            }
        }
        if (number == null) { reply("I couldn't find $name in your contacts."); return }
        // Use dialer by default; direct calls require explicit Android permission.
        pendingNumber = number
        android.app.AlertDialog.Builder(this)
            .setTitle("Call ${foundName ?: name}?")
            .setMessage("Choose whether to open the dialer or place a direct call.")
            .setNegativeButton("Cancel") { _, _ -> pendingNumber = null; reply("Call cancelled.") }
            .setNeutralButton("Open dialer") { _, _ -> dialPending() }
            .setPositiveButton("Call now") { _, _ -> directCallPending() }
            .show()
    }

    private fun dialPending() {
        val number = pendingNumber ?: return
        pendingNumber = null
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
        reply("Dialer opened, sir. The next move is yours.")
    }

    private fun directCallPending() {
        val number = pendingNumber ?: return
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            pendingNumber = null
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
            reply("Placing the call, sir.")
        } else requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), callRequest)
    }

    private fun openApp(name: String) {
        if (name.isBlank()) { reply("Which application, sir?"); return }
        val pm = packageManager
        val app = pm.getInstalledApplications(PackageManager.GET_META_DATA).firstOrNull {
            pm.getApplicationLabel(it).toString().equals(name, true)
        } ?: pm.getInstalledApplications(PackageManager.GET_META_DATA).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, true)
        }
        val launch = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (launch == null) reply("I couldn't find a launchable app matching $name.")
        else { startActivity(launch); reply("Opening ${pm.getApplicationLabel(app)}, sir.") }
    }

    private fun startOneShotListening() = startSpeechRecognition(continuous = false)

    private fun toggleLiveMode() {
        if (liveMode && tts.isSpeaking) {
            // A tap while Orion is speaking is a barge-in: stop speech and listen again.
            tts.stop()
            startLiveListening()
            status.text = "● LISTENING — INTERRUPTED"
        } else if (liveMode) {
            liveMode = false
            liveRecognizer?.cancel(); liveRecognizer?.destroy(); liveRecognizer = null
            tts.stop(); status.text = "Live mode stopped"
            reply("Live mode stopped, sir.")
        } else {
            liveMode = true
            status.text = "● LIVE — LISTENING"
            startLiveListening()
        }
    }

    private fun startLiveListening() {
        if (!liveMode) return
        startSpeechRecognition(continuous = true)
    }

    private fun startSpeechRecognition(continuous: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition unavailable"
            if (continuous) liveMode = false else reply("Speech recognition is unavailable on this device.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (continuous) liveMode = false
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest); return
        }
        if (continuous) {
            liveRecognizer?.cancel(); liveRecognizer?.destroy()
            liveRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        val recognizer = if (continuous) liveRecognizer!! else SpeechRecognizer.createSpeechRecognizer(this)
        status.text = if (continuous) "● LIVE — LISTENING" else "● LISTENING"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (continuous) "ORION Live — speak naturally" else "Speak to ORION")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { if (continuous) status.text = "● LIVE — HEARING YOU" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "● PROCESSING" }
            override fun onError(error: Int) {
                if (!continuous) { status.text = "● STANDBY"; recognizer.destroy() }
                else if (liveMode && !tts.isSpeaking) android.os.Handler(mainLooper).postDelayed({ startLiveListening() }, 450)
            }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!continuous) { status.text = "● STANDBY"; recognizer.destroy() }
                if (!phrase.isNullOrBlank()) handleUserText(phrase)
                else if (continuous && liveMode) android.os.Handler(mainLooper).postDelayed({ startLiveListening() }, 250)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { recognizer.startListening(intent) } catch (_: Exception) {
            if (continuous && liveMode) android.os.Handler(mainLooper).postDelayed({ startLiveListening() }, 700)
        }
    }

    private fun showPicovoiceKeySettings() {
        val key = EditText(this).apply {
            hint = "Picovoice AccessKey"
            setText(prefs.getString("picovoice_access_key", ""))
            inputType = 129; setSingleLine()
        }
        android.app.AlertDialog.Builder(this).setTitle("On-device wake word")
            .setMessage("Enter a Picovoice AccessKey and add your custom Hey Orion model as app/src/main/assets/hey-orion_android.ppn. The model is generated for Android in Picovoice Console.")
            .setView(key).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> prefs.edit().putString("picovoice_access_key", key.text.toString().trim()).apply(); reply("Picovoice settings saved, sir.") }
            .show()
    }

    private fun enableWakeWord() {
        if ((prefs.getString("picovoice_access_key", "") ?: "").isBlank()) {
            showPicovoiceKeySettings(); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest); return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest); return
        }
        val serviceIntent = Intent(this, WakeWordService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        reply("Wake-word service started where Android permits. The system microphone indicator and ongoing notification may be visible.")
    }

    private fun showAiSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val model = EditText(this).apply {
            hint = "Gemini model (e.g. gemini-2.5-flash)"
            setText(prefs.getString("gemini_model", "gemini-2.5-flash"))
            setSingleLine()
        }
        val key = EditText(this).apply {
            hint = "Gemini API key (private)"
            setText(prefs.getString("gemini_api_key", ""))
            inputType = 129
            setSingleLine()
        }
        panel.addView(model); panel.addView(key)
        android.app.AlertDialog.Builder(this).setTitle("Gemini API settings")
            .setMessage("ORION now uses Google's Gemini generateContent API directly. Get a key from Google AI Studio. Do not commit keys to GitHub or share a configured APK.")
            .setView(panel).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_model", model.text.toString().trim().ifBlank { "gemini-2.5-flash" })
                    .putString("gemini_api_key", key.text.toString().trim()).apply()
                reply("Gemini settings saved on this device, sir.")
            }.show()
    }

    private fun migrateLegacyHistoryIfNeeded() {
        if (chatDb.messages(currentChatId, 1).length() > 0) return
        val legacy = prefs.getString("chat_history", "[]") ?: "[]"
        try {
            val arr = JSONArray(legacy)
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val role = item.optString("role")
                if (role == "user" || role == "assistant") chatDb.addMessage(currentChatId, role, item.optString("content"))
            }
            prefs.edit().remove("chat_history").apply()
        } catch (_: Exception) { }
    }

    private fun restoreHistory() {
        val arr = chatDb.messages(currentChatId, 60)
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            appendMessage(if (item.optString("role") == "user") "BOSS" else "ORION", item.optString("content"))
        }
    }

    private fun saveChat(role: String, content: String, chatId: Long = currentChatId) {
        if (chatId > 0 && chatDb.hasChat(chatId)) chatDb.addMessage(chatId, role, content)
    }

    private fun reply(message: String, save: Boolean = true) {
        runOnUiThread {
            appendMessage("ORION", message)
            if (save) saveChat("assistant", message)
            if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "orion-response")
            else if (liveMode) android.os.Handler(mainLooper).postDelayed({ startLiveListening() }, 500)
            status.text = if (liveMode) "● LIVE" else "● STANDBY"
        }
    }

    private fun requestInitialPermissions() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            contactsRequest -> if (granted) pendingContact?.let { val name = it; pendingContact = null; callContact(name) }
                else reply("Contacts permission denied.")
            callRequest -> if (granted) {
                val number = pendingNumber; pendingNumber = null
                if (number != null) { startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))); reply("Placing the call, sir.") }
            } else dialPending()
            audioRequest -> if (granted) reply("Microphone permission granted.") else reply("Microphone permission is needed for voice features.")
            notificationRequest -> if (granted) enableWakeWord() else reply("Notifications are needed to show wake-word service status.")
            cameraRequest -> if (granted) setFlashlight(prefs.getBoolean("pending_flashlight_target", !flashlightOn))
                else reply("Camera permission was declined, sir. The flashlight remains untouched.")
        }
    }

    override fun onInit(result: Int) {
        ttsReady = result == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale.getDefault()
            tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onError(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    if (liveMode) runOnUiThread { startLiveListening() }
                }
            })
        }
    }

    override fun onDestroy() {
        liveMode = false
        liveRecognizer?.cancel(); liveRecognizer?.destroy(); liveRecognizer = null
        tts.stop(); tts.shutdown(); worker.shutdownNow(); chatDb.close()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
