package com.orion.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/** Local SQLite storage for independent conversations and their messages. */
class ChatDatabase(context: Context) : SQLiteOpenHelper(context, "orion_chats.db", null, 1) {
    data class ChatSummary(val id: Long, val title: String, val updatedAt: Long)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE chats (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(chat_id) REFERENCES chats(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX messages_chat_idx ON messages(chat_id, id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    fun createChat(title: String = "New chat"): Long {
        val now = System.currentTimeMillis()
        return writableDatabase.insert("chats", null, ContentValues().apply {
            put("title", title); put("updated_at", now)
        })
    }

    fun hasChat(id: Long): Boolean = readableDatabase.rawQuery("SELECT id FROM chats WHERE id=?", arrayOf(id.toString())).use { it.moveToFirst() }

    fun addMessage(chatId: Long, role: String, content: String) {
        val now = System.currentTimeMillis()
        val db = writableDatabase
        db.insert("messages", null, ContentValues().apply {
            put("chat_id", chatId); put("role", role); put("content", content); put("created_at", now)
        })
        if (role == "user") {
            val currentTitle = readableDatabase.rawQuery("SELECT title FROM chats WHERE id=?", arrayOf(chatId.toString())).use { c -> if (c.moveToFirst()) c.getString(0) else "New chat" }
            if (currentTitle == "New chat") db.update("chats", ContentValues().apply { put("title", content.replace('\n', ' ').take(48)) }, "id=?", arrayOf(chatId.toString()))
        }
        db.update("chats", ContentValues().apply { put("updated_at", now) }, "id=?", arrayOf(chatId.toString()))
    }

    fun messages(chatId: Long, limit: Int = 60): JSONArray {
        val out = JSONArray()
        readableDatabase.rawQuery(
            "SELECT role, content, created_at FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT ?",
            arrayOf(chatId.toString(), limit.toString())
        ).use { c ->
            val rows = ArrayList<JSONObject>()
            while (c.moveToNext()) rows.add(JSONObject().put("role", c.getString(0)).put("content", c.getString(1)).put("time", c.getLong(2)))
            rows.asReversed().forEach { out.put(it) }
        }
        return out
    }

    fun recentMessages(chatId: Long, limit: Int = 12): JSONArray = messages(chatId, limit)

    fun chats(): List<ChatSummary> {
        val out = ArrayList<ChatSummary>()
        readableDatabase.rawQuery("SELECT id, title, updated_at FROM chats ORDER BY updated_at DESC", null).use { c ->
            while (c.moveToNext()) out.add(ChatSummary(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun clearAll() { writableDatabase.delete("messages", null, null); writableDatabase.delete("chats", null, null) }
}
