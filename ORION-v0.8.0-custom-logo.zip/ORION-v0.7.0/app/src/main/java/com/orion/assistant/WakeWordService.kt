package com.orion.assistant

import ai.picovoice.porcupine.PorcupineManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** On-device Porcupine wake-word service. Requires a Picovoice key and custom Android .ppn asset. */
class WakeWordService : Service() {
    private var porcupineManager: PorcupineManager? = null
    private var active = false

    override fun onCreate() { super.onCreate(); createChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification("Waiting for “Hey ORION” on-device")
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(41, notification)
        val key = getSharedPreferences("orion_local", MODE_PRIVATE).getString("picovoice_access_key", "") ?: ""
        if (key.isBlank()) { notifySetupProblem("Add a Picovoice AccessKey in ORION voice settings"); stopSelf(); return START_NOT_STICKY }
        try {
            assets.open(KEYWORD_ASSET).use { }
        } catch (_: Exception) {
            notifySetupProblem("Add $KEYWORD_ASSET to app/src/main/assets")
            stopSelf(); return START_NOT_STICKY
        }
        try {
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeywordPaths(arrayOf(KEYWORD_ASSET))
                .build(this) { _ -> onWakeWordDetected() }
            porcupineManager?.start()
            active = true
            return START_STICKY
        } catch (e: Exception) {
            notifySetupProblem("Porcupine could not start. Check the AccessKey and Android keyword model.")
            stopSelf(); return START_NOT_STICKY
        }
    }

    private fun onWakeWordDetected() {
        if (!active) return
        active = false
        try { porcupineManager?.stop() } catch (_: Exception) { }
        val launch = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("wake_word_detected", true)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(41, buildNotification("Hey ORION detected — tap to give your command", launch))
        try { startActivity(launch) } catch (_: Exception) { /* Notification remains as a safe fallback. */ }
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("orion_mic", "ORION wake word", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Visible status for ORION's on-device wake-word listener"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notifySetupProblem(message: String) {
        getSystemService(NotificationManager::class.java).notify(42, buildNotification(message))
    }

    private fun buildNotification(message: String, intent: Intent? = null): Notification {
        val openIntent = intent ?: Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "orion_mic") else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ORION wake word")
            .setContentText(message)
            .setContentIntent(pending)
            .setOngoing(active)
            .build()
    }

    override fun onDestroy() {
        active = false
        try { porcupineManager?.stop() } catch (_: Exception) { }
        try { porcupineManager?.delete() } catch (_: Exception) { }
        porcupineManager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object { private const val KEYWORD_ASSET = "hey-orion_android.ppn" }
}
