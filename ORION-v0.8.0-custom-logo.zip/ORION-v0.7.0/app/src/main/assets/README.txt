To enable the custom Porcupine wake phrase, export the “Hey ORION” keyword model for Android from Picovoice Console and place the downloaded .ppn file here named:
hey-orion_android.ppn
Do not put your Picovoice AccessKey in this folder or commit it to GitHub. Enter the key inside the app's Voice & wake word settings.
