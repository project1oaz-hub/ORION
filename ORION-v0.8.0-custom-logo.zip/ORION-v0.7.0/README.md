# ORION — Omni-Responsive Intelligent Operation Network
**Version 0.7.0 · Gemini API · natural-language device commands · Live voice · Porcupine wake word · SQLite chats**

## What's included
- Native Kotlin Android app (min SDK 26; Java 17; Android SDK 35).
- Gemini `generateContent` API integration; no OpenAI API key is required.
- Calm, concise, dry-witted butler-style system prompt.
- Natural-language local command routing for app launching, alarms, contact calls, and flashlight control, including combined requests separated by “and”, commas, or “then”.
- Contact calls retain a visible confirmation step. Alarm requests open Android's clock UI. Flashlight control uses Android camera permission.
- Continuous turn-based Live voice: listen → Gemini reply → speak → listen again. Tapping Live while speaking interrupts speech; tapping while listening ends the session.
- Picovoice Porcupine SDK integration for on-device “Hey ORION” detection.
- Separate conversations and messages in a local SQLite database; chat list can reopen prior chats.
- Interactive fluid dot background and native dark chat UI.

## Build with GitHub Actions
1. Download and extract this ZIP.
2. Upload the **contents** of the extracted project folder to the repository root, preserving `.github/workflows/android.yml`.
3. Open **Actions** → **Build ORION APK** and run the workflow.
4. If it succeeds, download the `ORION-debug-apk` artifact and extract `app-debug.apk`.

The workflow uses Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3 and SDK 35. The source ZIP has been integrity-checked, but a complete Android compilation/device test has not been performed in this environment. GitHub Actions is the required build validation.

## Configure Gemini
In ORION → AI/provider settings, enter a Gemini model name (default `gemini-2.5-flash`) and a Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey). The key is stored in app-private preferences in this prototype, not in a secure backend vault. Do not commit it to GitHub or distribute a configured personal APK.

## Configure “Hey ORION” (required for keyword detection)
Porcupine needs a Picovoice AccessKey and a custom Android keyword model; neither can be safely or legitimately bundled as a generic shared secret/model in this source ZIP.
1. Create a Picovoice AccessKey in the Picovoice Console.
2. Create/export the custom phrase **Hey ORION** for **Android**.
3. Add the downloaded file to `app/src/main/assets/hey-orion_android.ppn` (create the `assets` directory if needed).
4. In ORION → Settings → Voice & wake word → Set Picovoice AccessKey, save the key, then choose Start on-device Hey Orion.
5. On detection, ORION opens and starts speech recognition for the command. Android can restrict background activity launches or microphone use; if the app does not open automatically, use the wake-word notification.

The source includes Porcupine Android SDK 4.0.2. The wake-word service will intentionally report a setup message until the key and model file are present.

## Live mode limitations
Live mode provides a continuous conversational loop using Android's speech-recognition service and normal Gemini HTTP requests. It is **not** Gemini's native low-latency duplex Live/WebSocket audio API, so there can be turn delays and speech recognition may depend on the device's speech service/network. The Live button does not claim streaming PCM or full-duplex audio.

## Natural-language command examples
- “Wake me at 6 and call Sam.” — opens the alarm UI for 6:00 AM and then asks for confirmation before calling the matching contact.
- “Set an alarm for 7:30 PM.”
- “Open YouTube.” / “Launch Maps.”
- “Call Mum.”
- “Turn on the flashlight.” / “Switch the torch off.”

For ambiguous “wake me at 6” requests, the parser defaults to 6:00 AM. Check the clock UI before saving. Local command parsing covers common phrasings, not every possible natural-language formulation; unrecognized requests are sent to Gemini.

## Privacy and permissions
Chat messages are stored locally in `orion_chats.db`. The Gemini API receives messages and recent context when configured. Picovoice performs keyword spotting on-device, but requires an AccessKey for initialization. Android controls microphone privacy indicators and background-service behavior. Calls remain confirmation-gated by the app; do not grant permissions unless comfortable with their use.


## ORION app icon (v0.8.0)
The launcher icon now uses the supplied iridescent cosmic planet image. Android density-specific launcher PNGs are in `app/src/main/res/mipmap-*`, and the source artwork is in `drawable-nodpi/orion_logo.png`.
