package com.edith.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.runBlocking
import java.util.Locale

class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var tts: TextToSpeech? = null
    private var current: SpeechRecognizer? = null
    private var listenCb: ((String?) -> Unit)? = null
    private var pendingDone: (() -> Unit)? = null
    private var speakId = 0
    private var track: AudioTrack? = null
    var lastError = 0

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.language = Locale.getDefault()
        }
    }

    companion object {
        fun errorText(c: Int): String = when (c) {
            -1 -> "No speech recognition service found. Install or enable the Google app."
            1 -> "Network timeout. Speech recognition needs internet."
            2 -> "Network error. Check your connection."
            3 -> "Audio problem. Another app may be using the microphone."
            4 -> "Speech server error. Try again."
            5 -> "Speech service error."
            6 -> "I didn't hear anything."
            7 -> "I couldn't understand that."
            8 -> "Speech recogniser is busy. Try again."
            9 -> "Microphone permission is missing. Allow it in app settings."
            else -> "Speech error $c"
        }
    }

    private fun finish() { val d = pendingDone; pendingDone = null; d?.invoke() }

    private fun stopQuiet() {
        speakId++
        tts?.stop()
        track?.let { try { it.stop() } catch (e: Exception) {}; it.release() }
        track = null
    }

    /** Speaks text; [done] fires once when finished OR interrupted. [fast] forces the instant phone voice. */
    fun speak(text: String, fast: Boolean = false, done: () -> Unit = {}) {
        stopQuiet()
        pendingDone = done
        val id = ++speakId
        if (!fast && Prefs.naturalVoice && Prefs.geminiKey.isNotBlank()) {
            val clean = text.replace(Regex("[*_#`]"), "").take(700)
            Thread {
                val pcm = try { runBlocking { Ai.tts(clean) } } catch (e: Exception) { null }
                main.post {
                    if (id == speakId) { if (pcm != null) play(pcm, id, text) else sys(text, id) }
                }
            }.start()
        } else sys(text, id)
    }

    fun stopSpeaking() { stopQuiet(); finish() }\n\n    private fun stopSpeakingForInterrupt() { stopQuiet(); pendingDone = null }
    fun shutdown() { tts?.shutdown() }

    private fun sys(text: String, id: Int) {
        val t = tts
        if (t == null || !ready) { finish(); return }
        val uid = id.toString()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { main.post { if (id == speakId && u == uid) finish() } }
            override fun onStop(u: String?, interrupted: Boolean) { main.post { if (id == speakId && u == uid) finish() } }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { main.post { if (id == speakId && u == uid) finish() } }
        })
        t.setSpeechRate(Prefs.rate)
        t.setPitch(Prefs.pitch)
        t.speak(text.replace(Regex("[*_#`]"), "").take(3500), TextToSpeech.QUEUE_FLUSH, null, uid)
    }

    private fun play(pcm: Pcm, id: Int, text: String) {
        try {
            val frames = pcm.bytes.size / 2
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(pcm.rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.bytes.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm.bytes, 0, pcm.bytes.size)
            t.setNotificationMarkerPosition((frames - 1).coerceAtLeast(1))
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(a: AudioTrack?) {
                    if (id == speakId && track === t) { track = null; try { t.release() } catch (e: Exception) {}; finish() }
                }
                override fun onPeriodicNotification(a: AudioTrack?) {}
            }, main)
            track = t
            t.play()
            // safety net in case the marker never fires
            main.postDelayed({
                if (id == speakId && track === t) { track = null; try { t.stop(); t.release() } catch (e: Exception) {}; finish() }
            }, frames * 1000L / pcm.rate + 1000)
        } catch (e: Exception) {
            sys(text, id)
        }
    }

    fun cancelListen() {
        main.post {
            val cb = listenCb
            listenCb = null
            try { current?.destroy() } catch (e: Exception) {}
            current = null
            if (cb != null) { lastError = 0; cb(null) }
        }
    }

    /** One-shot speech recognition. Callback gets null on failure/silence; see [lastError]. */
    fun listen(onResult: (String?) -> Unit) { main.post { start(0, onResult) } }

    /**
     * Listens for a user barge-in while TTS is playing. Speech onset stops playback
     * immediately; the final recognized phrase is returned to the caller.
     */
    fun listenForInterrupt(onInterrupt: (String?) -> Unit) {
        main.post {
            cancelListenNow()
            val comps = listOf<ComponentName?>(null) + listOfNotNull(Recognizers.find(ctx))
            startInterrupt(0, comps, onInterrupt)
        }
    }

    private fun cancelListenNow() {
        val cb = listenCb
        listenCb = null
        try { current?.cancel(); current?.destroy() } catch (_: Exception) {}
        current = null
        if (cb != null) { lastError = 0; cb(null) }
    }

    private fun startInterrupt(i: Int, comps: List<ComponentName?>, onInterrupt: (String?) -> Unit) {
        if (i >= comps.size) { lastError = -1; onInterrupt(null); return }
        if (comps[i] == null && !SpeechRecognizer.isRecognitionAvailable(ctx)) {
            startInterrupt(i + 1, comps, onInterrupt); return
        }
        val comp = comps[i]
        val r = if (comp != null) SpeechRecognizer.createSpeechRecognizer(ctx, comp)
                else SpeechRecognizer.createSpeechRecognizer(ctx)
        current = r
        var began = false
        r.setRecognitionListener(object : RecognitionListener {
            override fun onBeginningOfSpeech() {
                began = true
                stopSpeakingForInterrupt()
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                r.destroy(); if (current === r) current = null
                listenCb = null
                lastError = if (t.isNullOrBlank()) 7 else 0
                onInterrupt(t)
            }
            override fun onError(e: Int) {
                r.destroy(); if (current === r) current = null
                listenCb = null
                if (!began && e == SpeechRecognizer.ERROR_CLIENT && i + 1 < comps.size)
                    startInterrupt(i + 1, comps, onInterrupt)
                else { lastError = e; onInterrupt(null) }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName))
    }

    private fun start(i: Int, onResult: (String?) -> Unit) {
        val comps = listOf<ComponentName?>(null) + listOfNotNull(Recognizers.find(ctx))
        if (i >= comps.size) { lastError = -1; onResult(null); return }
        if (comps[i] == null && !SpeechRecognizer.isRecognitionAvailable(ctx)) { start(i + 1, onResult); return }
        val comp = comps[i]
        val r = if (comp != null) SpeechRecognizer.createSpeechRecognizer(ctx, comp) else SpeechRecognizer.createSpeechRecognizer(ctx)
        current = r
        listenCb = onResult
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                r.destroy(); if (current === r) current = null
                lastError = if (t.isNullOrBlank()) 7 else 0
                listenCb = null
                onResult(t)
            }
            override fun onError(e: Int) {
                r.destroy(); if (current === r) current = null
                if (e == SpeechRecognizer.ERROR_CLIENT && i + 1 < comps.size) start(i + 1, onResult)
                else { lastError = e; listenCb = null; onResult(null) }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        )
    }
}
