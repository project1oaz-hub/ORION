package com.ivy.app.engine

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Android's built-in speech recognizer (the "standard" STT: no API key, uses the phone's own recognition service). */
class SystemStt(private val ctx: Context) {
    fun available(): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    /** One utterance. Returns null when nothing was heard. Partial text goes to [onPartial]. */
    suspend fun listen(onLevel: (Float) -> Unit, onPartial: (String) -> Unit): String? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<String?> { cont ->
            val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            fun end(block: () -> Unit) { if (cont.isActive) { rec.destroy(); block() } }
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) = end {
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) cont.resume(null)
                    else cont.resumeWithException(IllegalStateException(describe(error)))
                }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    end { cont.resume(t) }
                }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
                }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            cont.invokeOnCancellation {
                Handler(Looper.getMainLooper()).post { try { rec.cancel(); rec.destroy() } catch (_: Exception) {} }
            }
            rec.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }
    }

    private fun describe(e: Int) = when (e) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission needed"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service needs a network connection"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy, try again"
        SpeechRecognizer.ERROR_SERVER -> "Speech service error"
        else -> "Speech recognition error ($e)"
    }
}
