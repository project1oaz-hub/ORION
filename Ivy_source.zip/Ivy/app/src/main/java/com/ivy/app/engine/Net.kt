package com.ivy.app.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class Resp(val code: Int, val body: String)

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).callTimeout(90, TimeUnit.SECONDS).build()

    private fun req(url: String, headers: Map<String, String>) =
        Request.Builder().url(url).header("User-Agent", "Ivy/1.0 (Android)").apply { headers.forEach { header(it.key, it.value) } }

    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): Resp = withContext(Dispatchers.IO) {
        client.newCall(req(url, headers).build()).execute().use { Resp(it.code, it.body?.string() ?: "") }
    }

    suspend fun post(url: String, json: String, headers: Map<String, String> = emptyMap()): Resp = withContext(Dispatchers.IO) {
        val b = json.toRequestBody("application/json".toMediaType())
        client.newCall(req(url, headers).post(b).build()).execute().use { Resp(it.code, it.body?.string() ?: "") }
    }

    suspend fun bytes(url: String, max: Int = 25_000_000): ByteArray = withContext(Dispatchers.IO) {
        require(url.startsWith("http://") || url.startsWith("https://")) { "Only http(s) URLs are supported" }
        client.newCall(req(url, emptyMap()).build()).execute().use {
            require(it.isSuccessful) { "HTTP ${it.code}" }
            val b = it.body!!.bytes(); require(b.size <= max) { "File too large" }; b
        }
    }
}
