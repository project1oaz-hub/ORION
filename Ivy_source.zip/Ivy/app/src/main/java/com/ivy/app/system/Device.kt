package com.ivy.app.system

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import com.ivy.app.domain.ToolResult
import kotlinx.coroutines.delay

object Device {
    fun openApp(ctx: Context, name: String): ToolResult {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val q = name.trim().lowercase()
        val m = apps.firstOrNull { it.first.lowercase() == q } ?: apps.firstOrNull { it.first.lowercase().contains(q) }
            ?: return ToolResult("App not found", listOf("Query" to name))
        val i = pm.getLaunchIntentForPackage(m.second) ?: return ToolResult("Cannot launch", listOf("App" to m.first))
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ToolResult("Opened **${m.first}**", listOf("Package" to m.second))
    }

    private fun needA11y() = ToolResult("Accessibility Service is off", listOf("Fix" to "Enable Ivy under Settings → Accessibility"))

    suspend fun readScreen(): ToolResult {
        val s = IvyAccessibilityService.instance ?: return needA11y()
        delay(1200)
        val t = s.readScreen()
        return ToolResult("Screen text", if (t.isEmpty()) listOf("Result" to "Nothing readable") else t.take(80).map { it to "" })
    }

    fun clickText(t: String): ToolResult {
        val s = IvyAccessibilityService.instance ?: return needA11y()
        return ToolResult("Tap \"$t\"", listOf("Result" to if (s.clickText(t)) "Tapped" else "No clickable element with that text"))
    }

    fun globalAction(a: String): ToolResult {
        val s = IvyAccessibilityService.instance ?: return needA11y()
        val code = when (a.lowercase()) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK; "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS; "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> return ToolResult("Unknown action", listOf("Allowed" to "back, home, recents, notifications"))
        }
        return ToolResult("Pressed **$a**", listOf("Result" to if (s.performGlobalAction(code)) "Done" else "Failed"))
    }

    suspend fun shell(cmd: String, confirm: suspend (String) -> Boolean): ToolResult {
        if (!ShizukuBridge.isActive()) return ToolResult("Shizuku is not active", listOf("Fix" to "Start Shizuku and grant Ivy permission in Settings"))
        if (!confirm("Run this command with elevated (ADB) privileges?\n\n$cmd")) return ToolResult("Shell command", listOf("Result" to "Cancelled by you"))
        return ToolResult("Shell output", ShizukuBridge.exec(cmd).lines().take(60).map { it to "" })
    }
}
