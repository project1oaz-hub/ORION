package com.ivy.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.ClosedCaptionDisabled
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LiveScreen(vm: MainViewModel) {
    val ui by vm.live.collectAsState()
    val label = when {
        ui.muted -> "Muted"
        ui.phase == Phase.Listening -> "Listening..."
        ui.phase == Phase.Thinking -> "Thinking..."
        ui.phase == Phase.Speaking -> "Speaking..."
        else -> "Starting..."
    }
    val energy = when (ui.phase) { Phase.Listening -> ui.level; Phase.Speaking -> 0.45f; Phase.Thinking -> 0.25f; else -> 0f }

    // The dot orb is the visual: it swells with your voice, pulses while thinking / speaking.
    DotGridBackground(Modifier.fillMaxSize(), orbX = 0.5f, orbY = 0.42f, energy = energy,
        active = ui.phase == Phase.Thinking || ui.phase == Phase.Speaking) {
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Text(label, Modifier.align(Alignment.TopCenter).padding(top = 28.dp), color = C.sub, fontSize = 20.sp, fontFamily = FontFamily.Serif)
            Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp, start = 24.dp, end = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (ui.showCaptions && ui.caption.isNotBlank())
                    Text("\"${ui.caption}\"", color = C.text, fontSize = 20.sp, lineHeight = 30.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(48.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundBtn(64, { vm.toggleMute() }) { Icon(if (ui.muted) Icons.Outlined.MicOff else Icons.Filled.Mic, "Mute", tint = C.text) }
                    Box(Modifier.size(88.dp).clip(CircleShape).background(C.accent).clickable { vm.stopLive() }, contentAlignment = Alignment.Center) {
                        Box(Modifier.size(22.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF0B1B3A)))
                    }
                    RoundBtn(64, { vm.toggleCaptions() }) {
                        Icon(if (ui.showCaptions) Icons.Outlined.ClosedCaption else Icons.Outlined.ClosedCaptionDisabled, "Captions", tint = C.text)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(size: Int, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(C.surface).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}
