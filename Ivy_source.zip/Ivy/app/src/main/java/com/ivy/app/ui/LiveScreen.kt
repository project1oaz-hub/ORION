package com.ivy.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.ClosedCaptionDisabled
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LiveScreen(vm: MainViewModel) {
    val ui by vm.live.collectAsState()
    val label = when {
        ui.muted -> "Muted"
        ui.phase == Phase.Listening -> "Listening..."
        ui.phase == Phase.Thinking -> "Thinking..."
        ui.phase == Phase.Speaking -> "Speaking..."
        else -> "Starting..."
    }
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(1f, 1.07f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    val lvl by animateFloatAsState(ui.level, label = "lvl")
    val scale = when (ui.phase) { Phase.Listening -> 1f + lvl * 0.25f; Phase.Thinking -> pulse; Phase.Speaking -> pulse * 1.04f; else -> 1f }
    val inner = when (ui.phase) { Phase.Thinking -> C.accent.copy(alpha = 0.30f); Phase.Speaking -> C.accent.copy(alpha = 0.55f); else -> C.circle }

    Box(Modifier.fillMaxSize().background(C.bg).statusBarsPadding().navigationBarsPadding()) {
        Text(label, Modifier.align(Alignment.TopCenter).padding(top = 24.dp), color = C.sub, fontSize = 18.sp)
        Box(Modifier.align(Alignment.Center).scale(scale), contentAlignment = Alignment.Center) {
            Box(Modifier.size(190.dp).clip(CircleShape).background(C.surface))
            Box(Modifier.size(144.dp).clip(CircleShape).background(inner))
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp, start = 24.dp, end = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (ui.showCaptions && ui.caption.isNotBlank())
                Text("\"${ui.caption}\"", color = C.text, fontSize = 20.sp, lineHeight = 30.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(48.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn(64, { vm.toggleMute() }) { Icon(if (ui.muted) Icons.Outlined.MicOff else Icons.Filled.Mic, "Mute", tint = C.text) }
                Box(Modifier.size(88.dp).clip(CircleShape).background(Color(0xFFE3E3E3)).clickable { vm.stopLive() }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(22.dp).clip(RoundedCornerShape(4.dp)).background(Color.Black))
                }
                RoundBtn(64, { vm.toggleCaptions() }) {
                    Icon(if (ui.showCaptions) Icons.Outlined.ClosedCaption else Icons.Outlined.ClosedCaptionDisabled, "Captions", tint = C.text)
                }
            }
        }
    }
}

@Composable
private fun RoundBtn(size: Int, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(C.surface).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}
