package com.ivy.app.domain

import android.content.Context
import android.net.Uri
import com.ivy.app.data.AppSettings
import com.ivy.app.data.IvyDb
import org.json.JSONArray
import org.json.JSONObject

data class Attachment(val uri: Uri, val name: String, val mime: String)

data class Param(val name: String, val type: String, val desc: String, val required: Boolean = true)

data class ToolSpec(val name: String, val description: String, val params: List<Param> = emptyList()) {
    fun schema(): JSONObject {
        val props = JSONObject(); val req = JSONArray()
        params.forEach {
            props.put(it.name, JSONObject().put("type", it.type).put("description", it.desc))
            if (it.required) req.put(it.name)
        }
        val o = JSONObject().put("type", "object").put("properties", props)
        if (req.length() > 0) o.put("required", req)
        return o
    }
}

/** Structured tool output; rendered as a card in the chat and fed (as plain text) back to the model. */
data class ToolResult(val title: String, val rows: List<Pair<String, String>>, val note: String? = null) {
    fun toJson(): String {
        val r = JSONArray()
        rows.forEach { r.put(JSONArray().put(it.first).put(it.second)) }
        return JSONObject().put("title", title).put("rows", r).put("note", note ?: JSONObject.NULL).toString()
    }

    fun toPlain(max: Int = 6000): String {
        val sb = StringBuilder(title.replace("**", "")).append('\n')
        rows.forEach { sb.append(it.first).append(if (it.second.isBlank()) "" else ": ${it.second}").append('\n') }
        note?.let { sb.append(it) }
        return sb.toString().take(max)
    }

    companion object {
        fun fromJson(s: String): ToolResult {
            val o = JSONObject(s); val a = o.getJSONArray("rows")
            return ToolResult(
                o.getString("title"),
                (0 until a.length()).map { a.getJSONArray(it).let { p -> p.getString(0) to p.getString(1) } },
                if (o.isNull("note")) null else o.getString("note"),
            )
        }
    }
}

sealed class Reply {
    data class Text(val text: String) : Reply()
    data class Call(val name: String, val args: JSONObject, val id: String, val sig: String? = null) : Reply()
}

/** role: user | assistant | call | result */
data class Turn(
    val role: String, val text: String = "",
    val callName: String? = null, val callArgs: JSONObject? = null, val callId: String? = null, val callSig: String? = null,
)

interface Llm { suspend fun chat(system: String, turns: List<Turn>, tools: List<ToolSpec>): Reply }

class ToolContext(
    val app: Context,
    val settings: AppSettings,
    val db: IvyDb,
    val attachment: Attachment?,
    val confirm: suspend (String) -> Boolean,
)

interface Tool {
    val spec: ToolSpec
    val category: String          // recon | device
    fun status(a: JSONObject): String
    fun target(a: JSONObject): String
    suspend fun run(a: JSONObject, c: ToolContext): ToolResult
}
