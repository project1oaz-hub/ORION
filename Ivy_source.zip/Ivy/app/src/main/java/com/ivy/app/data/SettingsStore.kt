package com.ivy.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val gemini: String = "",
    val groq: String = "",
    val xon: String = "",          // XposedOrNot Plus key (optional; free tier needs none)
    val vt: String = "",
    val engine: String = "gemini",
    val stt: String = "system",    // system | groq | gemini
    val geminiModel: String = "",
    val groqModel: String = "",
)

class SettingsStore(ctx: Context, private val vault: KeyVault) {
    private val prefs = ctx.getSharedPreferences("ivy_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun secret(n: String) = prefs.getString(n, null)?.let { vault.decrypt(it) } ?: ""

    private fun load() = AppSettings(
        gemini = secret("gemini"), groq = secret("groq"), xon = secret("xon"), vt = secret("vt"),
        engine = prefs.getString("engine", "gemini") ?: "gemini",
        stt = prefs.getString("stt", "system") ?: "system",
        geminiModel = prefs.getString("gemini_model", "") ?: "",
        groqModel = prefs.getString("groq_model", "") ?: "",
    )

    fun setSecret(name: String, value: String) {
        prefs.edit().apply { if (value.isBlank()) remove(name) else putString(name, vault.encrypt(value)) }.apply()
        _state.value = load()
    }
    fun setEngine(e: String) { prefs.edit().putString("engine", e).apply(); _state.value = load() }
    fun setStt(v: String) { prefs.edit().putString("stt", v).apply(); _state.value = load() }
    fun setModel(provider: String, id: String) { prefs.edit().putString("${provider}_model", id).apply(); _state.value = load() }
}
