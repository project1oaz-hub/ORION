package com.ivy.app.system

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class IvyAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { if (instance === this) instance = null; return super.onUnbind(intent) }

    fun readScreen(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= 200) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) out += t
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root); return out
    }

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) { if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK); cur = cur.parent }
        }
        return false
    }

    companion object { @Volatile var instance: IvyAccessibilityService? = null }
}
