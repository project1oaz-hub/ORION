package com.ivy.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Dot-grid background. A soft "orb" of bigger, bluish dots drifts around (and swells with [energy] / [active]),
 * dots are pushed away from your finger while you touch, and every tap sends a ripple through the grid.
 * Touches are observed but never consumed, so content on top stays fully interactive.
 */
@Composable
fun DotGridBackground(
    modifier: Modifier = Modifier.fillMaxSize(),
    orbX: Float = 0.64f, orbY: Float = 0.45f,
    energy: Float = 0f, active: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    var touching by remember { mutableStateOf(false) }
    var touchPos by remember { mutableStateOf(Offset.Zero) }
    var rippleCenter by remember { mutableStateOf(Offset.Zero) }
    val ripple = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    val inf = rememberInfiniteTransition(label = "dots")
    val drift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing)), label = "drift")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val touchK by animateFloatAsState(if (touching) 1f else 0f, tween(350), label = "touchK")
    val energyS by animateFloatAsState(energy.coerceIn(0f, 1f), label = "energy")

    Box(
        modifier.background(C.bg).pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)
                    val c = e.changes.firstOrNull()
                    if (c != null && c.pressed) {
                        touching = true; touchPos = c.position
                        if (c.changedToDown()) {
                            rippleCenter = c.position
                            scope.launch { ripple.snapTo(0f); ripple.animateTo(1f, tween(1100, easing = LinearOutSlowInEasing)) }
                        }
                    } else touching = false
                }
            }
        },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val sp = 24.dp.toPx(); val off = 11.dp.toPx(); val baseR = 1.6.dp.toPx(); val boost = 2.4.dp.toPx()
            val w = size.width; val h = size.height
            val ang = drift * 2f * PI.toFloat()
            val orb = Offset(w * orbX + sin(ang) * w * 0.09f, h * orbY + sin(ang * 2f + 1f) * h * 0.035f)
            val orbR = 100.dp.toPx() * (1f + energyS * 0.9f + if (active) pulse * 0.2f else 0f)
            val tR = 120.dp.toPx(); val band = 28.dp.toPx()
            val rippleR = ripple.value * 280.dp.toPx(); val rippleA = 1f - ripple.value
            val rc = rippleCenter; val tp = touchPos; val tk = touchK
            val acc = FloatArray(3)
            val dim = Color(0xFF2E3034); val blue = Color(0xFF7F9FD8)

            fun add(x: Float, y: Float, cx: Float, cy: Float, r: Float, k: Float, push: Float) {
                val dx = x - cx; val dy = y - cy; val d = sqrt(dx * dx + dy * dy)
                if (d < r && d > 0.01f) {
                    val u = 1f - d / r; val f = u * u * k
                    acc[0] += dx / d * f * push; acc[1] += dy / d * f * push; acc[2] += f
                }
            }

            val cols = (w / sp).toInt() + 2; val rows = (h / sp).toInt() + 2
            val orbPush = 22.dp.toPx(); val touchPush = 14.dp.toPx(); val ripPush = 10.dp.toPx()
            for (r in 0 until rows) for (c in 0 until cols) {
                val x0 = off + c * sp; val y0 = off + r * sp
                acc[0] = 0f; acc[1] = 0f; acc[2] = 0f
                add(x0, y0, orb.x, orb.y, orbR, 0.85f, orbPush)
                if (tk > 0.01f) add(x0, y0, tp.x, tp.y, tR, tk, touchPush)
                if (rippleA > 0.02f) {
                    val dx = x0 - rc.x; val dy = y0 - rc.y; val d = sqrt(dx * dx + dy * dy)
                    val q = (d - rippleR) / band; val f = exp(-q * q) * rippleA * 0.9f
                    if (f > 0.02f && d > 0.01f) { acc[0] += dx / d * f * ripPush; acc[1] += dy / d * f * ripPush; acc[2] += f }
                }
                val f = acc[2].coerceAtMost(1.3f)
                drawCircle(lerp(dim, blue, (f * 1.3f).coerceIn(0f, 1f)), baseR + f * boost, Offset(x0 + acc[0], y0 + acc[1]))
            }
        }
        content()
    }
}
