package com.ivy.app

import android.app.Application
import androidx.room.Room
import com.ivy.app.data.IvyDb
import com.ivy.app.data.KeyVault
import com.ivy.app.data.SettingsStore
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

class IvyApp : Application() {
    lateinit var vault: KeyVault
    lateinit var settings: SettingsStore

    /** Room database encrypted with SQLCipher; passphrase is wrapped by an Android Keystore key. */
    val db: IvyDb by lazy {
        System.loadLibrary("sqlcipher")
        Room.databaseBuilder(this, IvyDb::class.java, "ivy.db")
            .openHelperFactory(SupportOpenHelperFactory(vault.dbPassphrase()))
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        vault = KeyVault(this)
        settings = SettingsStore(this, vault)
    }

    companion object { lateinit var instance: IvyApp }
}
