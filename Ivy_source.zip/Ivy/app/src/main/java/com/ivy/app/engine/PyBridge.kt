package com.ivy.app.engine

import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.ivy.app.IvyApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Bridge to the embedded Python (Chaquopy) module `ivy_recon`. */
object PyBridge {
    private val module by lazy {
        if (!Python.isStarted()) Python.start(AndroidPlatform(IvyApp.instance))
        Python.getInstance().getModule("ivy_recon")
    }

    suspend fun call(fn: String, vararg args: Any?): String = withContext(Dispatchers.IO) {
        module.callAttr(fn, *args).toString()
    }
}
