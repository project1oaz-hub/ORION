package com.ivy.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val bg = Color(0xFF121214); val surface = Color(0xFF1E1F22); val surface2 = Color(0xFF2A2B2E)
    val circle = Color(0xFF2F3033); val border = Color(0xFF333336); val divider = Color(0xFF2C2D30)
    val text = Color(0xFFE6E6E8); val sub = Color(0xFF9A9AA0); val accent = Color(0xFFA8C7FA); val danger = Color(0xFFF28B82)
}

@Composable
fun IvyTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = C.accent, background = C.bg, surface = C.surface, onSurface = C.text, onBackground = C.text),
    content = content,
)
