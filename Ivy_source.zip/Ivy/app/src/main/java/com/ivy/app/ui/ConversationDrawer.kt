package com.ivy.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ivy.app.data.ConversationEntity

@Composable
fun ConversationDrawer(vm: MainViewModel, onNew: () -> Unit, onSelect: (Long) -> Unit, onSettings: () -> Unit) {
    val convs by vm.conversations.collectAsState()
    val cur by vm.currentId.collectAsState()
    var menuFor by remember { mutableStateOf<Long?>(null) }
    var renameFor by remember { mutableStateOf<ConversationEntity?>(null) }
    var deleteFor by remember { mutableStateOf<ConversationEntity?>(null) }

    ModalDrawerSheet(drawerContainerColor = C.bg, modifier = Modifier.width(320.dp)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            Text("Ivy", color = C.text, fontSize = 30.sp, fontFamily = FontFamily.Serif, modifier = Modifier.padding(start = 12.dp, top = 20.dp, bottom = 16.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(C.surface).clickable(onClick = onNew).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Edit, null, tint = C.accent, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(14.dp)); Text("New chat", color = C.text, fontSize = 17.sp)
            }
            Text("Recents", color = C.sub, fontSize = 13.sp, letterSpacing = 1.sp, modifier = Modifier.padding(start = 12.dp, top = 24.dp, bottom = 8.dp))
            if (convs.isEmpty()) Text("No chats yet", color = C.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 12.dp, top = 4.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(convs, key = { it.id }) { c ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (c.id == cur) C.surface2 else Color.Transparent)
                        .clickable { onSelect(c.id) }.padding(start = 14.dp, top = 2.dp, bottom = 2.dp, end = 2.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(c.title, color = C.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box {
                            Icon(Icons.Filled.MoreVert, "Options", tint = C.sub, modifier = Modifier.clip(CircleShape).clickable { menuFor = c.id }.padding(10.dp).size(20.dp))
                            DropdownMenu(menuFor == c.id, { menuFor = null }, containerColor = C.surface2) {
                                DropdownMenuItem(text = { Text("Rename") }, onClick = { renameFor = c; menuFor = null })
                                DropdownMenuItem(text = { Text("Delete", color = C.danger) }, onClick = { deleteFor = c; menuFor = null })
                            }
                        }
                    }
                }
            }
            HorizontalDivider(color = C.divider)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onSettings).padding(horizontal = 14.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Settings, null, tint = C.sub, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(14.dp)); Text("Settings", color = C.text, fontSize = 17.sp)
            }
        }
    }

    renameFor?.let { c ->
        var t by remember(c.id) { mutableStateOf(c.title) }
        AlertDialog(onDismissRequest = { renameFor = null }, containerColor = C.surface, title = { Text("Rename chat") },
            text = { OutlinedTextField(t, { t = it }, singleLine = true) },
            confirmButton = { TextButton({ vm.rename(c.id, t); renameFor = null }) { Text("Save") } },
            dismissButton = { TextButton({ renameFor = null }) { Text("Cancel") } })
    }
    deleteFor?.let { c ->
        AlertDialog(onDismissRequest = { deleteFor = null }, containerColor = C.surface, title = { Text("Delete chat?") },
            text = { Text("\"${c.title}\" and its messages will be removed from this device. Saved scan results are kept.") },
            confirmButton = { TextButton({ vm.delete(c.id); deleteFor = null }) { Text("Delete", color = C.danger) } },
            dismissButton = { TextButton({ deleteFor = null }) { Text("Cancel") } })
    }
}
