package com.ivy.app.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.exifinterface.media.ExifInterface
import com.ivy.app.domain.ToolContext
import com.ivy.app.domain.ToolResult
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.*

private typealias Rows = MutableList<Pair<String, String>>

private fun JSONArray?.strings(): List<String> = (0 until (this?.length() ?: 0)).map { this!!.optString(it) }
private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
private fun day(iso: String) = iso.substringBefore('T')
private fun fmtDate(d: Date) = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(d)

object Recon {
    fun host(s: String) = s.trim().lowercase().removePrefix("https://").removePrefix("http://")
        .substringBefore('/').substringBefore('?').substringBefore(':')

    private suspend fun resolve(h: String): String = withContext(Dispatchers.IO) { InetAddress.getByName(host(h)).hostAddress ?: h }

    // ---------- Username (Chaquopy) ----------
    suspend fun username(u: String): ToolResult {
        val raw = PyBridge.call("username_scan", u.trim().removePrefix("@"))
        if (raw.trimStart().startsWith("{")) return ToolResult("Username search", listOf("Error" to JSONObject(raw).optString("error")))
        val a = JSONArray(raw)
        val found = mutableListOf<Pair<String, String>>(); val possible = mutableListOf<Pair<String, String>>()
        var nf = 0; var unk = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            when (o.getString("status")) {
                "found" -> found += o.getString("site") to o.getString("url")
                "possible" -> possible += o.getString("site") to o.getString("url")
                "not_found" -> nf++
                else -> unk++
            }
        }
        val rows: Rows = mutableListOf("Checked" to "${a.length()} sites", "Found" to "${found.size}")
        rows += found
        if (possible.isNotEmpty()) { rows += "Possible (site shows a shell page)" to ""; rows += possible }
        rows += "Not found" to "$nf"; if (unk > 0) rows += "Blocked / unknown" to "$unk"
        return ToolResult("Username search for **@${u.removePrefix("@")}**", rows,
            "Matches are not proof of identity: names are reused by different people.")
    }

    // ---------- WHOIS via RDAP ----------
    suspend fun whois(input: String): ToolResult {
        val d = host(input); val r = Net.get("https://rdap.org/domain/${enc(d)}")
        if (r.code == 404) return ToolResult("No record for **$d**", emptyList(), "RDAP has no data: the domain may be unregistered or its TLD unsupported.")
        if (r.code != 200) throw IOException("RDAP returned ${r.code}")
        val j = JSONObject(r.body); var registrar: String? = null; var registrant: String? = null
        val ents = j.optJSONArray("entities")
        for (i in 0 until (ents?.length() ?: 0)) {
            val e = ents!!.getJSONObject(i); val roles = e.optJSONArray("roles").strings(); val fn = vcardFn(e)
            if ("registrar" in roles) registrar = fn; if ("registrant" in roles) registrant = fn
        }
        val rows: Rows = mutableListOf("Registrant" to (registrant?.takeIf { it.isNotBlank() } ?: "Redacted for privacy"))
        registrar?.let { rows += "Registrar" to it }
        val ev = j.optJSONArray("events")
        for (i in 0 until (ev?.length() ?: 0)) {
            val e = ev!!.getJSONObject(i)
            val label = when (e.optString("eventAction")) { "registration" -> "Registered"; "expiration" -> "Expires"; "last changed" -> "Updated"; else -> null }
            if (label != null) rows += label to day(e.optString("eventDate"))
        }
        val ns = j.optJSONArray("nameservers"); val nsl = (0 until (ns?.length() ?: 0)).map { ns!!.getJSONObject(it).optString("ldhName").lowercase() }
        if (nsl.isNotEmpty()) rows += "Name servers" to nsl.joinToString(", ")
        val st = j.optJSONArray("status").strings(); if (st.isNotEmpty()) rows += "Status" to st.joinToString(", ")
        return ToolResult("WHOIS record for **$d**", rows)
    }

    private fun vcardFn(e: JSONObject): String? {
        val arr = e.optJSONArray("vcardArray")?.optJSONArray(1) ?: return null
        for (i in 0 until arr.length()) { val it = arr.optJSONArray(i) ?: continue; if (it.optString(0) == "fn") return it.optString(3) }
        return null
    }

    // ---------- DNS over HTTPS ----------
    suspend fun dns(input: String, typesIn: String): ToolResult {
        val d = host(input)
        val types = typesIn.split(',').map { it.trim().uppercase() }.filter { it.isNotEmpty() }.ifEmpty { listOf("A", "AAAA", "MX", "TXT", "NS", "CNAME") }
        val names = mapOf(1 to "A", 28 to "AAAA", 15 to "MX", 16 to "TXT", 2 to "NS", 5 to "CNAME")
        val rows: Rows = mutableListOf()
        for (t in types) {
            val j = JSONObject(Net.get("https://dns.google/resolve?name=${enc(d)}&type=${enc(t)}").body)
            val a = j.optJSONArray("Answer"); var any = false
            for (i in 0 until (a?.length() ?: 0)) {
                val o = a!!.getJSONObject(i); val n = names[o.optInt("type")] ?: continue
                if (n == t) { rows += t to o.optString("data").removeSurrounding("\""); any = true }
            }
            if (!any) rows += t to "no records"
        }
        return ToolResult("DNS records for **$d**", rows)
    }

    // ---------- Subdomains ----------
    private val WORDS = "www mail ftp dev test staging api admin portal vpn remote blog shop app beta cdn static assets img m mobile ns1 ns2 smtp imap pop webmail git gitlab jenkins ci docs help support status dashboard auth login sso intranet internal db sql grafana monitor old new demo files media cloud".split(" ")

    suspend fun subdomains(input: String, brute: Boolean): ToolResult = coroutineScope {
        val d = host(input); val found = ConcurrentHashMap<String, String>()
        try {
            val r = Net.get("https://crt.sh/?q=%25.${enc(d)}&output=json")
            if (r.code == 200) {
                val a = JSONArray(r.body)
                for (i in 0 until a.length()) a.getJSONObject(i).optString("name_value").split('\n').forEach {
                    val s = it.trim().lowercase().removePrefix("*.")
                    if (s.endsWith(".$d") && s != d) found.putIfAbsent(s, "crt.sh")
                }
            }
        } catch (e: Exception) { found["(crt.sh unavailable)"] = e.message ?: "error" }
        if (brute) {
            val sem = Semaphore(40)
            WORDS.map { w ->
                async(Dispatchers.IO) {
                    sem.withPermit {
                        val s = "$w.$d"
                        try { found[s] = "DNS " + InetAddress.getByName(s).hostAddress } catch (_: UnknownHostException) {}
                    }
                }
            }.awaitAll()
        }
        val sorted = found.entries.sortedBy { it.key }
        ToolResult("Subdomains of **$d**", listOf("Total found" to "${sorted.size}") + sorted.take(150).map { it.key to it.value },
            if (sorted.size > 150) "Showing 150 of ${sorted.size}." else null)
    }

    // ---------- Port scan ----------
    private val COMMON = listOf(21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995, 1433, 1723, 3306, 3389, 5432, 5900, 6379, 8000, 8080, 8443, 27017)
    private val SERVICES = mapOf(21 to "ftp", 22 to "ssh", 23 to "telnet", 25 to "smtp", 53 to "dns", 80 to "http", 110 to "pop3", 143 to "imap", 443 to "https",
        445 to "smb", 993 to "imaps", 995 to "pop3s", 1433 to "mssql", 3306 to "mysql", 3389 to "rdp", 5432 to "postgres", 5900 to "vnc", 6379 to "redis", 8080 to "http-alt", 8443 to "https-alt", 27017 to "mongodb")

    private fun parsePorts(s: String): List<Int> {
        if (s.isBlank()) return COMMON
        val out = sortedSetOf<Int>()
        s.split(',').forEach { part ->
            val t = part.trim()
            if ('-' in t) { val (a, b) = t.split('-').map { it.trim().toInt() }; for (p in a..minOf(b, a + 5000)) if (p in 1..65535) out += p }
            else t.toIntOrNull()?.takeIf { it in 1..65535 }?.let { out += it }
        }
        require(out.isNotEmpty()) { "No valid ports" }
        return out.take(5000)
    }

    suspend fun portScan(input: String, portsIn: String): ToolResult = coroutineScope {
        val h = host(input); val ports = parsePorts(portsIn)
        val addr = withContext(Dispatchers.IO) { InetAddress.getByName(h) }
        val sem = Semaphore(150)
        val res = ports.map { p ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    p to try { Socket().use { it.connect(InetSocketAddress(addr, p), 1500) }; "open" }
                    catch (e: ConnectException) { if (e.message?.contains("refused", true) == true) "closed" else "filtered" }
                    catch (e: Exception) { "filtered" }
                }
            }
        }.awaitAll()
        val open = res.filter { it.second == "open" }
        val rows: Rows = mutableListOf("Target" to "$h (${addr.hostAddress})", "Scanned" to "${ports.size} ports")
        rows += open.map { "${it.first}/tcp" to "open" + (SERVICES[it.first]?.let { s -> " · $s" } ?: "") }
        rows += "Open" to "${open.size}"; rows += "Closed" to "${res.count { it.second == "closed" }}"; rows += "Filtered" to "${res.count { it.second == "filtered" }}"
        ToolResult("Port scan of **$h**", rows, "Only scan systems you own or have permission to test.")
    }

    // ---------- TLS ----------
    suspend fun ssl(input: String, port: Int): ToolResult = withContext(Dispatchers.IO) {
        val h = host(input)
        // Trust-all is intentional: we want to *inspect* any certificate (expired, self-signed), not validate it.
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), SecureRandom()) }
        val s = ctx.socketFactory.createSocket() as SSLSocket
        s.use {
            it.soTimeout = 8000; it.connect(InetSocketAddress(h, port), 8000)
            it.sslParameters = it.sslParameters.apply { serverNames = listOf(SNIHostName(h)) }
            it.startHandshake()
            val chain = it.session.peerCertificates.filterIsInstance<X509Certificate>(); val c = chain.first()
            val sans = c.subjectAlternativeNames?.mapNotNull { n -> n.getOrNull(1)?.toString() } ?: emptyList()
            val left = (c.notAfter.time - System.currentTimeMillis()) / 86_400_000
            ToolResult("TLS certificate for **$h**", listOf(
                "Subject" to c.subjectX500Principal.name, "Issuer" to c.issuerX500Principal.name,
                "Valid from" to fmtDate(c.notBefore), "Valid until" to fmtDate(c.notAfter),
                "Days left" to if (left < 0) "EXPIRED (${-left} days ago)" else "$left",
                "Protocol" to it.session.protocol, "Cipher" to it.session.cipherSuite,
                "Signature" to c.sigAlgName, "Chain length" to "${chain.size}",
                "SANs (${sans.size})" to sans.take(25).joinToString(", ") + if (sans.size > 25) " …" else "",
            ))
        }
    }

    // ---------- IP geo / ASN ----------
    suspend fun ipGeo(target: String): ToolResult {
        val ip = resolve(target); val j = JSONObject(Net.get("https://ipwho.is/${enc(ip)}").body)
        if (!j.optBoolean("success", false)) return ToolResult("IP lookup", listOf("Error" to j.optString("message", "lookup failed")))
        val c = j.optJSONObject("connection")
        return ToolResult("IP info for **$ip**", listOf(
            "Country" to j.optString("country"), "Region" to j.optString("region"), "City" to j.optString("city"),
            "Coordinates" to "${j.optDouble("latitude")}, ${j.optDouble("longitude")}",
            "ISP" to (c?.optString("isp") ?: ""), "Org" to (c?.optString("org") ?: ""),
            "ASN" to "AS${c?.optInt("asn") ?: ""}", "Timezone" to (j.optJSONObject("timezone")?.optString("id") ?: ""),
        ).filter { it.second.isNotBlank() && it.second != "AS" }, "Geolocation is approximate (usually city-level).")
    }

    // ---------- Reverse IP ----------
    suspend fun reverseIp(target: String): ToolResult {
        val ip = resolve(target); val r = Net.get("https://api.hackertarget.com/reverseiplookup/?q=${enc(ip)}")
        val lines = r.body.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.firstOrNull()?.contains("error", true) == true || lines.firstOrNull()?.startsWith("API count", true) == true)
            return ToolResult("Reverse IP for **$ip**", listOf("Result" to lines.first()))
        if (lines.firstOrNull()?.startsWith("No DNS A records", true) == true) return ToolResult("Reverse IP for **$ip**", listOf("Result" to "No other domains found"))
        return ToolResult("Domains on **$ip**", listOf("Total" to "${lines.size}") + lines.take(100).map { it to "" },
            if (lines.size > 100) "Showing 100 of ${lines.size}." else null)
    }

    // ---------- Breach check ----------
    suspend fun breach(email: String, key: String): ToolResult {
        if (key.isBlank()) return ToolResult("Breach check", listOf("Setup needed" to "Add your Have I Been Pwned API key in Settings"))
        val r = Net.get("https://haveibeenpwned.com/api/v3/breachedaccount/${enc(email.trim())}?truncateResponse=false", mapOf("hibp-api-key" to key))
        return when (r.code) {
            404 -> ToolResult("Breach check for **${email.trim()}**", listOf("Result" to "Not found in any known breach"))
            200 -> {
                val a = JSONArray(r.body)
                ToolResult("**${email.trim()}** appears in ${a.length()} breaches", (0 until a.length()).map {
                    val o = a.getJSONObject(it); o.optString("Name") to "${o.optString("BreachDate")} · ${o.optJSONArray("DataClasses").strings().take(4).joinToString(", ")}"
                })
            }
            401 -> ToolResult("Breach check", listOf("Error" to "API key rejected"))
            429 -> ToolResult("Breach check", listOf("Error" to "Rate limited, try again shortly"))
            else -> ToolResult("Breach check", listOf("Error" to "HTTP ${r.code}"))
        }
    }

    // ---------- Phone (Chaquopy + phonenumbers) ----------
    suspend fun phone(number: String, region: String): ToolResult {
        val j = JSONObject(PyBridge.call("phone_info", number, region.ifBlank { null }))
        if (j.has("error")) return ToolResult("Phone lookup", listOf("Error" to j.getString("error")))
        return ToolResult("Phone info for **${j.getString("international")}**", listOf(
            "Valid" to if (j.getBoolean("valid")) "Yes" else "No", "Line type" to j.getString("line_type"),
            "Carrier" to j.getString("carrier").ifBlank { "Unknown (original carrier only)" },
            "Region" to j.getString("region"), "Location" to j.getString("location"), "E.164" to j.getString("e164"),
            "Timezones" to j.getJSONArray("timezones").strings().joinToString(", "),
        ).filter { it.second.isNotBlank() }, "Carrier reflects the original assignment; the number may have been ported.")
    }

    // ---------- Images ----------
    private suspend fun loadBytes(c: ToolContext, url: String): Pair<ByteArray, String> {
        if (url.isNotBlank()) return Net.bytes(url.trim()) to url.trim()
        val att = c.attachment ?: throw IllegalArgumentException("Attach a file with + or give an image URL.")
        val b = withContext(Dispatchers.IO) { c.app.contentResolver.openInputStream(att.uri)!!.use { it.readBytes() } }
        return b to att.name
    }

    suspend fun exif(c: ToolContext, url: String): ToolResult {
        val (bytes, name) = loadBytes(c, url)
        val e = withContext(Dispatchers.IO) { ExifInterface(ByteArrayInputStream(bytes)) }
        val rows: Rows = mutableListOf()
        fun add(l: String, t: String) { e.getAttribute(t)?.takeIf { it.isNotBlank() }?.let { rows += l to it } }
        add("Camera make", ExifInterface.TAG_MAKE); add("Camera model", ExifInterface.TAG_MODEL); add("Lens", ExifInterface.TAG_LENS_MODEL)
        add("Taken", ExifInterface.TAG_DATETIME_ORIGINAL); add("Modified", ExifInterface.TAG_DATETIME); add("Software", ExifInterface.TAG_SOFTWARE)
        add("Width", ExifInterface.TAG_IMAGE_WIDTH); add("Height", ExifInterface.TAG_IMAGE_LENGTH)
        add("Exposure", ExifInterface.TAG_EXPOSURE_TIME); add("Aperture", ExifInterface.TAG_F_NUMBER)
        add("Artist", ExifInterface.TAG_ARTIST); add("Copyright", ExifInterface.TAG_COPYRIGHT)
        e.latLong?.let { rows += "GPS" to "%.6f, %.6f".format(it[0], it[1]); rows += "Map" to "https://www.google.com/maps?q=${it[0]},${it[1]}" }
        return ToolResult("Image metadata: **${name.takeLast(40)}**", if (rows.isEmpty()) listOf("Result" to "No EXIF found") else rows,
            if (rows.isEmpty()) "Most social platforms strip EXIF on upload." else null)
    }

    private fun dHash(bmp: Bitmap): String {
        val s = Bitmap.createScaledBitmap(bmp, 9, 8, true); var h = 0L
        fun g(x: Int, y: Int): Double { val p = s.getPixel(x, y); return 0.299 * (p shr 16 and 255) + 0.587 * (p shr 8 and 255) + 0.114 * (p and 255) }
        for (y in 0 until 8) for (x in 0 until 8) { h = h shl 1; if (g(x, y) > g(x + 1, y)) h = h or 1 }
        return "%016x".format(h)
    }

    suspend fun reverseImage(c: ToolContext, url: String): ToolResult {
        val (bytes, name) = loadBytes(c, url)
        val bmp = withContext(Dispatchers.Default) { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) } ?: throw IOException("Not a decodable image")
        val rows: Rows = mutableListOf("Perceptual hash (dHash)" to dHash(bmp), "Size" to "${bmp.width}×${bmp.height}")
        if (url.isNotBlank()) {
            val u = enc(url.trim())
            rows += "Google Lens" to "https://lens.google.com/uploadbyurl?url=$u"
            rows += "TinEye" to "https://tineye.com/search?url=$u"
            rows += "Yandex" to "https://yandex.com/images/search?rpt=imageview&url=$u"
        } else {
            rows += "Google Lens" to "https://lens.google.com/"; rows += "TinEye" to "https://tineye.com/"; rows += "Yandex" to "https://yandex.com/images/"
        }
        return ToolResult("Reverse image helper", rows,
            if (url.isBlank()) "Local file: open a link and upload the image manually. Compare dHash values; a few differing bits = near-duplicate." else null)
    }

    // ---------- File hash ----------
    suspend fun fileHash(c: ToolContext, vt: Boolean): ToolResult {
        val att = c.attachment ?: throw IllegalArgumentException("Attach a file with + first.")
        val md = listOf("MD5", "SHA-1", "SHA-256").map { MessageDigest.getInstance(it) }; var size = 0L
        withContext(Dispatchers.IO) {
            c.app.contentResolver.openInputStream(att.uri)!!.use { ins ->
                val b = ByteArray(65536); while (true) { val n = ins.read(b); if (n < 0) break; md.forEach { it.update(b, 0, n) }; size += n }
            }
        }
        val hex = md.map { d -> d.digest().joinToString("") { "%02x".format(it) } }
        val rows: Rows = mutableListOf("File" to att.name, "Size" to "$size bytes", "MD5" to hex[0], "SHA1" to hex[1], "SHA256" to hex[2])
        if (vt) {
            if (c.settings.vt.isBlank()) rows += "VirusTotal" to "Add your API key in Settings"
            else {
                val r = Net.get("https://www.virustotal.com/api/v3/files/${hex[2]}", mapOf("x-apikey" to c.settings.vt))
                when (r.code) {
                    200 -> { val a = JSONObject(r.body).getJSONObject("data").getJSONObject("attributes"); val st = a.getJSONObject("last_analysis_stats")
                        rows += "VT malicious" to "${st.optInt("malicious")}"; rows += "VT suspicious" to "${st.optInt("suspicious")}"
                        rows += "VT harmless" to "${st.optInt("harmless")}"; rows += "VT undetected" to "${st.optInt("undetected")}" }
                    404 -> rows += "VirusTotal" to "Hash not known to VirusTotal"
                    else -> rows += "VirusTotal" to "HTTP ${r.code}"
                }
            }
        }
        return ToolResult("File hashes", rows)
    }

    // ---------- Dork builder ----------
    fun dork(a: JSONObject): ToolResult {
        fun g(k: String) = a.optString(k, "").trim()
        val p = mutableListOf<String>()
        if (g("site").isNotEmpty()) p += "site:${host(g("site"))}"
        if (g("filetype").isNotEmpty()) p += "filetype:${g("filetype")}"
        if (g("intitle").isNotEmpty()) p += "intitle:\"${g("intitle")}\""
        if (g("inurl").isNotEmpty()) p += "inurl:${g("inurl")}"
        if (g("intext").isNotEmpty()) p += "intext:\"${g("intext")}\""
        if (g("keywords").isNotEmpty()) p += g("keywords")
        g("exclude").split(' ', ',').filter { it.isNotBlank() }.forEach { p += "-$it" }
        val q = p.joinToString(" ")
        val rows: Rows = mutableListOf("Query" to q.ifBlank { "(add at least one field)" })
        if (q.isNotBlank()) {
            rows += "Google" to "https://www.google.com/search?q=${enc(q)}"
            rows += "Bing" to "https://www.bing.com/search?q=${enc(q)}"
            rows += "DuckDuckGo" to "https://duckduckgo.com/?q=${enc(q)}"
        }
        if (g("site").isNotEmpty()) {
            val s = "site:${host(g("site"))}"
            rows += "Idea: documents" to "$s (filetype:pdf OR filetype:docx OR filetype:xlsx)"
            rows += "Idea: index pages" to "$s intitle:\"index of\""
            rows += "Idea: login pages" to "$s (inurl:login OR inurl:admin)"
            rows += "Idea: leaked configs" to "$s (ext:env OR ext:conf OR ext:log)"
        }
        return ToolResult("Google dork", rows)
    }

    // ---------- Social profiles (public APIs only) ----------
    suspend fun social(platform: String, user: String): ToolResult {
        val u = user.trim().removePrefix("@"); require(Regex("[A-Za-z0-9._-]{1,40}").matches(u)) { "Invalid username" }
        fun ts(sec: Long) = fmtDate(Date(sec * 1000))
        return when (platform.lowercase()) {
            "github" -> { val r = Net.get("https://api.github.com/users/$u"); if (r.code == 404) notFound(platform, u) else {
                val j = JSONObject(r.body); ToolResult("GitHub profile **@$u**", listOf("Name" to j.optString("name"), "Bio" to j.optString("bio"),
                    "Location" to j.optString("location"), "Company" to j.optString("company"), "Website" to j.optString("blog"),
                    "Repos" to "${j.optInt("public_repos")}", "Followers" to "${j.optInt("followers")}", "Following" to "${j.optInt("following")}",
                    "Joined" to day(j.optString("created_at"))).filter { it.second.isNotBlank() && it.second != "null" }) } }
            "reddit" -> { val r = Net.get("https://www.reddit.com/user/$u/about.json"); if (r.code != 200) notFound(platform, u) else {
                val j = JSONObject(r.body).getJSONObject("data"); ToolResult("Reddit profile **u/$u**", listOf("Post karma" to "${j.optInt("link_karma")}",
                    "Comment karma" to "${j.optInt("comment_karma")}", "Joined" to ts(j.optLong("created_utc")), "Bio" to j.optJSONObject("subreddit")?.optString("public_description").orEmpty()).filter { it.second.isNotBlank() }) } }
            "hackernews" -> { val r = Net.get("https://hacker-news.firebaseio.com/v0/user/$u.json"); if (r.body.trim() == "null") notFound(platform, u) else {
                val j = JSONObject(r.body); ToolResult("Hacker News **$u**", listOf("Karma" to "${j.optInt("karma")}", "Joined" to ts(j.optLong("created")),
                    "About" to j.optString("about").replace(Regex("<[^>]*>"), " ").take(300)).filter { it.second.isNotBlank() }) } }
            "gitlab" -> { val a = JSONArray(Net.get("https://gitlab.com/api/v4/users?username=$u").body); if (a.length() == 0) notFound(platform, u) else {
                val j = a.getJSONObject(0); ToolResult("GitLab profile **@$u**", listOf("Name" to j.optString("name"), "State" to j.optString("state"), "Profile" to j.optString("web_url"))) } }
            else -> ToolResult("Social profile", listOf("Unsupported" to "Supported: github, reddit, hackernews, gitlab"), "Other platforms need authenticated APIs.")
        }
    }
    private fun notFound(p: String, u: String) = ToolResult("$p profile", listOf("Result" to "No public profile found for @$u"))

    // ---------- Saved scans ----------
    suspend fun history(c: ToolContext, module: String): ToolResult {
        val list = if (module.isBlank()) c.db.scans().recent(15) else c.db.scans().recentByModule(module, 15)
        val f = SimpleDateFormat("MMM d HH:mm", Locale.US)
        return ToolResult("Recent scans", if (list.isEmpty()) listOf("Result" to "No saved scans yet")
        else list.map { "${it.module} · ${it.target}".take(60) to f.format(Date(it.createdAt)) })
    }
}
