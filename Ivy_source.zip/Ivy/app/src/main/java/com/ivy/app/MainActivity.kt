package com.ivy.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ivy.app.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
        )
        setContent { IvyTheme { Surface(Modifier.fillMaxSize(), color = C.bg) { IvyRoot() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IvyRoot(vm: MainViewModel = viewModel()) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val live by vm.live.collectAsState()
    val confirm by vm.confirmReq.collectAsState()
    var settingsOpen by remember { mutableStateOf(false) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var pendingMic by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingMic?.invoke(); pendingMic = null
    }
    fun withMic(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingMic = action; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
    }

    when {
        live.active -> LiveScreen(vm)
        settingsOpen -> SettingsScreen(vm) { settingsOpen = false }
        else -> ModalNavigationDrawer(
            drawerState = drawer,
            drawerContent = {
                ConversationDrawer(vm,
                    onNew = { vm.newChat(); scope.launch { drawer.close() } },
                    onSelect = { vm.select(it); scope.launch { drawer.close() } },
                    onSettings = { settingsOpen = true; scope.launch { drawer.close() } })
            },
        ) { ChatScreen(vm, onMenu = { scope.launch { drawer.open() } }, onSettings = { settingsOpen = true },
            onLive = { withMic { vm.startLive() } }, onDictate = { withMic { vm.dictate() } }) }
    }

    confirm?.let { req ->
        AlertDialog(
            onDismissRequest = { req.answer.complete(false) }, containerColor = C.surface,
            title = { Text("Confirm action") }, text = { Text(req.prompt) },
            confirmButton = { TextButton({ req.answer.complete(true) }) { Text("Run") } },
            dismissButton = { TextButton({ req.answer.complete(false) }) { Text("Cancel") } },
        )
    }
}
