package com.ivy.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.ivy.app.system.IvyAccessibilityService
import com.ivy.app.system.ShizukuBridge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val s by vm.settings.state.collectAsState()
    var keyDialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    var engineDialog by remember { mutableStateOf(false) }
    var clearDialog by remember { mutableStateOf(false) }
    var a11y by remember { mutableStateOf(IvyAccessibilityService.instance != null) }
    var shizuku by remember { mutableStateOf(ShizukuBridge.isActive()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { a11y = IvyAccessibilityService.instance != null; shizuku = ShizukuBridge.isActive() }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { it?.let(vm::export) }
    fun keySub(v: String) = if (v.isBlank()) "not set" else "●●●●●●●● connected"

    Column(Modifier.fillMaxSize().background(C.bg).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("Settings", color = C.text, fontSize = 26.sp, modifier = Modifier.padding(start = 6.dp, top = 20.dp, bottom = 12.dp))

        Section("AI PROVIDERS") {
            Item("Gemini API key", keySub(s.gemini), chevron = true) { keyDialog = "gemini" to "Gemini API key" }
            Divider2(); Item("Groq API key", keySub(s.groq), chevron = true) { keyDialog = "groq" to "Groq API key" }
        }
        Section("VOICE") {
            Item("Live mode engine", trailing = { Text(if (s.engine == "groq") "Groq" else "Gemini", color = C.sub, fontSize = 16.sp) }) { engineDialog = true }
            Divider2()
            Item("Fast transcription (Groq)", trailing = {
                Switch(s.fastTranscription, { vm.settings.setFast(it) }, colors = SwitchDefaults.colors(
                    checkedTrackColor = C.accent, checkedThumbColor = Color(0xFF111113), uncheckedTrackColor = C.surface2, uncheckedThumbColor = C.sub, uncheckedBorderColor = C.surface2))
            }) { vm.settings.setFast(!s.fastTranscription) }
        }
        Section("RECON KEYS (OPTIONAL)") {
            Item("Have I Been Pwned key", keySub(s.hibp), chevron = true) { keyDialog = "hibp" to "Have I Been Pwned API key" }
            Divider2(); Item("VirusTotal key", keySub(s.vt), chevron = true) { keyDialog = "vt" to "VirusTotal API key" }
        }
        Section("LOCAL DATA") {
            Item("Database encryption", "SQLCipher · Android Keystore", trailing = { Text("Enabled", color = C.sub, fontSize = 16.sp) }) {}
            Divider2(); Item("Export history", chevron = true) { export.launch("ivy_history.json") }
            Divider2(); Item("Clear all local data", chevron = true, danger = true) { clearDialog = true }
        }
        Section("SYSTEM ACCESS") {
            Item("Accessibility Service", trailing = { Text(if (a11y) "Active" else "Off", color = C.sub, fontSize = 16.sp) }) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Divider2()
            Item("Shizuku (ADB bridge)", trailing = { Text(if (shizuku) "Active" else if (ShizukuBridge.isRunning()) "Tap to allow" else "Off", color = C.sub, fontSize = 16.sp) }) {
                ShizukuBridge.requestPermission()
                if (!ShizukuBridge.isRunning()) ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    keyDialog?.let { (k, label) ->
        var v by remember(k) { mutableStateOf("") }
        AlertDialog(onDismissRequest = { keyDialog = null }, containerColor = C.surface, title = { Text(label) },
            text = { OutlinedTextField(v, { v = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), placeholder = { Text("Paste key") }) },
            confirmButton = { TextButton({ if (v.isNotBlank()) vm.settings.setSecret(k, v.trim()); keyDialog = null }) { Text("Save") } },
            dismissButton = { TextButton({ vm.settings.setSecret(k, ""); keyDialog = null }) { Text("Remove") } })
    }
    if (engineDialog) AlertDialog(onDismissRequest = { engineDialog = false }, containerColor = C.surface, title = { Text("Live mode engine") },
        text = { Column {
            listOf("gemini" to "Gemini", "groq" to "Groq").forEach { (id, name) ->
                Row(Modifier.fillMaxWidth().clickable { vm.settings.setEngine(id); engineDialog = false }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(s.engine == id, { vm.settings.setEngine(id); engineDialog = false }); Spacer(Modifier.width(8.dp)); Text(name)
                }
            }
        } }, confirmButton = {})
    if (clearDialog) AlertDialog(onDismissRequest = { clearDialog = false }, containerColor = C.surface, title = { Text("Clear all local data?") },
        text = { Text("Deletes all chats and saved scan results on this device. API keys are kept.") },
        confirmButton = { TextButton({ vm.clearAll(); clearDialog = false }) { Text("Clear", color = C.danger) } },
        dismissButton = { TextButton({ clearDialog = false }) { Text("Cancel") } })
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, color = C.sub, fontSize = 13.sp, letterSpacing = 1.sp, modifier = Modifier.padding(start = 6.dp, top = 22.dp, bottom = 10.dp))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.surface), content = content)
}

@Composable
private fun Divider2() = HorizontalDivider(color = C.divider, modifier = Modifier.padding(horizontal = 20.dp))

@Composable
private fun Item(title: String, sub: String? = null, chevron: Boolean = false, danger: Boolean = false,
                 trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = if (danger) C.danger else C.text, fontSize = 17.sp)
            if (sub != null) Text(sub, color = C.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        }
        trailing?.invoke()
        if (chevron) Icon(Icons.Filled.ChevronRight, null, tint = if (danger) C.danger else C.sub)
    }
}
