package com.ivy.app.system

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/** Elevated (ADB-level) shell without root, via the Shizuku service. */
object ShizukuBridge {
    fun isActive(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun requestPermission() { try { if (Shizuku.pingBinder()) Shizuku.requestPermission(1001) } catch (_: Throwable) {} }

    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        check(isActive()) { "Shizuku is not running or permission was not granted." }
        // newProcess is private in Shizuku API 13+, but remains the supported way to run shell commands.
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText(); val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        (out + (if (err.isNotBlank()) "\n[stderr] $err" else "") + "\n[exit $code]").trim()
    }
}
