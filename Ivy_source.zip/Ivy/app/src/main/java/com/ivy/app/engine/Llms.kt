package com.ivy.app.engine

import com.ivy.app.data.AppSettings
import com.ivy.app.domain.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object LlmFactory {
    fun create(s: AppSettings): Llm? {
        val g = s.gemini.isNotBlank(); val q = s.groq.isNotBlank()
        return when {
            s.engine == "gemini" && g -> GeminiLlm(s.gemini)
            s.engine == "groq" && q -> GroqLlm(s.groq)
            g -> GeminiLlm(s.gemini)
            q -> GroqLlm(s.groq)
            else -> null
        }
    }
}

private fun parts(vararg o: JSONObject) = JSONArray().also { a -> o.forEach { a.put(it) } }

class GeminiLlm(private val key: String, private val model: String = "gemini-2.5-flash") : Llm {
    override suspend fun chat(system: String, turns: List<Turn>, tools: List<ToolSpec>): Reply {
        val contents = JSONArray()
        for (t in turns) {
            when (t.role) {
                "user", "assistant" -> if (t.text.isNotBlank())
                    contents.put(JSONObject().put("role", if (t.role == "user") "user" else "model")
                        .put("parts", parts(JSONObject().put("text", t.text))))
                "call" -> contents.put(JSONObject().put("role", "model").put("parts", parts(
                    JSONObject().put("functionCall", JSONObject().put("name", t.callName).put("args", t.callArgs ?: JSONObject())))))
                else -> contents.put(JSONObject().put("role", "user").put("parts", parts(
                    JSONObject().put("functionResponse", JSONObject().put("name", t.callName)
                        .put("response", JSONObject().put("result", t.text))))))
            }
        }
        val decls = JSONArray()
        tools.forEach {
            val d = JSONObject().put("name", it.name).put("description", it.description)
            if (it.params.isNotEmpty()) d.put("parameters", it.schema())
            decls.put(d)
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", parts(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
        val r = Net.post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            body.toString(), mapOf("x-goog-api-key" to key))
        if (r.code != 200) error("Gemini ${r.code}: ${r.body.take(300)}")
        val ps = JSONObject(r.body).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return Reply.Text("(no response)")
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            p.optJSONObject("functionCall")?.let {
                return Reply.Call(it.getString("name"), it.optJSONObject("args") ?: JSONObject(), "g" + UUID.randomUUID().toString().take(8))
            }
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        return Reply.Text(sb.toString().ifBlank { "(no response)" })
    }
}

class GroqLlm(private val key: String, private val model: String = "llama-3.3-70b-versatile") : Llm {
    override suspend fun chat(system: String, turns: List<Turn>, tools: List<ToolSpec>): Reply {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for (t in turns) {
            when (t.role) {
                "user", "assistant" -> if (t.text.isNotBlank()) msgs.put(JSONObject().put("role", t.role).put("content", t.text))
                "call" -> msgs.put(JSONObject().put("role", "assistant").put("content", JSONObject.NULL).put("tool_calls",
                    JSONArray().put(JSONObject().put("id", t.callId).put("type", "function").put("function",
                        JSONObject().put("name", t.callName).put("arguments", (t.callArgs ?: JSONObject()).toString())))))
                else -> msgs.put(JSONObject().put("role", "tool").put("tool_call_id", t.callId).put("content", t.text))
            }
        }
        val tl = JSONArray()
        tools.forEach {
            tl.put(JSONObject().put("type", "function").put("function",
                JSONObject().put("name", it.name).put("description", it.description).put("parameters", it.schema())))
        }
        val body = JSONObject().put("model", model).put("messages", msgs).put("tools", tl).put("tool_choice", "auto")
        val r = Net.post("https://api.groq.com/openai/v1/chat/completions", body.toString(), mapOf("Authorization" to "Bearer $key"))
        if (r.code != 200) error("Groq ${r.code}: ${r.body.take(300)}")
        val m = JSONObject(r.body).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        m.optJSONArray("tool_calls")?.optJSONObject(0)?.let {
            val f = it.getJSONObject("function")
            val args = try { JSONObject(f.optString("arguments").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
            return Reply.Call(f.getString("name"), args, it.optString("id", "q" + UUID.randomUUID().toString().take(8)))
        }
        return Reply.Text(m.optString("content").ifBlank { "(no response)" })
    }
}
