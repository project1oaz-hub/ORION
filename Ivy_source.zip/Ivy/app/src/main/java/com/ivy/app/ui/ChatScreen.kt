package com.ivy.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ivy.app.data.MessageEntity
import com.ivy.app.domain.ToolResult
import com.ivy.app.engine.LlmFactory

@Composable
fun ChatScreen(vm: MainViewModel, onMenu: () -> Unit, onSettings: () -> Unit, onLive: () -> Unit, onDictate: () -> Unit) {
    val msgs by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val att by vm.attachment.collectAsState()
    val dictating by vm.dictating.collectAsState()
    val dictated by vm.dictated.collectAsState()
    val s by vm.settings.state.collectAsState()
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var providerMenu by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::attach) }
    val provider = LlmFactory.provider(s) ?: s.engine

    LaunchedEffect(dictated) { if (dictated.isNotBlank()) { input = (input + " " + dictated).trim(); vm.dictated.value = "" } }
    LaunchedEffect(msgs.size, busy) {
        val n = msgs.size + if (busy) 1 else 0
        if (n > 0) list.animateScrollToItem(n - 1)
    }

    DotGridBackground(Modifier.fillMaxSize(), active = busy || dictating, energy = if (dictating) 0.5f else 0f) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Menu, "Menu", tint = C.text, modifier = Modifier.size(28.dp).clickable(onClick = onMenu))
                Spacer(Modifier.width(26.dp))
                Text("Ivy", color = C.text, fontSize = 34.sp, fontFamily = FontFamily.Serif)
                Spacer(Modifier.weight(1f))
                Box {
                    Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { providerMenu = true }.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(provider.replaceFirstChar { it.uppercase() }, color = C.accent, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                        Icon(Icons.Filled.ArrowDropDown, null, tint = C.accent)
                    }
                    DropdownMenu(providerMenu, { providerMenu = false }, containerColor = C.surface2) {
                        listOf("gemini" to "Gemini", "groq" to "Groq").forEach { (id, name) ->
                            DropdownMenuItem(text = { Text(name, color = if (id == provider) C.accent else C.text) },
                                onClick = { vm.settings.setEngine(id); providerMenu = false })
                        }
                    }
                }
                Spacer(Modifier.width(14.dp))
                Icon(Icons.Filled.Settings, "Settings", tint = C.sub, modifier = Modifier.size(30.dp).clickable(onClick = onSettings))
            }

            Box(Modifier.weight(1f)) {
                if (msgs.isEmpty() && !busy) Greeting()
                else LazyColumn(Modifier.fillMaxSize(), state = list, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(msgs, key = { it.id }) { MessageItem(it) }
                    if (busy) item { Text("Thinking…", color = C.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 36.dp)) }
                }
            }

            att?.let {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(C.surface).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("📎 ${it.name.take(28)}", color = C.text, fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Filled.Close, "Remove", tint = C.sub, modifier = Modifier.size(16.dp).clickable { vm.clearAttachment() })
                }
            }

            Row(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(32.dp)).background(C.surface).padding(start = 24.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    if (input.isEmpty()) Text(if (dictating) "Listening…" else "Ask Ivy", color = C.sub, fontSize = 19.sp)
                    BasicTextField(input, { input = it }, textStyle = TextStyle(color = C.text, fontSize = 19.sp),
                        cursorBrush = SolidColor(C.accent), maxLines = 5, modifier = Modifier.fillMaxWidth())
                }
                Icon(Icons.Filled.Add, "Attach", tint = C.sub, modifier = Modifier.clip(CircleShape).clickable { picker.launch("*/*") }.padding(8.dp).size(24.dp))
                Icon(if (dictating) Icons.Filled.Stop else Icons.Filled.Mic, "Dictate", tint = C.accent,
                    modifier = Modifier.clip(CircleShape).clickable(onClick = onDictate).padding(8.dp).size(26.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(54.dp).clip(CircleShape).background(C.accent).clickable {
                    if (input.isNotBlank()) { vm.send(input); input = "" } else onLive()
                }, contentAlignment = Alignment.Center) {
                    Icon(if (input.isNotBlank()) Icons.Filled.ArrowUpward else Icons.Filled.GraphicEq, "Send", tint = Color(0xFF0B1B3A), modifier = Modifier.size(28.dp))
                }
            }
        }
    }
}

@Composable
private fun Greeting() {
    Column(Modifier.fillMaxWidth().padding(start = 24.dp, top = 56.dp)) {
        Text("Hello", style = TextStyle(
            brush = Brush.horizontalGradient(listOf(Color(0xFF4C8DF6), Color(0xFF9B72CB), Color(0xFFD96570))),
            fontSize = 60.sp, fontWeight = FontWeight.Medium))
        Text("How can I help today?", color = Color(0xFF5F6368), fontSize = 31.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, lineHeight = 40.sp)
    }
}

fun boldText(s: String): AnnotatedString = buildAnnotatedString {
    s.split("**").forEachIndexed { i, p -> if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = C.text)) { append(p) } else append(p) }
}

@Composable
fun MessageItem(m: MessageEntity) {
    when (m.role) {
        "user" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(24.dp)).background(C.surface2).padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text(m.text, color = C.text, fontSize = 16.sp, lineHeight = 24.sp)
            }
        }
        "status" -> Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Public, null, tint = C.sub, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp)); Text(m.text, color = C.sub, fontSize = 15.sp)
        }
        "card" -> Column {
            Row(verticalAlignment = Alignment.Top) {
                Avatar(); Spacer(Modifier.width(12.dp))
                Text(boldText(m.text), color = C.text, fontSize = 16.sp, lineHeight = 24.sp)
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.padding(start = 36.dp)) { ResultCard(ToolResult.fromJson(m.cardJson ?: return@Box)) }
        }
        else -> Row(verticalAlignment = Alignment.Top) {
            Avatar(); Spacer(Modifier.width(12.dp))
            Text(boldText(m.text), color = Color(0xFFD0D0D4), fontSize = 16.sp, lineHeight = 26.sp)
        }
    }
}

@Composable private fun Avatar() = Box(Modifier.padding(top = 3.dp).size(24.dp).clip(CircleShape).background(Color(0xFF3A3B3E)))

@Composable
fun ResultCard(r: ToolResult) {
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.surface).border(BorderStroke(1.dp, C.border), RoundedCornerShape(16.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        r.rows.take(80).forEach { (k, v) ->
            val link = v.startsWith("http")
            if (v.isBlank()) Text(k, color = if (k.startsWith("http")) C.accent else C.text, fontSize = 15.sp,
                modifier = Modifier.fillMaxWidth().then(if (k.startsWith("http")) Modifier.clickable { runCatching { uri.openUri(k) } } else Modifier))
            else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(k, color = C.sub, fontSize = 15.sp, modifier = Modifier.widthIn(max = 120.dp))
                Text(v, color = if (link) C.accent else C.text, fontSize = 15.sp, textAlign = TextAlign.End,
                    modifier = Modifier.weight(1f).then(if (link) Modifier.clickable { runCatching { uri.openUri(v) } } else Modifier))
            }
        }
        if (r.rows.size > 80) Text("+ ${r.rows.size - 80} more (saved locally)", color = C.sub, fontSize = 13.sp)
        r.note?.let { Text(it, color = C.sub, fontSize = 13.sp) }
    }
}
