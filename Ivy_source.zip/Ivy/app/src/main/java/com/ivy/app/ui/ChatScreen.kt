package com.ivy.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ivy.app.data.MessageEntity
import com.ivy.app.domain.ToolResult

@Composable
fun ChatScreen(vm: MainViewModel, onMenu: () -> Unit, onMic: () -> Unit) {
    val msgs by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val att by vm.attachment.collectAsState()
    val list = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::attach) }

    LaunchedEffect(msgs.size, busy) {
        val n = msgs.size + if (busy) 1 else 0
        if (n > 0) list.animateScrollToItem(n - 1)
    }

    Column(Modifier.fillMaxSize().background(C.bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Icon(Icons.Filled.Menu, "Menu", tint = C.text, modifier = Modifier.align(Alignment.CenterStart).size(28.dp).clickable(onClick = onMenu))
            Text("Ivy", Modifier.align(Alignment.Center), color = C.text, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Box(Modifier.align(Alignment.CenterEnd).size(40.dp).clip(CircleShape).background(C.circle), contentAlignment = Alignment.Center) {
                Text("B", color = C.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
        }
        LazyColumn(Modifier.weight(1f), state = list, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(msgs, key = { it.id }) { MessageItem(it) }
            if (busy) item { Text("Thinking…", color = C.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 36.dp)) }
        }
        att?.let {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(C.surface).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("📎 ${it.name.take(28)}", color = C.text, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.Close, "Remove", tint = C.sub, modifier = Modifier.size(16.dp).clickable { vm.clearAttachment() })
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(32.dp)).background(C.surface).padding(start = 22.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                if (input.isEmpty()) Text("Ask Ivy", color = C.sub, fontSize = 17.sp)
                BasicTextField(input, { input = it }, textStyle = androidx.compose.ui.text.TextStyle(color = C.text, fontSize = 17.sp),
                    cursorBrush = SolidColor(C.accent), maxLines = 5, modifier = Modifier.fillMaxWidth())
            }
            Icon(Icons.Filled.Add, "Attach", tint = C.text, modifier = Modifier.clip(CircleShape).clickable { picker.launch("*/*") }.padding(8.dp).size(24.dp))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(48.dp).clip(CircleShape).background(C.circle).clickable {
                if (input.isNotBlank()) { vm.send(input); input = "" } else onMic()
            }, contentAlignment = Alignment.Center) {
                Icon(if (input.isNotBlank()) Icons.Filled.ArrowUpward else Icons.Filled.Mic, "Send", tint = C.text)
            }
        }
    }
}

fun boldText(s: String): AnnotatedString = buildAnnotatedString {
    s.split("**").forEachIndexed { i, p -> if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = C.text)) { append(p) } else append(p) }
}

@Composable
fun MessageItem(m: MessageEntity) {
    when (m.role) {
        "user" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(24.dp)).background(C.surface2).padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text(m.text, color = C.text, fontSize = 16.sp, lineHeight = 24.sp)
            }
        }
        "status" -> Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Public, null, tint = C.sub, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp)); Text(m.text, color = C.sub, fontSize = 15.sp)
        }
        "card" -> Column {
            Row(verticalAlignment = Alignment.Top) {
                Avatar(); Spacer(Modifier.width(12.dp))
                Text(boldText(m.text), color = C.text, fontSize = 16.sp, lineHeight = 24.sp)
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.padding(start = 36.dp)) { ResultCard(ToolResult.fromJson(m.cardJson ?: return@Box)) }
        }
        else -> Row(verticalAlignment = Alignment.Top) {
            Avatar(); Spacer(Modifier.width(12.dp))
            Text(boldText(m.text), color = Color(0xFFD0D0D4), fontSize = 16.sp, lineHeight = 26.sp)
        }
    }
}

@Composable private fun Avatar() = Box(Modifier.padding(top = 3.dp).size(24.dp).clip(CircleShape).background(Color(0xFF3A3B3E)))

@Composable
fun ResultCard(r: ToolResult) {
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.surface).border(BorderStroke(1.dp, C.border), RoundedCornerShape(16.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        r.rows.take(80).forEach { (k, v) ->
            val link = v.startsWith("http")
            if (v.isBlank()) Text(k, color = if (k.startsWith("http")) C.accent else C.text, fontSize = 15.sp,
                modifier = Modifier.fillMaxWidth().then(if (k.startsWith("http")) Modifier.clickable { runCatching { uri.openUri(k) } } else Modifier))
            else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(k, color = C.sub, fontSize = 15.sp, modifier = Modifier.widthIn(max = 120.dp))
                Text(v, color = if (link) C.accent else C.text, fontSize = 15.sp, textAlign = TextAlign.End,
                    modifier = Modifier.weight(1f).then(if (link) Modifier.clickable { runCatching { uri.openUri(v) } } else Modifier))
            }
        }
        if (r.rows.size > 80) Text("+ ${r.rows.size - 80} more (saved locally)", color = C.sub, fontSize = 13.sp)
        r.note?.let { Text(it, color = C.sub, fontSize = 13.sp) }
    }
}
