package com.ivy.app.engine

import org.json.JSONArray
import org.json.JSONObject

/** Lists the chat models the user's key can actually use, straight from each provider. */
object ModelCatalog {
    private val SKIP = listOf("embedding", "tts", "image", "aqa", "imagen", "veo", "robotics", "computer-use", "whisper", "orpheus", "guard", "audio", "live")

    suspend fun list(provider: String, key: String): List<String> {
        val ids = if (provider == "gemini") {
            val r = Net.get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", mapOf("x-goog-api-key" to key))
            if (r.code != 200) error("Gemini ${r.code}: ${r.body.take(160)}")
            val a = JSONObject(r.body).optJSONArray("models") ?: JSONArray()
            (0 until a.length()).map { a.getJSONObject(it) }.filter {
                val m = it.optJSONArray("supportedGenerationMethods"); (0 until (m?.length() ?: 0)).any { i -> m!!.optString(i) == "generateContent" }
            }.map { it.getString("name").removePrefix("models/") }
        } else {
            val r = Net.get("https://api.groq.com/openai/v1/models", mapOf("Authorization" to "Bearer $key"))
            if (r.code != 200) error("Groq ${r.code}: ${r.body.take(160)}")
            val a = JSONObject(r.body).optJSONArray("data") ?: JSONArray()
            (0 until a.length()).map { a.getJSONObject(it) }.filter { it.optBoolean("active", true) }.map { it.getString("id") }
        }
        return ids.filter { id -> SKIP.none { id.contains(it, true) } }.distinct().sorted()
    }

    fun pickDefault(provider: String, models: List<String>): String? {
        if (models.isEmpty()) return null
        return if (provider == "gemini")
            models.firstOrNull { it == "gemini-2.5-flash" } ?: models.firstOrNull { it.contains("flash") && !it.contains("lite") && !it.contains("preview") && !it.contains("exp") }
                ?: models.firstOrNull { it.contains("flash") } ?: models.first()
        else
            models.firstOrNull { it == "llama-3.3-70b-versatile" } ?: models.firstOrNull { it.contains("llama") && it.contains("70b") }
                ?: models.firstOrNull { it.contains("llama") } ?: models.first()
    }
}
