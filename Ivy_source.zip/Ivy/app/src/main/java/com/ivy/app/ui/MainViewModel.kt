package com.ivy.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ivy.app.IvyApp
import com.ivy.app.data.ConversationEntity
import com.ivy.app.data.MessageEntity
import com.ivy.app.domain.AssistantOrchestrator
import com.ivy.app.domain.Attachment
import com.ivy.app.engine.Recorder
import com.ivy.app.engine.Speaker
import com.ivy.app.engine.SystemStt
import com.ivy.app.engine.Transcriber
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject

enum class Phase { Idle, Listening, Thinking, Speaking }
data class LiveUi(val active: Boolean = false, val phase: Phase = Phase.Idle, val caption: String = "",
                  val level: Float = 0f, val muted: Boolean = false, val showCaptions: Boolean = true)
class ConfirmRequest(val prompt: String, val answer: CompletableDeferred<Boolean>)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ivy = app as IvyApp
    val settings = ivy.settings
    private val uiPrefs = ivy.getSharedPreferences("ivy_ui", Context.MODE_PRIVATE)

    // ---------- conversations ----------
    val currentId = MutableStateFlow<Long?>(uiPrefs.getLong("conv", -1L).takeIf { it > 0 })
    val conversations: StateFlow<List<ConversationEntity>> = ivy.db.conversations().observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val messages: StateFlow<List<MessageEntity>> = currentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else ivy.db.messages().observe(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val busy = MutableStateFlow(false)
    val attachment = MutableStateFlow<Attachment?>(null)
    val confirmReq = MutableStateFlow<ConfirmRequest?>(null)
    val live = MutableStateFlow(LiveUi())
    val dictating = MutableStateFlow(false)
    val dictated = MutableStateFlow("")

    private val orchestrator = AssistantOrchestrator(ivy, ivy.db, settings) { prompt ->
        val d = CompletableDeferred<Boolean>(); confirmReq.value = ConfirmRequest(prompt, d)
        try { d.await() } finally { confirmReq.value = null }
    }

    fun select(id: Long) { currentId.value = id; uiPrefs.edit().putLong("conv", id).apply() }
    fun newChat() { currentId.value = null; uiPrefs.edit().remove("conv").apply() }
    fun rename(id: Long, title: String) { viewModelScope.launch { if (title.isNotBlank()) ivy.db.conversations().rename(id, title.trim().take(60)) } }
    fun delete(id: Long) {
        viewModelScope.launch {
            ivy.db.messages().deleteFor(id); ivy.db.conversations().delete(id)
            if (currentId.value == id) newChat()
        }
    }

    private suspend fun ensureConversation(): Long {
        currentId.value?.let { return it }
        val id = ivy.db.conversations().insert(ConversationEntity(title = "New chat"))
        select(id); return id
    }

    fun send(text: String) {
        if (text.isBlank() || busy.value) return
        val att = attachment.value; attachment.value = null
        viewModelScope.launch {
            busy.value = true
            try { orchestrator.handle(ensureConversation(), text.trim(), att) } finally { busy.value = false }
        }
    }

    fun attach(uri: Uri) {
        val cr = getApplication<Application>().contentResolver
        var name = "file"
        cr.query(uri, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i) } }
        attachment.value = Attachment(uri, name, cr.getType(uri) ?: "application/octet-stream")
    }
    fun clearAttachment() { attachment.value = null }

    fun clearAll() {
        viewModelScope.launch {
            ivy.db.messages().clear(); ivy.db.conversations().clear(); ivy.db.scans().clear(); newChat()
        }
    }

    fun export(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val c = JSONArray(); ivy.db.conversations().all().forEach { c.put(JSONObject().put("id", it.id).put("title", it.title).put("created", it.createdAt)) }
            val m = JSONArray(); ivy.db.messages().all().forEach {
                m.put(JSONObject().put("conversation", it.conversationId).put("role", it.role).put("text", it.text).put("at", it.createdAt))
            }
            val s = JSONArray(); ivy.db.scans().all().forEach {
                s.put(JSONObject().put("module", it.module).put("target", it.target).put("summary", it.summary ?: "")
                    .put("result", JSONObject(it.resultJson)).put("at", it.createdAt))
            }
            ivy.contentResolver.openOutputStream(uri)?.use {
                it.write(JSONObject().put("conversations", c).put("messages", m).put("scans", s).toString(2).toByteArray())
            }
        }
    }

    // ---------- Voice: system STT / TTS by default, cloud STT optional ----------
    private val sysStt by lazy { SystemStt(ivy) }
    private val speaker by lazy { Speaker(ivy) }
    private var liveJob: Job? = null
    private var dictJob: Job? = null

    /** Mic inside the input pill: one utterance into the text box. Tap again to cancel. */
    fun dictate() {
        if (dictJob?.isActive == true) { dictJob?.cancel(); return }
        dictJob = viewModelScope.launch {
            dictating.value = true
            try {
                val s = settings.state.value
                dictated.value = if (s.stt == "system" && sysStt.available()) sysStt.listen({ }, { }).orEmpty()
                else Recorder.record { }?.let { Transcriber.transcribe(it, s) }.orEmpty()
            } catch (e: CancellationException) { throw e } catch (e: Exception) { dictated.value = "" }
            finally { dictating.value = false }
        }
    }

    /** Live mode: listen → transcribe → think (+ tool) → speak → repeat. */
    fun startLive() {
        if (liveJob?.isActive == true) return
        live.update { it.copy(active = true, phase = Phase.Idle, caption = "") }
        liveJob = viewModelScope.launch {
            try {
                while (isActive) {
                    if (live.value.muted) { live.update { it.copy(phase = Phase.Idle) }; delay(300); continue }
                    live.update { it.copy(phase = Phase.Listening, caption = "") }
                    val s = settings.state.value
                    var heard: String? = null
                    try {
                        if (s.stt == "system" && sysStt.available()) {
                            heard = sysStt.listen({ l -> live.update { it.copy(level = l) } }, { p -> live.update { it.copy(caption = p) } })
                        } else {
                            val wav = Recorder.record { l -> live.update { it.copy(level = l) } }
                            if (wav != null) { live.update { it.copy(phase = Phase.Thinking) }; heard = Transcriber.transcribe(wav, s) }
                        }
                    } catch (e: CancellationException) { throw e } catch (e: Exception) {
                        live.update { it.copy(caption = e.message?.take(120) ?: "Speech recognition failed", level = 0f) }
                        delay(2500); continue
                    }
                    val text = heard?.trim().orEmpty()
                    if (text.isEmpty()) { delay(250); continue }
                    live.update { it.copy(phase = Phase.Thinking, caption = text, level = 0f) }
                    busy.value = true
                    val reply = try { orchestrator.handle(ensureConversation(), text, null) } finally { busy.value = false }
                    live.update { it.copy(phase = Phase.Speaking, caption = reply.replace("**", "").take(160)) }
                    speaker.speak(reply)
                }
            } finally {
                speaker.stop()
                live.update { it.copy(active = false, phase = Phase.Idle, caption = "", level = 0f) }
            }
        }
    }
    fun stopLive() { liveJob?.cancel() }
    fun toggleMute() { live.update { it.copy(muted = !it.muted) } }
    fun toggleCaptions() { live.update { it.copy(showCaptions = !it.showCaptions) } }
}
