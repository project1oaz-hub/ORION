package com.ivy.app.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ivy.app.IvyApp
import com.ivy.app.data.MessageEntity
import com.ivy.app.domain.AssistantOrchestrator
import com.ivy.app.domain.Attachment
import com.ivy.app.engine.Recorder
import com.ivy.app.engine.Speaker
import com.ivy.app.engine.Transcriber
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject

enum class Phase { Idle, Listening, Thinking, Speaking }
data class LiveUi(val active: Boolean = false, val phase: Phase = Phase.Idle, val caption: String = "",
                  val level: Float = 0f, val muted: Boolean = false, val showCaptions: Boolean = true)
class ConfirmRequest(val prompt: String, val answer: CompletableDeferred<Boolean>)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ivy = app as IvyApp
    val settings = ivy.settings
    val messages: StateFlow<List<MessageEntity>> = ivy.db.messages().observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val busy = MutableStateFlow(false)
    val attachment = MutableStateFlow<Attachment?>(null)
    val confirmReq = MutableStateFlow<ConfirmRequest?>(null)
    val live = MutableStateFlow(LiveUi())

    private val orchestrator = AssistantOrchestrator(ivy, ivy.db, settings) { prompt ->
        val d = CompletableDeferred<Boolean>(); confirmReq.value = ConfirmRequest(prompt, d)
        try { d.await() } finally { confirmReq.value = null }
    }

    fun send(text: String) {
        if (text.isBlank() || busy.value) return
        val att = attachment.value; attachment.value = null
        viewModelScope.launch {
            busy.value = true
            try { orchestrator.handle(text.trim(), att) } finally { busy.value = false }
        }
    }

    fun attach(uri: Uri) {
        val cr = getApplication<Application>().contentResolver
        var name = "file"
        cr.query(uri, null, null, null, null)?.use { c -> if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i) } }
        attachment.value = Attachment(uri, name, cr.getType(uri) ?: "application/octet-stream")
    }
    fun clearAttachment() { attachment.value = null }

    fun newChat() { viewModelScope.launch { ivy.db.messages().clear() } }
    fun clearAll() { viewModelScope.launch { ivy.db.messages().clear(); ivy.db.scans().clear() } }

    fun export(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val m = JSONArray(); ivy.db.messages().all().forEach { m.put(JSONObject().put("role", it.role).put("text", it.text).put("at", it.createdAt)) }
            val s = JSONArray(); ivy.db.scans().all().forEach {
                s.put(JSONObject().put("module", it.module).put("target", it.target).put("summary", it.summary ?: "")
                    .put("result", JSONObject(it.resultJson)).put("at", it.createdAt))
            }
            ivy.contentResolver.openOutputStream(uri)?.use { it.write(JSONObject().put("messages", m).put("scans", s).toString(2).toByteArray()) }
        }
    }

    // ---------- Live (voice) mode: listen → transcribe → think (+tool) → speak → repeat ----------
    private var liveJob: Job? = null
    private val speaker by lazy { Speaker(ivy) }

    fun startLive() {
        if (liveJob?.isActive == true) return
        live.update { it.copy(active = true, phase = Phase.Idle, caption = "") }
        liveJob = viewModelScope.launch {
            try {
                while (isActive) {
                    if (live.value.muted) { live.update { it.copy(phase = Phase.Idle) }; delay(300); continue }
                    live.update { it.copy(phase = Phase.Listening, caption = "") }
                    val wav = Recorder.record { l -> live.update { it.copy(level = l) } } ?: continue
                    live.update { it.copy(phase = Phase.Thinking) }
                    val text = try { Transcriber.transcribe(wav, settings.state.value) } catch (e: Exception) {
                        live.update { it.copy(caption = e.message?.take(120) ?: "Transcription failed") }; delay(2000); continue
                    }
                    if (text.isBlank()) continue
                    live.update { it.copy(caption = text) }
                    busy.value = true
                    val reply = try { orchestrator.handle(text, null) } finally { busy.value = false }
                    live.update { it.copy(phase = Phase.Speaking, caption = reply.replace("**", "").take(160)) }
                    speaker.speak(reply)
                }
            } finally {
                speaker.stop()
                live.update { it.copy(active = false, phase = Phase.Idle, caption = "", level = 0f) }
            }
        }
    }
    fun stopLive() { liveJob?.cancel() }
    fun toggleMute() { live.update { it.copy(muted = !it.muted) } }
    fun toggleCaptions() { live.update { it.copy(showCaptions = !it.showCaptions) } }
}
