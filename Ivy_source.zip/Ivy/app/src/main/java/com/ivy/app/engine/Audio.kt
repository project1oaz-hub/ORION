package com.ivy.app.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import com.ivy.app.data.AppSettings
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.math.sqrt

object Recorder {
    /** Records one utterance (16 kHz mono WAV); stops after ~1.4 s of silence following speech. Null if no speech. */
    @SuppressLint("MissingPermission")
    suspend fun record(onLevel: (Float) -> Unit): ByteArray? = withContext(Dispatchers.IO) {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192))
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext null }
        val out = ByteArrayOutputStream(); val buf = ShortArray(1600)
        var speech = false; var silent = 0; var total = 0
        rec.startRecording()
        try {
            while (isActive && total < 30_000) {
                val n = rec.read(buf, 0, buf.size); if (n <= 0) break
                var sum = 0.0; for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
                val rms = sqrt(sum / n); onLevel(minOf(1f, (rms / 6000).toFloat()))
                val ms = n * 1000 / rate; total += ms
                val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until n) bb.putShort(buf[i]); out.write(bb.array())
                if (rms > 1200) { speech = true; silent = 0 }
                else if (speech) { silent += ms; if (silent > 1400) break }
                else if (total > 8000) break
            }
        } finally { rec.stop(); rec.release(); onLevel(0f) }
        if (speech) wav(out.toByteArray(), rate) else null
    }

    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray()).put("fmt ".toByteArray())
            .putInt(16).putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
            .put("data".toByteArray()).putInt(pcm.size)
        return h.array() + pcm
    }
}

object Transcriber {
    /** Cloud transcription, used only when Speech recognition is set to Groq / Gemini (system STT is the default). */
    suspend fun transcribe(wav: ByteArray, s: AppSettings): String = when {
        s.stt == "groq" && s.groq.isNotBlank() -> groq(wav, s.groq)
        s.stt == "gemini" && s.gemini.isNotBlank() -> gemini(wav, s.gemini, s.geminiModel.ifBlank { "gemini-2.5-flash" })
        s.groq.isNotBlank() -> groq(wav, s.groq)
        s.gemini.isNotBlank() -> gemini(wav, s.gemini, s.geminiModel.ifBlank { "gemini-2.5-flash" })
        else -> error("Add a Groq or Gemini API key in Settings, or switch Speech recognition to System.")
    }

    private suspend fun groq(wav: ByteArray, key: String): String = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("model", "whisper-large-v3-turbo")
            .addFormDataPart("response_format", "json")
            .addFormDataPart("file", "speech.wav", wav.toRequestBody("audio/wav".toMediaType())).build()
        val req = Request.Builder().url("https://api.groq.com/openai/v1/audio/transcriptions")
            .header("Authorization", "Bearer $key").post(body).build()
        Net.client.newCall(req).execute().use {
            val t = it.body?.string() ?: ""
            if (!it.isSuccessful) error("Groq ${it.code}: ${t.take(200)}")
            JSONObject(t).optString("text").trim()
        }
    }

    private suspend fun gemini(wav: ByteArray, key: String, model: String): String {
        val b64 = Base64.encodeToString(wav, Base64.NO_WRAP)
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
            .put(JSONObject().put("text", "Transcribe this audio verbatim. Output only the transcript."))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", b64))))))
        val r = Net.post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            body.toString(), mapOf("x-goog-api-key" to key))
        if (r.code != 200) error("Gemini ${r.code}: ${r.body.take(200)}")
        return JSONObject(r.body).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).optString("text").trim()
    }
}

class Speaker(ctx: Context) {
    private val ready = CompletableDeferred<Boolean>()
    private val tts: TextToSpeech = TextToSpeech(ctx) { ready.complete(it == TextToSpeech.SUCCESS) }

    suspend fun speak(text: String) {
        if (!ready.await()) return
        val clean = text.replace("**", "").replace("`", "").take(1200)
        suspendCancellableCoroutine { cont ->
            val id = UUID.randomUUID().toString()
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onDone(u: String?) { if (cont.isActive) cont.resume(Unit) }
                @Deprecated("Deprecated in Java") override fun onError(u: String?) { if (cont.isActive) cont.resume(Unit) }
            })
            tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
            cont.invokeOnCancellation { tts.stop() }
        }
    }
    fun stop() { tts.stop() }
    fun shutdown() { tts.shutdown() }
}
