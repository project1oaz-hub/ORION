package com.ivy.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,              // user | assistant | status | card
    val text: String,
    val cardJson: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val module: String,
    val target: String,
    val resultJson: String,
    val summary: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY id") fun observe(): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages ORDER BY id") suspend fun all(): List<MessageEntity>
    @Query("SELECT * FROM messages WHERE role IN ('user','assistant') ORDER BY id DESC LIMIT :n")
    suspend fun recentChat(n: Int): List<MessageEntity>
    @Insert suspend fun insert(m: MessageEntity): Long
    @Query("DELETE FROM messages") suspend fun clear()
}

@Dao
interface ScanDao {
    @Insert suspend fun insert(s: ScanEntity): Long
    @Query("UPDATE scans SET summary = :s WHERE id = :id") suspend fun setSummary(id: Long, s: String)
    @Query("SELECT * FROM scans ORDER BY id DESC LIMIT :n") suspend fun recent(n: Int): List<ScanEntity>
    @Query("SELECT * FROM scans WHERE module = :m ORDER BY id DESC LIMIT :n")
    suspend fun recentByModule(m: String, n: Int): List<ScanEntity>
    @Query("SELECT * FROM scans ORDER BY id DESC") fun observe(): Flow<List<ScanEntity>>
    @Query("SELECT * FROM scans ORDER BY id") suspend fun all(): List<ScanEntity>
    @Query("DELETE FROM scans") suspend fun clear()
}

@Database(entities = [MessageEntity::class, ScanEntity::class], version = 1, exportSchema = false)
abstract class IvyDb : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun scans(): ScanDao
}
