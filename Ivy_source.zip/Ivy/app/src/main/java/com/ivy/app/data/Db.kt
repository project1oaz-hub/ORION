package com.ivy.app.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(defaultValue = "0") val conversationId: Long = 0,
    val role: String,              // user | assistant | status | card
    val text: String,
    val cardJson: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val module: String,
    val target: String,
    val resultJson: String,
    val summary: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC") fun observe(): Flow<List<ConversationEntity>>
    @Query("SELECT * FROM conversations ORDER BY id") suspend fun all(): List<ConversationEntity>
    @Insert suspend fun insert(c: ConversationEntity): Long
    @Query("UPDATE conversations SET title = :t WHERE id = :id") suspend fun rename(id: Long, t: String)
    @Query("UPDATE conversations SET updatedAt = :t WHERE id = :id") suspend fun touch(id: Long, t: Long)
    @Query("SELECT title FROM conversations WHERE id = :id") suspend fun title(id: Long): String?
    @Query("DELETE FROM conversations WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM conversations") suspend fun clear()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY id") fun observe(cid: Long): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages ORDER BY id") suspend fun all(): List<MessageEntity>
    @Query("SELECT * FROM messages WHERE conversationId = :cid AND role IN ('user','assistant') ORDER BY id DESC LIMIT :n")
    suspend fun recentChat(cid: Long, n: Int): List<MessageEntity>
    @Insert suspend fun insert(m: MessageEntity): Long
    @Query("DELETE FROM messages WHERE conversationId = :cid") suspend fun deleteFor(cid: Long)
    @Query("DELETE FROM messages") suspend fun clear()
}

@Dao
interface ScanDao {
    @Insert suspend fun insert(s: ScanEntity): Long
    @Query("UPDATE scans SET summary = :s WHERE id = :id") suspend fun setSummary(id: Long, s: String)
    @Query("SELECT * FROM scans ORDER BY id DESC LIMIT :n") suspend fun recent(n: Int): List<ScanEntity>
    @Query("SELECT * FROM scans WHERE module = :m ORDER BY id DESC LIMIT :n")
    suspend fun recentByModule(m: String, n: Int): List<ScanEntity>
    @Query("SELECT * FROM scans ORDER BY id DESC") fun observe(): Flow<List<ScanEntity>>
    @Query("SELECT * FROM scans ORDER BY id") suspend fun all(): List<ScanEntity>
    @Query("DELETE FROM scans") suspend fun clear()
}

@Database(entities = [ConversationEntity::class, MessageEntity::class, ScanEntity::class], version = 2, exportSchema = false)
abstract class IvyDb : RoomDatabase() {
    abstract fun conversations(): ConversationDao
    abstract fun messages(): MessageDao
    abstract fun scans(): ScanDao
}

/** v1 had one global chat; v2 has many. Existing messages are moved into one "Earlier chat". */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
        db.execSQL("ALTER TABLE messages ADD COLUMN conversationId INTEGER NOT NULL DEFAULT 0")
        db.execSQL("INSERT INTO conversations (title, createdAt, updatedAt) SELECT 'Earlier chat', MIN(createdAt), MAX(createdAt) FROM messages HAVING COUNT(*) > 0")
        db.execSQL("UPDATE messages SET conversationId = (SELECT MAX(id) FROM conversations) WHERE conversationId = 0")
    }
}
