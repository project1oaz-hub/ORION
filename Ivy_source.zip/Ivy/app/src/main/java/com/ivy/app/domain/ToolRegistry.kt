package com.ivy.app.domain

import com.ivy.app.engine.Recon
import com.ivy.app.system.Device
import org.json.JSONObject

class FnTool(
    override val spec: ToolSpec,
    override val category: String,
    private val statusFn: (JSONObject) -> String,
    private val targetKey: String,
    private val fn: suspend (JSONObject, ToolContext) -> ToolResult,
) : Tool {
    override fun status(a: JSONObject) = statusFn(a)
    override fun target(a: JSONObject) = if (targetKey.isBlank()) "" else a.optString(targetKey)
    override suspend fun run(a: JSONObject, c: ToolContext) = fn(a, c)
}

private fun p(n: String, t: String, d: String, req: Boolean = true) = Param(n, t, d, req)
private fun s(a: JSONObject, k: String) = a.optString(k, "")

object ToolRegistry {
    fun all(): List<Tool> = listOf(
        FnTool(ToolSpec("username_search", "Check whether a username exists on ~40 platforms (GitHub, Reddit, Steam, Pinterest, TikTok, X, Instagram...).", listOf(p("username", "string", "Username without @"))),
            "recon", { "Searching for @${s(it, "username")}" }, "username") { a, _ -> Recon.username(s(a, "username")) },
        FnTool(ToolSpec("whois_lookup", "WHOIS/RDAP registration details for a domain: registrar, dates, name servers, registrant if public.", listOf(p("domain", "string", "Domain, e.g. example.com"))),
            "recon", { "Looking up ${s(it, "domain")}" }, "domain") { a, _ -> Recon.whois(s(a, "domain")) },
        FnTool(ToolSpec("dns_lookup", "Resolve DNS records (A, AAAA, MX, TXT, NS, CNAME) for a domain.", listOf(p("domain", "string", "Domain"), p("types", "string", "Comma-separated record types; default all", false))),
            "recon", { "Resolving DNS for ${s(it, "domain")}" }, "domain") { a, _ -> Recon.dns(s(a, "domain"), s(a, "types")) },
        FnTool(ToolSpec("subdomain_enum", "Passive subdomain discovery via certificate transparency (crt.sh) with optional wordlist brute force.", listOf(p("domain", "string", "Root domain"), p("brute", "boolean", "Also brute-force a small wordlist", false))),
            "recon", { "Enumerating subdomains of ${s(it, "domain")}" }, "domain") { a, _ -> Recon.subdomains(s(a, "domain"), a.optBoolean("brute", false)) },
        FnTool(ToolSpec("port_scan", "TCP connect scan of a host. Only use on hosts the user owns or is authorized to test.", listOf(p("host", "string", "Hostname or IP"), p("ports", "string", "Ports like '1-1024' or '22,80,443'; default common ports", false))),
            "recon", { "Scanning ${s(it, "host")}" }, "host") { a, _ -> Recon.portScan(s(a, "host"), s(a, "ports")) },
        FnTool(ToolSpec("ssl_inspect", "Inspect the TLS certificate of a host: issuer, validity, SANs, protocol and cipher.", listOf(p("host", "string", "Hostname"), p("port", "integer", "Port, default 443", false))),
            "recon", { "Checking certificate for ${s(it, "host")}" }, "host") { a, _ -> Recon.ssl(s(a, "host"), a.optInt("port", 443)) },
        FnTool(ToolSpec("ip_geolocate", "Approximate location, ISP and ASN for an IP address or hostname.", listOf(p("target", "string", "IP or hostname"))),
            "recon", { "Locating ${s(it, "target")}" }, "target") { a, _ -> Recon.ipGeo(s(a, "target")) },
        FnTool(ToolSpec("reverse_ip", "List other domains hosted on the same IP as the target.", listOf(p("target", "string", "IP or hostname"))),
            "recon", { "Reverse IP lookup for ${s(it, "target")}" }, "target") { a, _ -> Recon.reverseIp(s(a, "target")) },
        FnTool(ToolSpec("email_breach_check", "Check whether an email address appears in known data breaches (Have I Been Pwned).", listOf(p("email", "string", "Email address"))),
            "recon", { "Checking breaches for ${s(it, "email")}" }, "email") { a, c -> Recon.breach(s(a, "email"), c.settings.hibp) },
        FnTool(ToolSpec("phone_lookup", "Carrier, region and line type for a phone number.", listOf(p("number", "string", "Number, ideally with +country code"), p("region", "string", "ISO region like US, used if no + prefix", false))),
            "recon", { "Looking up ${s(it, "number")}" }, "number") { a, _ -> Recon.phone(s(a, "number"), s(a, "region")) },
        FnTool(ToolSpec("image_exif", "Extract EXIF/metadata (GPS, device, timestamps) from the attached image or an image URL.", listOf(p("url", "string", "Image URL; omit to use the attached file", false))),
            "recon", { "Reading image metadata" }, "url") { a, c -> Recon.exif(c, s(a, "url")) },
        FnTool(ToolSpec("reverse_image_helper", "Compute a perceptual hash and give Google Lens / TinEye / Yandex search links for the attached image or URL.", listOf(p("url", "string", "Public image URL; omit to use the attached file", false))),
            "recon", { "Preparing reverse image search" }, "url") { a, c -> Recon.reverseImage(c, s(a, "url")) },
        FnTool(ToolSpec("file_hash", "MD5/SHA1/SHA256 of the attached file, optionally checked on VirusTotal.", listOf(p("virustotal", "boolean", "Also query VirusTotal", false))),
            "recon", { "Hashing file" }, "") { a, c -> Recon.fileHash(c, a.optBoolean("virustotal", false)) },
        FnTool(ToolSpec("dork_builder", "Build advanced search-engine queries (site:, filetype:, intitle:...) and search links.", listOf(
            p("site", "string", "Domain", false), p("filetype", "string", "e.g. pdf", false), p("intitle", "string", "", false),
            p("inurl", "string", "", false), p("intext", "string", "", false), p("exclude", "string", "Terms to exclude", false), p("keywords", "string", "Free keywords", false))),
            "recon", { "Building search query" }, "site") { a, _ -> Recon.dork(a) },
        FnTool(ToolSpec("social_profile", "Public profile metadata (bio, counts, join date) for github, reddit, hackernews or gitlab.", listOf(p("platform", "string", "github | reddit | hackernews | gitlab"), p("username", "string", "Username"))),
            "recon", { "Fetching ${s(it, "platform")} profile @${s(it, "username")}" }, "username") { a, _ -> Recon.social(s(a, "platform"), s(a, "username")) },
        FnTool(ToolSpec("scan_history", "Show recent saved scan results from the local database.", listOf(p("module", "string", "Filter by tool name", false))),
            "history", { "Reading scan history" }, "module") { a, c -> Recon.history(c, s(a, "module")) },

        FnTool(ToolSpec("open_app", "Open an installed Android app by name.", listOf(p("name", "string", "App name, e.g. YouTube"))),
            "device", { "Opening ${s(it, "name")}" }, "name") { a, c -> Device.openApp(c.app, s(a, "name")) },
        FnTool(ToolSpec("read_screen", "Read visible text on the current screen (Accessibility Service)."),
            "device", { "Reading screen" }, "") { _, _ -> Device.readScreen() },
        FnTool(ToolSpec("click_text", "Tap the on-screen element with the given text (Accessibility Service).", listOf(p("text", "string", "Visible label"))),
            "device", { "Tapping \"${s(it, "text")}\"" }, "text") { a, _ -> Device.clickText(s(a, "text")) },
        FnTool(ToolSpec("global_action", "Press a system button: back, home, recents or notifications.", listOf(p("action", "string", "back | home | recents | notifications"))),
            "device", { "Pressing ${s(it, "action")}" }, "action") { a, _ -> Device.globalAction(s(a, "action")) },
        FnTool(ToolSpec("shell_command", "Run a shell command through Shizuku (ADB-level). The user is asked to confirm first.", listOf(p("command", "string", "Shell command"))),
            "device", { "Running shell command" }, "command") { a, c -> Device.shell(s(a, "command"), c.confirm) },
    )
}
