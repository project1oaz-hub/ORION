"""Embedded recon helpers (run on-device via Chaquopy).
Username search is a Sherlock-style engine: per-site URL templates + status/body checks."""
import json
import re
from concurrent.futures import ThreadPoolExecutor

import requests

UA = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

# (name, url template, body text meaning "not found" or None, weak)
# weak=True: site serves a 200 shell for any name, so a 200 only means "possible".
SITES = [
    ("GitHub", "https://github.com/{}", None, False),
    ("GitLab", "https://gitlab.com/{}", None, False),
    ("Bitbucket", "https://bitbucket.org/{}/", None, False),
    ("Codeberg", "https://codeberg.org/{}", None, False),
    ("Reddit", "https://www.reddit.com/user/{}/about.json", None, False),
    ("Hacker News", "https://news.ycombinator.com/user?id={}", "No such user", False),
    ("X / Twitter", "https://x.com/{}", None, True),
    ("Instagram", "https://www.instagram.com/{}/", None, True),
    ("TikTok", "https://www.tiktok.com/@{}", "Couldn't find this account", False),
    ("Steam", "https://steamcommunity.com/id/{}", "The specified profile could not be found", False),
    ("Pinterest", "https://www.pinterest.com/{}/", None, False),
    ("Twitch", "https://www.twitch.tv/{}", None, True),
    ("YouTube", "https://www.youtube.com/@{}", None, False),
    ("Medium", "https://medium.com/@{}", None, False),
    ("DEV", "https://dev.to/{}", None, False),
    ("Keybase", "https://keybase.io/{}", None, False),
    ("SoundCloud", "https://soundcloud.com/{}", None, False),
    ("Behance", "https://www.behance.net/{}", None, False),
    ("Dribbble", "https://dribbble.com/{}", None, False),
    ("Flickr", "https://www.flickr.com/people/{}", None, False),
    ("Vimeo", "https://vimeo.com/{}", None, False),
    ("Patreon", "https://www.patreon.com/{}", None, False),
    ("Replit", "https://replit.com/@{}", None, False),
    ("npm", "https://www.npmjs.com/~{}", None, False),
    ("PyPI", "https://pypi.org/user/{}/", None, False),
    ("Docker Hub", "https://hub.docker.com/u/{}", None, True),
    ("Gravatar", "https://gravatar.com/{}", None, False),
    ("About.me", "https://about.me/{}", None, False),
    ("Linktree", "https://linktr.ee/{}", None, False),
    ("Mastodon.social", "https://mastodon.social/@{}", None, False),
    ("Chess.com", "https://www.chess.com/member/{}", None, False),
    ("Lichess", "https://lichess.org/@/{}", None, False),
    ("Snapchat", "https://www.snapchat.com/add/{}", None, False),
    ("Kaggle", "https://www.kaggle.com/{}", None, False),
    ("LeetCode", "https://leetcode.com/{}/", None, False),
    ("CodePen", "https://codepen.io/{}", None, False),
    ("Wikipedia", "https://en.wikipedia.org/wiki/User:{}", None, False),
    ("Imgur", "https://imgur.com/user/{}", None, False),
    ("Pastebin", "https://pastebin.com/u/{}", None, False),
    ("Spotify", "https://open.spotify.com/user/{}", None, True),
]


def _check(site, username):
    name, tpl, miss, weak = site
    url = tpl.format(username)
    try:
        r = requests.get(url, headers=UA, timeout=8, allow_redirects=True)
    except Exception:
        return {"site": name, "url": url, "status": "error"}
    if r.status_code in (404, 410):
        st = "not_found"
    elif r.status_code == 200:
        if miss and miss.lower() in r.text.lower():
            st = "not_found"
        else:
            st = "possible" if weak else "found"
    else:
        st = "unknown"
    return {"site": name, "url": url, "status": st}


def username_scan(username):
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,40}", username or ""):
        return json.dumps({"error": "Username may contain letters, digits, . _ - (max 40)."})
    with ThreadPoolExecutor(max_workers=16) as ex:
        results = list(ex.map(lambda s: _check(s, username), SITES))
    return json.dumps(results)


def phone_info(number, region=None):
    import phonenumbers
    from phonenumbers import PhoneNumberType as T, carrier, geocoder, timezone
    try:
        n = phonenumbers.parse(number, region or None)
    except Exception as e:
        return json.dumps({"error": str(e)})
    names = {
        T.FIXED_LINE: "Landline", T.MOBILE: "Mobile", T.FIXED_LINE_OR_MOBILE: "Landline or mobile",
        T.TOLL_FREE: "Toll free", T.PREMIUM_RATE: "Premium rate", T.SHARED_COST: "Shared cost",
        T.VOIP: "VoIP", T.PERSONAL_NUMBER: "Personal", T.PAGER: "Pager", T.UAN: "UAN",
        T.VOICEMAIL: "Voicemail", T.UNKNOWN: "Unknown",
    }
    f = phonenumbers.PhoneNumberFormat
    return json.dumps({
        "valid": phonenumbers.is_valid_number(n),
        "possible": phonenumbers.is_possible_number(n),
        "e164": phonenumbers.format_number(n, f.E164),
        "international": phonenumbers.format_number(n, f.INTERNATIONAL),
        "national": phonenumbers.format_number(n, f.NATIONAL),
        "country_code": n.country_code,
        "region": phonenumbers.region_code_for_number(n),
        "location": geocoder.description_for_number(n, "en"),
        "carrier": carrier.name_for_number(n, "en"),
        "line_type": names.get(phonenumbers.number_type(n), "Unknown"),
        "timezones": list(timezone.time_zones_for_number(n)),
    })
