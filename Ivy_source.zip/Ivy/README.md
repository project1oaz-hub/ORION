# Ivy: local-first Android recon + assistant

Kotlin · Jetpack Compose · Room + SQLCipher · Chaquopy (Python) · Gemini / Groq · Shizuku · Accessibility

## Build the APK
1. Open this folder in **Android Studio (Koala+)**, JDK 17, Android SDK 35. Let Gradle sync (first sync downloads Gradle 8.9, Chaquopy and pip wheels, so it needs internet).
2. Chaquopy needs a **Python 3.8+ on your PATH** at build time (`python3`).
3. `Build ▸ Build APK(s)`, or `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.
4. Install, open **Settings** (drawer), paste a **Gemini and/or Groq API key**. Keys are encrypted with an Android Keystore key.

## Layers
`data` Room/SQLCipher, KeyVault, SettingsStore · `domain` AssistantOrchestrator, ToolRegistry, models ·
`engine` Net, Recon scanners, PyBridge (+ `python/ivy_recon.py`), LLM clients, audio · `system` Accessibility, Shizuku, Device · `ui` Compose + ViewModel

## Flow
Input → `AssistantOrchestrator` → model with function declarations → either a text reply, or a tool call
(recon / device) → status line + result card saved to the DB → result fed back → plain-language summary (stored on the scan row).
Voice: record (silence-detected WAV) → Groq Whisper or Gemini → orchestrator → Android TTS → repeat.

## Notes
- Optional keys (HIBP, VirusTotal) are in Settings → *Recon keys*.
- Username search is a built-in Sherlock-style engine (Python/requests, ~40 sites). X, Instagram, Twitch, Docker Hub, Spotify serve a page for any name, so they're reported as "possible".
- WHOIS uses RDAP, DNS uses DNS-over-HTTPS, subdomains use crt.sh.
- Attach files with **+** (image EXIF, hashes, reverse-image helper).
- `shell_command` always asks for confirmation. `read_screen` sends on-screen text to your AI provider.
- Port scan / recon: only on assets you own or are authorized to test.
- Enable Accessibility in system settings; start Shizuku and grant permission from Ivy's Settings.
- Sources were not compiled in the authoring environment: expect to fix small compile issues on first sync.
