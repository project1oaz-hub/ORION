# EDITH Android Assistant

## Voice upgrades in this package
- Offline wake-word detection uses the existing local Vosk recognizer (no cloud call is needed to detect “Hey EDITH”). The wake service now debounces duplicate detections and retries after recognition timeouts/errors.
- Voice interruption uses adaptive energy-based voice activity detection while EDITH speaks, with Android echo cancellation/noise suppression where supported. Some Android devices prohibit simultaneous microphone capture and playback; tap-to-interrupt remains the fallback.
- Screen awareness uses the existing Android Accessibility Service when a screen-reading action is explicitly requested. Password fields and their child content are excluded from text collection. Android requires the user to enable the accessibility service manually in Settings.

## Build
Upload this ZIP as `EDITH-Upgrade.zip` to the root of the GitHub repository and save the workflow as `.github/workflows/build.yml`. Run the **Build EDITH APK** workflow. Download the `EDITH-debug-APK` artifact from a successful run.

## Notes
This is a source update, not a claim of a tested release APK. Run the GitHub build and test wake detection, interruption, and screen reading on the target phone. The Vosk model is downloaded on first run by the existing ModelManager.
