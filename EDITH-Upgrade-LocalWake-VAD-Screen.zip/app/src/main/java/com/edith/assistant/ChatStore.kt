package com.edith.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Chat(val id: String, val title: String, val updated: Long, val msgs: List<Msg>)

/** Saved chats ("Recent" in the drawer). Stored on the phone only. */
object ChatStore {
    private var sp: SharedPreferences? = null
    val chats = mutableStateListOf<Chat>()
    var currentId by mutableStateOf<String?>(null)

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("edith_chats", Context.MODE_PRIVATE)
        sp = p
        try {
            val arr = JSONArray(p.getString("chats", "[]"))
            val list = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val m = o.getJSONArray("m")
                Chat(o.getString("id"), o.getString("t"), o.getLong("u"),
                    (0 until m.length()).map { Msg(m.getJSONObject(it).getString("r"), m.getJSONObject(it).getString("x")) })
            }
            chats.clear()
            chats.addAll(list.sortedByDescending { it.updated })
        } catch (e: Exception) {}
    }

    private fun persist() {
        val arr = JSONArray()
        chats.forEach { c ->
            val m = JSONArray()
            c.msgs.forEach { m.put(JSONObject().put("r", it.role).put("x", it.text)) }
            arr.put(JSONObject().put("id", c.id).put("t", c.title).put("u", c.updated).put("m", m))
        }
        sp?.edit()?.putString("chats", arr.toString())?.apply()
    }

    fun saveCurrent(ctx: Context) {
        init(ctx)
        val h = Assistant.history.toList()
        if (h.isEmpty()) return
        val id = currentId ?: java.util.UUID.randomUUID().toString().also { currentId = it }
        val title = h.firstOrNull { it.role == "user" }?.text?.take(40) ?: "New chat"
        val chat = Chat(id, title, System.currentTimeMillis(), h.takeLast(200))
        val i = chats.indexOfFirst { it.id == id }
        if (i >= 0) chats.removeAt(i)
        chats.add(0, chat)
        while (chats.size > 100) chats.removeAt(chats.size - 1)
        persist()
    }

    fun open(id: String) {
        val c = chats.firstOrNull { it.id == id } ?: return
        Assistant.history.clear()
        Assistant.history.addAll(c.msgs)
        currentId = id
    }

    fun newChat() { Assistant.history.clear(); currentId = null }

    fun delete(id: String) {
        chats.removeAll { it.id == id }
        if (currentId == id) newChat()
        persist()
    }

    fun clearCurrent() {
        val id = currentId
        if (id != null) delete(id) else Assistant.history.clear()
    }
}
