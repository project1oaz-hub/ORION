package com.edith.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

object Actions {
    private var torchOn = false

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Returns a reply if the text was a device command, else null. */
    fun handle(ctx: Context, raw: String): String? {
        var t = raw.lowercase().trim().trimEnd('.', '!', '?')
        t = t.replace(Regex("^((hey )?edith[, ]*|please |can you |could you |will you )+"), "").trim()
        if (t.length < 40 && Regex("\\b(flash ?light|torch)\\b").containsMatchIn(t)) return torch(ctx, t)
        usernameCommand(ctx, t)?.let { return it }
        smartCommands(ctx, t)?.let { return it }
        Regex("^(call|phone|dial|ring)\\s+(.+)$").find(t)?.let { return call(ctx, it.groupValues[2]) }
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let { return open(ctx, it.groupValues[2]) }
        return null
    }

    private val STOP = setOf("my", "me", "your", "the", "a", "an", "his", "her", "their", "this", "that", "our", "user", "everyone", "someone")

    private fun spokenHandle(s: String): String {
        var x = s.lowercase().trim().trim('\'', '"', '\u2018', '\u2019', '\u201C', '\u201D')
        x = x.replace(" underscore ", "_").replace(" dot ", ".").replace(" dash ", "-").replace(" hyphen ", "-")
        return x.removePrefix("@").replace(" ", "")
    }

    /** "check the username xyz" / "show me xyz profile" opens the Username check screen with xyz filled in. */
    private fun usernameCommand(ctx: Context, t: String): String? {
        val explicit = Regex("^(?:check|search|find|look ?up|show me|show|run)\\s+(?:the\\s+)?(?:username|user name|handle)\\s+(.+?)(?:'s)?(?:\\s+(?:profiles?|accounts?|footprint))?$").find(t)
        val single = Regex("^show me\\s+(\\S+?)(?:'s)?\\s+(?:profiles?|accounts?)$").find(t)
        val raw = explicit?.groupValues?.get(1) ?: single?.groupValues?.get(1) ?: return null
        if (explicit == null) {
            // "show me X profile" is a username only when it is quoted, @-prefixed or has digits/underscores/dots.
            // Plain words (e.g. a famous person's name) go to the AI instead.
            val looksLikeHandle = raw.firstOrNull() in listOf('\'', '"', '\u2018', '\u201C', '@') || raw.any { it.isDigit() || it == '_' || it == '.' }
            if (!looksLikeHandle || raw.lowercase() in STOP) return null
        }
        val name = spokenHandle(raw)
        if (!Osint.VALID.matches(name)) return "That doesn't look like a valid username. Usernames can use letters, numbers, dots, dashes and underscores."
        if (Osint.liveActive) {
            Osint.liveQuery = Osint.LiveReq(name, System.nanoTime())
            return "Checking $name on public sites. Results will show on screen."
        }
        Osint.pendingUser = name
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("osint", name))
        } catch (e: Exception) {}
        return "Opening the username check for $name. Tap Search once the spelling looks right."
    }

    /** Natural phrasings: "get me on instagram", "let me talk to mom", "search messi on youtube", "search messi" (in the current app). */
    private fun smartCommands(ctx: Context, t: String): String? {
        if (Regex("^(?:what(?:'s| is) (?:this|that|in front of me)|what am i (?:looking|pointing) at|identify this|scan this|look at this|tell me what this is|what do you see)$").containsMatchIn(t)) {
            if (Vision.liveCamera) return null   // Live already attaches the camera frame; the AI answers from it
            if (Osint.liveActive) {
                Vision.liveAsk = Vision.LiveAsk(Vision.DEFAULT, System.nanoTime())
                return "Let me take a look."
            }
            Vision.pendingPrompt = Vision.DEFAULT
            try {
                ctx.startActivity(Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("camera", true))
            } catch (e: Exception) {}
            return "Opening the camera."
        }
        Regex("^(?:search for|search|find|look up)\\s+(.+?)\\s+(?:on|in)\\s+(youtube|spotify|google maps|maps|google|play store|reddit|wikipedia|amazon|comet)$").find(t)?.let {
            val key = Phone.appKey(it.groupValues[2]).ifBlank { "google" }
            return Phone.inAppSearch(ctx, key, it.groupValues[1]).msg
        }
        Regex("^play\\s+(.+?)\\s+(?:on|in)\\s+(youtube|spotify)$").find(t)?.let {
            return Phone.inAppSearch(ctx, it.groupValues[2], it.groupValues[1], true).msg
        }
        Regex("^(?:search for|search|look up)\\s+(.+)$").find(t)?.let {
            val key = Phone.appKey(Phone.currentApp())
            if (key.isNotEmpty()) return Phone.inAppSearch(ctx, key, it.groupValues[1]).msg
        }
        Regex("^(?:let me (?:talk|speak) to|i (?:want|wanna|would like|'d like) to (?:talk|speak) to|(?:talk|speak) to|connect me (?:to|with)|put me through to|get me through to|ring up|call up|make a call to|give a call to)\\s+(.+)$").find(t)?.let {
            val n = it.groupValues[1].trim()
            if (n.any { c -> c.isLetter() }) {
                if (!has(ctx, Manifest.permission.READ_CONTACTS)) return call(ctx, n)
                if (lookup(ctx, n) == null) return null
            }
            return call(ctx, n)
        }
        Regex("^(?:run|fire up|bring up|go to|take me to|get me on|get me onto|get me to|switch to|jump to|pull up)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(t)?.let {
            val r = open(ctx, it.groupValues[1])
            return if (r.startsWith("Opening") || r.startsWith("I couldn't open")) r else null
        }
        return null
    }

    private fun torch(ctx: Context, t: String): String {
        val on = when {
            Regex("\\b(off|disable|stop)\\b").containsMatchIn(t) -> false
            Regex("\\b(on|enable|start)\\b").containsMatchIn(t) -> true
            else -> !torchOn
        }
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone doesn't have a flashlight."
        return try {
            cm.setTorchMode(id, on)
            torchOn = on
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't control the flashlight."
        }
    }

    internal fun lookup(ctx: Context, name: String): String? {
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    fun call(ctx: Context, name: String): String {
        val n = name.trim()
        val number: String
        if (n.none { it.isLetter() } && n.count { it.isDigit() } >= 5) {
            number = n.filter { it.isDigit() || it == '+' }
        } else {
            if (!has(ctx, Manifest.permission.READ_CONTACTS)) return "Please grant contacts permission to EDITH."
            number = lookup(ctx, n) ?: return "I couldn't find $n in your contacts."
        }
        val action = if (has(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return try {
            ctx.startActivity(Intent(action, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Calling $n."
        } catch (e: Exception) {
            "I couldn't place the call."
        }
    }

    /** (label, package) of the installed launcher app best matching [name]. */
    fun findApp(ctx: Context, name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val q = name.lowercase().trim().removePrefix("the ").removeSuffix(" app").trim()
        return apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.first.lowercase().contains(q) }
    }

    fun open(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val q = name.lowercase().trim().removePrefix("the ").removeSuffix(" app").trim()
        val hit = apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.first.lowercase().contains(q) }
            ?: return "I couldn't find an app called $name."
        val i = pm.getLaunchIntentForPackage(hit.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "I can't open ${hit.first}."
        return try {
            ctx.startActivity(i)
            Phone.noteApp(hit.first)
            "Opening ${hit.first}."
        } catch (e: Exception) {
            "I couldn't open ${hit.first}. Enable 'Display over other apps' for EDITH in Settings."
        }
    }
}
