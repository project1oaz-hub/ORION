package com.edith.assistant

import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream

/** A camera preview that starts/stops with [enabled]. Show it with AndroidView and read frames with [grabJpeg]. */
@Composable
fun CameraFeed(enabled: Boolean, onError: (String) -> Unit): PreviewView {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val pv = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    DisposableEffect(enabled) {
        val future = ProcessCameraProvider.getInstance(ctx)
        if (enabled) {
            future.addListener({
                try {
                    val provider = future.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                } catch (e: Exception) { onError("Camera error: ${e.message}") }
            }, ContextCompat.getMainExecutor(ctx))
        }
        onDispose { try { if (future.isDone) future.get().unbindAll() } catch (e: Exception) {} }
    }
    return pv
}

/** Current camera frame as a small JPEG (null if the camera isn't showing yet). */
fun grabJpeg(pv: PreviewView): ByteArray? {
    val b = pv.bitmap ?: return null
    val k = 1024f / maxOf(b.width, b.height)
    val sc = if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true) else b
    val out = ByteArrayOutputStream()
    sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
    return out.toByteArray()
}
