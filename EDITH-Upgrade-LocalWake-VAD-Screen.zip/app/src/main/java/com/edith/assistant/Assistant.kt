package com.edith.assistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import org.json.JSONObject

data class Msg(val role: String, val text: String)

object Assistant {
    val history = mutableStateListOf<Msg>()
    var busy by mutableStateOf(false)
    private val TAG = Regex("\\[\\[do:\\s*(\\{.*?\\})\\s*\\]\\]", RegexOption.DOT_MATCHES_ALL)

    /** Call on the main thread. */
    suspend fun respond(ctx: Context, text: String, spoken: Boolean = false, image: ByteArray? = null): String {
        ChatStore.init(ctx)
        history.add(Msg("user", text))
        busy = true
        val reply = try {
            Actions.handle(ctx, text) ?: converse(ctx, spoken, image)
        } catch (e: Exception) {
            "Sorry, something went wrong. ${e.message}"
        }
        history.add(Msg("assistant", reply))
        busy = false
        ChatStore.saveCurrent(ctx)
        return reply
    }

    /** Ask the AI; run any action tags it emits; for screen actions, loop (max 8 steps) so it can see and continue. */
    private suspend fun converse(ctx: Context, spoken: Boolean, image: ByteArray?): String {
        val convo = history.takeLast(20).toMutableList()
        var last = ""
        val problems = mutableListOf<String>()
        var steps = 0
        while (true) {
            val raw = try { Ai.chat(convo, spoken, if (steps == 0) image else null) } catch (e: Exception) { return "Sorry, I couldn't reach the AI. ${e.message}" }
            val tags = TAG.findAll(raw).map { it.groupValues[1] }.toList()
            val clean = raw.replace(TAG, "").trim()
            if (clean.isNotBlank()) last = clean
            if (tags.isEmpty()) break
            val results = StringBuilder()
            var more = false
            var opened = false
            var needObs = false
            for (t in tags) {
                try {
                    val j = JSONObject(t)
                    val r = if (j.optString("type") == "screen") Phone.screen() else Phone.run(ctx, j)
                    results.append(r.msg).append('\n')
                    if (!r.ok) problems.add(r.msg)
                    if (j.optString("type") in Phone.screenTypes) more = true
                    if (j.optString("type") in Phone.screenTypes && j.optString("type") != "screen") needObs = true
                    if (j.optString("type") == "open") opened = true
                } catch (e: Exception) {
                    results.append("Bad action.\n")
                }
            }
            if (!more || ++steps >= 8) break
            delay(if (opened) 1800L else 900L)
            convo.add(Msg("assistant", raw))
            convo.add(Msg("user", "[system] Action results: $results" + (if (needObs) "\nCurrent screen:\n${Phone.observe()}" else "") + "\nContinue the task, or give a short final reply with no action tags if finished."))
        }
        var out = last.ifBlank { "Done." }
        if (problems.isNotEmpty()) out += "\n" + problems.joinToString(" ")
        return out
    }
}
