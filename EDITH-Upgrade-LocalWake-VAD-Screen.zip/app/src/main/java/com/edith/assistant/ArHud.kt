package com.edith.assistant

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.asin
import kotlin.math.atan2

/** Compact heads-up display for Live camera mode: reticle, horizon, compass, time/battery/heading. */
@Composable
fun ArHud() {
    val ctx = LocalContext.current
    var heading by remember { mutableStateOf(0f) }
    var pitch by remember { mutableStateOf(0f) }
    var roll by remember { mutableStateOf(0f) }
    var clock by remember { mutableStateOf("") }
    var battery by remember { mutableStateOf(0) }

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(r, e.values)
                val east = -r[2]; val north = -r[5]; val up = -r[8]
                heading = ((Math.toDegrees(atan2(east.toDouble(), north.toDouble())) + 360.0) % 360.0).toFloat()
                pitch = Math.toDegrees(asin(up.coerceIn(-1f, 1f).toDouble())).toFloat()
                roll = Math.toDegrees(atan2(r[6].toDouble(), r[7].toDouble())).toFloat()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }
    LaunchedEffect(Unit) {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (isActive) {
            clock = fmt.format(Date())
            battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            delay(1000)
        }
    }

    val names = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val a = Theme.accent
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val r = minOf(w, h) * 0.22f
            val len = r * 0.35f
            val sw = 3.dp.toPx()
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(a, Offset(x, y), Offset(x + dx * len, y), sw)
                drawLine(a, Offset(x, y), Offset(x, y + dy * len), sw)
            }
            corner(cx - r, cy - r, 1f, 1f); corner(cx + r, cy - r, -1f, 1f)
            corner(cx - r, cy + r, 1f, -1f); corner(cx + r, cy + r, -1f, -1f)
            val hy = cy + pitch * (h / 90f)
            rotate(roll, Offset(cx, cy)) {
                drawLine(Color.White.copy(alpha = 0.5f), Offset(cx - w * 0.38f, hy), Offset(cx - w * 0.08f, hy), 2.dp.toPx())
                drawLine(Color.White.copy(alpha = 0.5f), Offset(cx + w * 0.08f, hy), Offset(cx + w * 0.38f, hy), 2.dp.toPx())
            }
            val rc = Offset(w - 52.dp.toPx(), 150.dp.toPx())
            val rr = 26.dp.toPx()
            drawCircle(Color.White.copy(alpha = 0.5f), rr, rc, style = Stroke(2.dp.toPx()))
            rotate(-heading, rc) {
                val p = Path().apply {
                    moveTo(rc.x, rc.y - rr)
                    lineTo(rc.x - 6.dp.toPx(), rc.y - rr + 14.dp.toPx())
                    lineTo(rc.x + 6.dp.toPx(), rc.y - rr + 14.dp.toPx())
                    close()
                }
                drawPath(p, Color(0xFFF28B82))
            }
            drawCircle(a, 3.dp.toPx(), rc)
        }
        Text(
            "$clock  ·  $battery%  ·  ${names[(((heading + 22.5f) / 45f).toInt()) % 8]} ${heading.toInt()}°  ·  tilt ${pitch.toInt()}°",
            color = Theme.accent, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 96.dp)
        )
    }
}
