package com.edith.assistant

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Vision {
    const val DEFAULT = "Identify what is in view and describe it briefly. Read any visible text."

    /** Set by a voice/chat command; the camera screen picks it up and asks it automatically. */
    var pendingPrompt by mutableStateOf<String?>(null)

    data class LiveAsk(val prompt: String, val id: Long)

    /** A "look at this" request made while Live is open: Live turns its camera on and answers without leaving. */
    var liveAsk by mutableStateOf<LiveAsk?>(null)

    /** True while Live's camera is on (a frame is attached to every question). */
    @Volatile var liveCamera = false
}
