package com.edith.assistant

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Floating card with public profile links for a well-known public figure. Works over Chat and Live. */
@Composable
fun BoxScope.ProfileCardView(card: Osint.Card, bottomPad: Dp, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Surface(
        shape = RoundedCornerShape(24.dp), color = Panel,
        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = bottomPad)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(card.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    Text("Handles come from the AI's knowledge and can be out of date. Check before relying on them.", color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Muted) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                card.links.forEach { l ->
                    Surface(shape = RoundedCornerShape(18.dp), color = Bubble, modifier = Modifier.clickable {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(l.url))) } catch (e: Exception) {}
                    }) { Text(l.site, color = Theme.accent, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
                }
            }
        }
    }
}
