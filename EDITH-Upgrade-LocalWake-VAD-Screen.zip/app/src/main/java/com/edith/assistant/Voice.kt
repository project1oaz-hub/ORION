package com.edith.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.runBlocking
import java.util.Locale

class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var tts: TextToSpeech? = null
    private var current: SpeechRecognizer? = null
    private var listenCb: ((String?) -> Unit)? = null
    private var pendingDone: (() -> Unit)? = null
    private var speakId = 0
    private var track: AudioTrack? = null
    var lastError = 0
    @Volatile private var bargeIn = false
    @Volatile private var bargeThread: Thread? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.language = Locale.getDefault()
        }
    }

    companion object {
        fun errorText(c: Int): String = when (c) {
            -1 -> "No speech recognition service found. Install or enable the Google app."
            1 -> "Network timeout. Speech recognition needs internet."
            2 -> "Network error. Check your connection."
            3 -> "Audio problem. Another app may be using the microphone."
            4 -> "Speech server error. Try again."
            5 -> "Speech service error."
            6 -> "I didn't hear anything."
            7 -> "I couldn't understand that."
            8 -> "Speech recogniser is busy. Try again."
            9 -> "Microphone permission is missing. Allow it in app settings."
            else -> "Speech error $c"
        }
    }

    private fun finish() { val d = pendingDone; pendingDone = null; d?.invoke() }

    private fun stopQuiet() {
        speakId++
        tts?.stop()
        track?.let { try { it.stop() } catch (e: Exception) {}; it.release() }
        track = null
    }

    /** Speaks text; [done] fires once when finished OR interrupted. [fast] forces the instant phone voice. */
    fun speak(text: String, fast: Boolean = false, done: () -> Unit = {}) {
        stopQuiet()
        pendingDone = done
        val id = ++speakId
        if (!fast && Prefs.naturalVoice && Prefs.geminiKey.isNotBlank()) {
            val clean = text.replace(Regex("[*_#`]"), "").take(700)
            Thread {
                val pcm = try { runBlocking { Ai.tts(clean) } } catch (e: Exception) { null }
                main.post {
                    if (id == speakId) { if (pcm != null) play(pcm, id, text) else sys(text, id) }
                }
            }.start()
        } else sys(text, id)
    }

    fun stopSpeaking() { stopQuiet(); finish() }
    fun shutdown() { stopBargeIn(); cancelListen(); stopSpeaking(); tts?.shutdown() }

    private fun sys(text: String, id: Int) {
        val t = tts
        if (t == null || !ready) { finish(); return }
        val uid = id.toString()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { main.post { if (id == speakId && u == uid) finish() } }
            override fun onStop(u: String?, interrupted: Boolean) { main.post { if (id == speakId && u == uid) finish() } }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { main.post { if (id == speakId && u == uid) finish() } }
        })
        t.setSpeechRate(Prefs.rate)
        t.setPitch(Prefs.pitch)
        t.speak(text.replace(Regex("[*_#`]"), "").take(3500), TextToSpeech.QUEUE_FLUSH, null, uid)
    }

    private fun play(pcm: Pcm, id: Int, text: String) {
        try {
            val frames = pcm.bytes.size / 2
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(pcm.rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.bytes.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm.bytes, 0, pcm.bytes.size)
            t.setNotificationMarkerPosition((frames - 1).coerceAtLeast(1))
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(a: AudioTrack?) {
                    if (id == speakId && track === t) { track = null; try { t.release() } catch (e: Exception) {}; finish() }
                }
                override fun onPeriodicNotification(a: AudioTrack?) {}
            }, main)
            track = t
            t.play()
            // safety net in case the marker never fires
            main.postDelayed({
                if (id == speakId && track === t) { track = null; try { t.stop(); t.release() } catch (e: Exception) {}; finish() }
            }, frames * 1000L / pcm.rate + 1000)
        } catch (e: Exception) {
            sys(text, id)
        }
    }


    /**
     * Best-effort full-duplex barge-in for Live mode. A lightweight PCM monitor runs
     * while EDITH speaks; sustained near-end voice activity stops playback immediately.
     * Android/device echo cancellation is enabled when available. Always call stopBargeIn()
     * when speech finishes or the Live screen closes.
     */
    fun startBargeIn(onInterrupt: () -> Unit) {
        stopBargeIn()
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        bargeIn = true
        bargeThread = Thread {
            val rate = 16000
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) { bargeIn = false; return@Thread }
            var recorder: AudioRecord? = null
            var aec: AcousticEchoCanceler? = null
            var ns: NoiseSuppressor? = null
            try {
                recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096))
                if (recorder.state != AudioRecord.STATE_INITIALIZED) return@Thread
                if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(recorder.audioSessionId)?.also { it.enabled = true }
                if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(recorder.audioSessionId)?.also { it.enabled = true }
                val buf = ShortArray(1024)
                var voicedFrames = 0
                var warmup = 0
                var noiseFloor = 450.0
                recorder.startRecording()
                while (bargeIn && !Thread.currentThread().isInterrupted) {
                    val n = recorder.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    var sum = 0.0
                    for (i in 0 until n) { val v = buf[i].toDouble(); sum += v * v }
                    val rms = kotlin.math.sqrt(sum / n)
                    warmup++
                    // Adaptive energy VAD: track quiet-room noise, then require a clear
                    // near-end speech rise for several frames to reduce false barge-ins.
                    if (warmup < 10 || rms < noiseFloor * 1.35) {
                        noiseFloor = (noiseFloor * 0.94 + rms * 0.06).coerceIn(100.0, 2200.0)
                    }
                    val threshold = maxOf(1150.0, noiseFloor * 2.8)
                    if (warmup > 8 && rms > threshold) voicedFrames++ else voicedFrames = maxOf(0, voicedFrames - 1)
                    if (voicedFrames >= 5) {
                        bargeIn = false
                        main.post { onInterrupt() }
                        break
                    }
                }
            } catch (_: Exception) {
                // Some devices don't allow concurrent capture; Live remains usable via tap-to-stop.
            } finally {
                try { recorder?.stop() } catch (_: Exception) {}
                try { recorder?.release() } catch (_: Exception) {}
                try { aec?.release() } catch (_: Exception) {}
                try { ns?.release() } catch (_: Exception) {}
            }
        }.apply { name = "EDITH-BargeIn"; isDaemon = true; start() }
    }

    fun stopBargeIn() {
        bargeIn = false
        bargeThread?.interrupt()
        bargeThread = null
    }

    fun cancelListen() {
        main.post {
            val cb = listenCb
            listenCb = null
            try { current?.destroy() } catch (e: Exception) {}
            current = null
            if (cb != null) { lastError = 0; cb(null) }
        }
    }

    /** One-shot speech recognition. Callback gets null on failure/silence; see [lastError]. */
    fun listen(onResult: (String?) -> Unit) { main.post { start(0, onResult) } }

    private fun start(i: Int, onResult: (String?) -> Unit) {
        val comps = listOf<ComponentName?>(null) + listOfNotNull(Recognizers.find(ctx))
        if (i >= comps.size) { lastError = -1; onResult(null); return }
        if (comps[i] == null && !SpeechRecognizer.isRecognitionAvailable(ctx)) { start(i + 1, onResult); return }
        val comp = comps[i]
        val r = if (comp != null) SpeechRecognizer.createSpeechRecognizer(ctx, comp) else SpeechRecognizer.createSpeechRecognizer(ctx)
        current = r
        listenCb = onResult
        var partial: String? = null
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val candidates = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val t = candidates?.firstOrNull { it.isNotBlank() } ?: partial
                r.destroy(); if (current === r) current = null
                lastError = if (t.isNullOrBlank()) 7 else 0
                listenCb = null
                onResult(t)
            }
            override fun onError(e: Int) {
                r.destroy(); if (current === r) current = null
                if (e == SpeechRecognizer.ERROR_CLIENT && i + 1 < comps.size) start(i + 1, onResult)
                else {
                    // Preserve useful partial words on silence/no-match rather than discarding them.
                    val recovered = if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) partial else null
                    lastError = if (!recovered.isNullOrBlank()) 0 else e
                    listenCb = null
                    onResult(recovered)
                }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {
                partial = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull { it.isNotBlank() } ?: partial
            }
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        )
    }
}
