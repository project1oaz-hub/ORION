package com.edith.assistant

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun OsintScreen(voice: Voice, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(true) { onBack() }
    var user by remember { mutableStateOf(Osint.pendingUser ?: "") }
    LaunchedEffect(Unit) { Osint.pendingUser = null }
    var job by remember { mutableStateOf<Job?>(null) }
    var status by remember { mutableStateOf("") }
    val hits = remember { mutableStateListOf<Osint.Hit>() }
    val running = job?.isActive == true

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Grad("Username check", 22)
        }
        Surface(shape = RoundedCornerShape(16.dp), color = Panel) {
            Text(
                "Checks whether a username has a public profile on hundreds of sites (WhatsMyName dataset). " +
                    "Use it for your own accounts, brand protection, or someone who has agreed to it. " +
                    "Results can include false positives, and a match may just be a different person with the same username. " +
                    "Don't use it to track, harass or profile anyone.",
                color = Muted, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(14.dp)
            )
        }
        Field("Username (no @)", user) { user = it.trim() }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(enabled = !running && Osint.VALID.matches(user), onClick = {
                hits.clear()
                status = "Downloading site list…"
                job = scope.launch {
                    try {
                        Osint.search(user, { d, t -> status = "Checked $d of $t sites" }, { hits.add(it) })
                        status = "Done. ${hits.size} possible profiles found."
                        if (Prefs.speak) voice.speak(Osint.summary(user, hits.toList()))
                    } catch (e: Exception) {
                        status = e.message ?: "Search failed."
                    }
                }
            }) { Text("Search") }
            if (running) OutlinedButton(onClick = { job?.cancel(); status = "Stopped. ${hits.size} found so far." }) { Text("Stop") }
        }
        if (status.isNotEmpty()) Text(status, color = Muted, fontSize = 13.sp)
        hits.forEach { h ->
            Column(Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(h.url))) } catch (e: Exception) {}
            }.padding(vertical = 6.dp)) {
                Text(h.site, color = Color.White, fontSize = 16.sp)
                Text(h.url, color = Theme.accent, fontSize = 12.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
