package com.edith.assistant

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Username footprint check using the public WhatsMyName dataset.
 * It only asks each site whether a profile URL for that exact username exists. No names, no faces.
 */
object Osint {
    data class Hit(val site: String, val url: String)

    private const val DATA = "https://raw.githubusercontent.com/WebBreacher/WhatsMyName/main/wmn-data.json"
    val VALID = Regex("^[A-Za-z0-9._-]{2,40}$")

    /** Set by a voice/chat command; the Username check screen picks it up and pre-fills the box. */
    var pendingUser by mutableStateOf<String?>(null)

    data class ProfileLink(val site: String, val url: String)
    data class Card(val name: String, val links: List<ProfileLink>)
    data class LiveReq(val name: String, val id: Long)

    /** Public-figure profile card shown over Chat or Live. */
    var card by mutableStateOf<Card?>(null)

    /** A username check requested while Live is open runs inside Live instead of leaving it. */
    var liveQuery by mutableStateOf<LiveReq?>(null)
    @Volatile var liveActive = false

    suspend fun search(user: String, onProgress: (Int, Int) -> Unit, onHit: (Hit) -> Unit) {
        require(VALID.matches(user)) { "Usernames can only contain letters, numbers, dots, dashes and underscores." }
        val sites = withContext(Dispatchers.IO) {
            val txt = fetch(DATA, 20000, 4_000_000)?.second
            if (txt.isNullOrBlank()) error("Couldn't download the site list. Check your internet.")
            val arr = JSONObject(txt).getJSONArray("sites")
            (0 until arr.length()).map { arr.getJSONObject(it) }.filter {
                it.has("uri_check") && it.has("e_code") && !it.has("post_body") && it.optString("uri_check").startsWith("https")
            }
        }
        val total = sites.size
        var done = 0
        val sem = Semaphore(24)
        coroutineScope {
            sites.map { s ->
                async(Dispatchers.IO) {
                    sem.withPermit {
                        val hit = try { check(s, user) } catch (e: Exception) { null }
                        withContext(Dispatchers.Main) {
                            done++
                            onProgress(done, total)
                            if (hit != null) onHit(hit)
                        }
                    }
                }
            }.awaitAll()
        }
    }

    fun summary(name: String, hits: List<Hit>): String =
        if (hits.isEmpty()) "I didn't find any public profiles for $name."
        else "Done checking $name. I found ${hits.size} possible ${if (hits.size == 1) "profile" else "profiles"}, including " +
            hits.take(3).joinToString(", ") { it.site } + ". They're on screen. A match can be someone else using the same username."

    private fun check(s: JSONObject, user: String): Hit? {
        val url = s.getString("uri_check").replace("{account}", user)
        val r = fetch(url, 7000, 250_000) ?: return null
        val code = r.first
        val body = r.second
        val eStr = s.optString("e_string")
        val mStr = s.optString("m_string")
        if (code != s.optInt("e_code", 200)) return null
        if (eStr.isNotEmpty() && !body.contains(eStr)) return null
        if (mStr.isNotEmpty() && body.contains(mStr)) return null
        val pretty = s.optString("uri_pretty").ifBlank { s.getString("uri_check") }.replace("{account}", user)
        return Hit(s.optString("name"), pretty)
    }

    private fun fetch(url: String, timeout: Int, max: Int): Pair<Int, String>? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            val code = c.responseCode
            val stream = if (code in 200..399) c.inputStream else (c.errorStream ?: return Pair(code, ""))
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            while (total < max) {
                val n = stream.read(buf, 0, minOf(buf.size, max - total))
                if (n < 0) break
                out.write(buf, 0, n)
                total += n
            }
            return Pair(code, out.toString("UTF-8"))
        } finally {
            c.disconnect()
        }
    }
}
