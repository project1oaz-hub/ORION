# ORION — Omni-Responsive Intelligent Operation Network
**Version 0.3.0 · Chat UI refresh**

## Architecture decisions

- **Provider-flexible AI:** configure any provider endpoint, model, and key that supports an OpenAI-compatible `POST /chat/completions` request format. This does not mean every provider is compatible; custom adapters can be added later.
- **Low-cost first:** the app makes no AI requests until a key and endpoint are configured. Provider charges, rate limits and free tiers vary. Offline commands such as app launching and contact lookup do not require an AI API.
- **Device owner:** no voice biometrics in this version. The assistant treats the user of the enrolled app/device as its boss persona; it does not verify identity from the phrase or voice.
- **Wake word:** experimental foreground microphone service. Android may show a system microphone privacy indicator and persistent notification. Screen-off operation depends on Android version, OEM battery management, speech service behavior and permissions; this implementation does not guarantee reliable always-on detection.
- **Local history:** last 60 messages in app-private preferences, with `show memories`, `remember ...`, `forget ...`, and `clear chat history` commands. Local preference storage is not encrypted by this prototype.
- **Sensitive actions:** calling a contact presents a confirmation choice. `open <app name>` launches a matching installed app when Android allows it.

## Included

- Native Kotlin Android app (min SDK 26)
- ChatGPT/Gemini-inspired minimal dark chat UI: top bar, bottom message composer, mic/send controls, and Home/Chats/Settings navigation
- Navigation menu for new chat, saved-history view, AI setup, voice/wake-word settings, and memory management
- Tap-to-speak speech recognition and text-to-speech
- Configurable OpenAI-compatible chat-completions provider
- Local chat history and explicit personal memories
- Contact lookup and confirmed call/dial action
- App launch by visible app label
- Experimental `Hey ORION` foreground service
- GitHub Actions debug APK workflow

## UI notes

The v0.3 refresh removes the large center orb/dashboard layout and uses a near-black, text-first chat interface. The Chats view currently displays/reopens the locally stored conversation history; it is not yet a multi-thread conversation database. The Settings and voice options are native dialogs. The user-provided planet icon has not been embedded as a launcher asset in this ZIP because a standalone original image asset was not available in the source project.

## Build with GitHub

1. Download and extract this ZIP.
2. Create a new repository on GitHub.
3. Upload the **contents** of the extracted folder into the repository root, not the enclosing folder.
4. Commit/push to `main` or `master`.
5. Open **Actions** → **Build ORION APK**. You can also select **Run workflow**.
6. Open the successful run, download the `ORION-debug-apk` artifact, and extract it.
7. Install `app-debug.apk` on your Android phone. Android may ask you to permit installs from the browser/file manager.

The workflow uses Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3 and SDK 35. The first GitHub build is the real validation step; the ZIP has not been built on a device in this environment.

## Configure an AI provider

In ORION, tap **AI PROVIDER SETTINGS** and provide:
- Endpoint URL for a compatible chat-completions API
- Model name
- API key

Requests and recent chat context are sent to the configured provider. Don't commit API keys to GitHub or distribute a configured personal build. Keys are stored in app-private preferences for this prototype, not a secure backend vault. For public release, use your own authenticated backend, per-user rate limits, provider key protection, and privacy controls.

## Commands

- `call Alice` — finds a matching contact and asks you to choose dialer or direct call.
- `open YouTube` — attempts to launch a matching installed app.
- `remember I prefer concise answers`
- `show memories`
- `forget concise answers`
- `clear chat history`
- Other messages are sent to the configured AI provider.

## Wake-word caveats

Android apps cannot silently hide microphone usage indicators. The OS and device manufacturer control background microphone access. The current service repeatedly uses Android's general speech recognition, which is a proof of concept rather than robust low-power hotword detection. Some recognizers do not support long-running sessions and screen-off capture. For a reliable always-on experience, the next engineering step is an on-device keyword-spotting engine, foreground-service lifecycle handling, battery-exemption UX where appropriate, and tests on the target phone. Once “Hey ORION” is detected, this version opens the app; it does not yet automatically capture the command that follows.

## Before public release

- Use encrypted storage for private memories and give users review/delete/export controls.
- Move API credentials to a backend; add timeouts, rate limits and provider error handling.
- Add automated tests and test on actual target devices.
- Add a branded icon/logo, accessibility polish, privacy policy and release signing.
- Review Google Play policies and Android background execution rules.
