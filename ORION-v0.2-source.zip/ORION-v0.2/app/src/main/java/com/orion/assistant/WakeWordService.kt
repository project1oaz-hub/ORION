package com.orion.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Experimental wake-word implementation.
 *
 * This uses Android's general speech recognizer in repeated sessions. It is not a
 * low-power keyword spotter, and Android/OEM battery policies can stop it. It is
 * not guaranteed to work with the screen off on every device. A reliable production
 * build should use a dedicated on-device keyword spotting model and device testing.
 */
class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    @Volatile private var active = false
    private var sessionPending = false

    override fun onCreate() { super.onCreate(); createChannel() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification("Waiting for “Hey ORION”")
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(41, notification)
        active = true
        listenAgain()
        return START_STICKY
    }

    private fun listenAgain() {
        if (!active || sessionPending) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        try {
            sessionPending = true
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { sessionPending = false; scheduleNext() }
                override fun onResults(results: Bundle?) {
                    sessionPending = false
                    val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (phrase.contains("hey orion", ignoreCase = true)) {
                        active = false
                        val launch = Intent(this@WakeWordService, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra("wake_word_detected", true)
                        val notificationManager = getSystemService(NotificationManager::class.java)
                        notificationManager.notify(41, buildNotification("Wake word detected — tap to open ORION"))
                        try { startActivity(launch) } catch (_: Exception) {}
                        stopSelf()
                    } else scheduleNext()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(request)
        } catch (_: Exception) {
            sessionPending = false
            scheduleNext()
        }
    }

    private fun scheduleNext() {
        if (!active) return
        android.os.Handler(mainLooper).postDelayed({ listenAgain() }, 900)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("orion_mic", "ORION wake word", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Visible status for ORION's active microphone wake-word service"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "orion_mic") else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ORION wake word is active").setContentText(message)
            .setContentIntent(open).setOngoing(true).build()
    }

    override fun onDestroy() {
        active = false; sessionPending = false
        recognizer?.destroy(); recognizer = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
