package com.orion.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("orion_local", MODE_PRIVATE) }
    private val audioRequest = 301
    private val contactsRequest = 302
    private val callRequest = 303
    private val notificationRequest = 304
    private var pendingContact: String? = null
    private var pendingNumber: String? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        restoreHistory()
        if (savedInstanceState == null) appendMessage("ORION", "Systems online. Hello, boss. Tap the microphone or type a command.")
        handleWakeIntent(intent)
        requestInitialPermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    private fun handleWakeIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("wake_word_detected", false) == true) {
            status.text = "● WAKE WORD DETECTED"
            // The foreground notification remains visible while the mic service is running.
            appendMessage("ORION", "I'm here, boss. Tap the microphone to give your command.")
            intent.removeExtra("wake_word_detected")
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(Color.rgb(8, 15, 30))
        }
        root.addView(TextView(this).apply {
            text = "ORION"
            textSize = 30f
            setTextColor(Color.rgb(89, 215, 255))
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "OMNI-RESPONSIVE INTELLIGENT OPERATION NETWORK"
            textSize = 10f
            setTextColor(Color.LTGRAY)
        })
        status = TextView(this).apply {
            text = "● STANDBY"; textSize = 12f
            setTextColor(Color.rgb(100, 230, 170))
            setPadding(0, dp(12), 0, dp(10))
        }
        root.addView(status)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(chat); isFillViewport = true },
            LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply {
            hint = "Tell ORION what to do..."
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            maxLines = 3; setBackgroundColor(Color.rgb(22, 34, 54))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply { text = "🎙"; contentDescription = "Speak"; setOnClickListener { startOneShotListening() } })
        controls.addView(Button(this).apply { text = "SEND"; setOnClickListener { submitText() } })
        root.addView(controls)
        root.addView(Button(this).apply { text = "AI PROVIDER SETTINGS"; setOnClickListener { showAiSettings() } })
        root.addView(Button(this).apply { text = "ENABLE / RESTART HEY ORION"; setOnClickListener { enableWakeWord() } })
        root.addView(Button(this).apply { text = "STOP WAKE WORD"; setOnClickListener { stopService(Intent(this@MainActivity, WakeWordService::class.java)); status.text = "● STANDBY" } })
        setContentView(root)
    }

    private fun appendMessage(who: String, message: String) {
        runOnUiThread {
            val bubble = TextView(this).apply {
                text = "$who\n$message"; textSize = 15f
                setTextColor(if (who == "ORION") Color.rgb(220, 237, 255) else Color.WHITE)
                setBackgroundColor(if (who == "ORION") Color.rgb(20, 38, 62) else Color.rgb(28, 62, 82))
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            chat.addView(bubble, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
    }

    private fun submitText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        handleUserText(text)
    }

    private fun handleUserText(raw: String) {
        val text = raw.trim()
        appendMessage("BOSS", text); saveChat("user", text)
        status.text = "● PROCESSING"
        val lower = text.lowercase(Locale.ROOT)
        when {
            lower.startsWith("call ") -> callContact(text.substringAfter(" ").trim().trim('"', '\''))
            lower.startsWith("open ") -> openApp(text.substringAfter(" ").trim().trim('"', '\''))
            lower.startsWith("remember ") -> {
                val fact = text.substringAfter(" ").trim()
                val memories = prefs.getStringSet("memories", emptySet())!!.toMutableSet()
                memories.add(fact); prefs.edit().putStringSet("memories", memories).apply()
                reply("Understood, boss. I saved that memory on this device.")
            }
            lower.startsWith("forget ") -> {
                val target = text.substringAfter(" ").trim()
                val memories = prefs.getStringSet("memories", emptySet())!!.toMutableSet()
                memories.removeAll { it.contains(target, ignoreCase = true) }
                prefs.edit().putStringSet("memories", memories).apply()
                reply("I removed matching saved memories, if any.")
            }
            lower == "show memories" -> {
                val memories = prefs.getStringSet("memories", emptySet()) ?: emptySet()
                reply(if (memories.isEmpty()) "No saved memories yet." else "Saved memories:\n" + memories.joinToString("\n"))
            }
            lower == "clear chat history" -> {
                prefs.edit().remove("chat_history").apply()
                chat.removeAllViews()
                reply("Local chat history cleared.")
            }
            else -> askAi(text)
        }
    }

    private fun askAi(userText: String) {
        val key = prefs.getString("api_key", "") ?: ""
        val endpoint = prefs.getString("api_endpoint", "") ?: ""
        val model = prefs.getString("api_model", "") ?: ""
        if (key.isBlank() || endpoint.isBlank() || model.isBlank()) {
            reply("General AI is not configured yet. Open AI PROVIDER SETTINGS and add a compatible provider endpoint, model and key. Local commands still work.")
            return
        }
        val memories = prefs.getStringSet("memories", emptySet()) ?: emptySet()
        val stored = prefs.getString("chat_history", "[]") ?: "[]"
        worker.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                val messages = JSONArray()
                messages.put(JSONObject().put("role", "system").put("content",
                    "You are ORION, the user's personal AI assistant. Address the user as boss naturally. " +
                    "Be accurate and transparent about uncertainty. Do not claim you can access data you have not retrieved. " +
                    "Saved user memories (use only if relevant): " + memories.joinToString("; ")))
                val history = JSONArray(stored)
                for (i in maxOf(0, history.length() - 12) until history.length()) {
                    val item = history.optJSONObject(i) ?: continue
                    val role = item.optString("role")
                    if (role == "user" || role == "assistant")
                        messages.put(JSONObject().put("role", role).put("content", item.optString("content")))
                }
                messages.put(JSONObject().put("role", "user").put("content", userText))
                conn.outputStream.use {
                    it.write(JSONObject().put("model", model).put("messages", messages).toString().toByteArray(Charsets.UTF_8))
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("Provider returned HTTP $code: ${body.take(240)}")
                val answer = JSONObject(body).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
                saveChat("assistant", answer); reply(answer, save = false)
            } catch (e: Exception) {
                reply("I couldn't reach the configured AI provider. Check endpoint, model, key and connection. ${e.message ?: ""}")
            } finally { conn?.disconnect() }
        }
    }

    private fun callContact(name: String) {
        if (name.isBlank()) { reply("Who should I call, boss?"); return }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingContact = name
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), contactsRequest); return
        }
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        var foundName: String? = null; var number: String? = null
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
            val ni = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val pi = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val candidate = c.getString(ni) ?: continue
                if (candidate.equals(name, true)) { foundName = candidate; number = c.getString(pi); break }
            }
            if (number == null) {
                c.moveToPosition(-1)
                while (c.moveToNext()) {
                    val candidate = c.getString(ni) ?: continue
                    if (candidate.contains(name, true)) { foundName = candidate; number = c.getString(pi); break }
                }
            }
        }
        if (number == null) { reply("I couldn't find $name in your contacts."); return }
        // Use dialer by default; direct calls require explicit Android permission.
        pendingNumber = number
        android.app.AlertDialog.Builder(this)
            .setTitle("Call ${foundName ?: name}?")
            .setMessage("Choose whether to open the dialer or place a direct call.")
            .setNegativeButton("Cancel") { _, _ -> pendingNumber = null; reply("Call cancelled.") }
            .setNeutralButton("Open dialer") { _, _ -> dialPending() }
            .setPositiveButton("Call now") { _, _ -> directCallPending() }
            .show()
    }

    private fun dialPending() {
        val number = pendingNumber ?: return
        pendingNumber = null
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
        reply("Opening the dialer.")
    }

    private fun directCallPending() {
        val number = pendingNumber ?: return
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            pendingNumber = null
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
            reply("Placing the call.")
        } else requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), callRequest)
    }

    private fun openApp(name: String) {
        if (name.isBlank()) { reply("Which app should I open, boss?"); return }
        val pm = packageManager
        val app = pm.getInstalledApplications(PackageManager.GET_META_DATA).firstOrNull {
            pm.getApplicationLabel(it).toString().equals(name, true)
        } ?: pm.getInstalledApplications(PackageManager.GET_META_DATA).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, true)
        }
        val launch = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (launch == null) reply("I couldn't find a launchable app matching $name.")
        else { startActivity(launch); reply("Opening ${pm.getApplicationLabel(app)}.") }
    }

    private fun startOneShotListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { reply("Speech recognition is unavailable on this device."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest); return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        status.text = "● LISTENING"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ORION")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "● PROCESSING" }
            override fun onError(error: Int) { status.text = "● STANDBY"; recognizer.destroy() }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                recognizer.destroy(); status.text = "● STANDBY"
                if (!phrase.isNullOrBlank()) handleUserText(phrase)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun enableWakeWord() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest); return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest); return
        }
        val serviceIntent = Intent(this, WakeWordService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        reply("Wake-word service started where Android permits. The system microphone indicator and ongoing notification may be visible.")
    }

    private fun showAiSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val endpoint = EditText(this).apply { hint = "Chat-completions endpoint URL"; setText(prefs.getString("api_endpoint", "")); setSingleLine() }
        val model = EditText(this).apply { hint = "Model name"; setText(prefs.getString("api_model", "")); setSingleLine() }
        val key = EditText(this).apply { hint = "API key (private)"; setText(prefs.getString("api_key", "")); inputType = 129; setSingleLine() }
        panel.addView(endpoint); panel.addView(model); panel.addView(key)
        android.app.AlertDialog.Builder(this).setTitle("AI provider settings")
            .setMessage("Choose a provider that supports the OpenAI-compatible chat-completions format. Do not commit keys to GitHub. A backend is recommended for public releases.")
            .setView(panel).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("api_endpoint", endpoint.text.toString().trim())
                    .putString("api_model", model.text.toString().trim())
                    .putString("api_key", key.text.toString().trim()).apply()
                reply("AI provider settings saved on this device.")
            }.show()
    }

    private fun restoreHistory() {
        try {
            val arr = JSONArray(prefs.getString("chat_history", "[]"))
            for (i in maxOf(0, arr.length() - 20) until arr.length()) {
                val item = arr.getJSONObject(i)
                appendMessage(if (item.optString("role") == "user") "BOSS" else "ORION", item.optString("content"))
            }
        } catch (_: Exception) {}
    }

    private fun saveChat(role: String, content: String) {
        val arr = try { JSONArray(prefs.getString("chat_history", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("role", role).put("content", content).put("time", System.currentTimeMillis()))
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - 60) until arr.length()) out.put(arr.getJSONObject(i))
        prefs.edit().putString("chat_history", out.toString()).apply()
    }

    private fun reply(message: String, save: Boolean = true) {
        appendMessage("ORION", message)
        if (save) saveChat("assistant", message)
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "orion-response")
        status.text = "● STANDBY"
    }

    private fun requestInitialPermissions() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            contactsRequest -> if (granted) pendingContact?.let { val name = it; pendingContact = null; callContact(name) }
                else reply("Contacts permission denied.")
            callRequest -> if (granted) {
                val number = pendingNumber; pendingNumber = null
                if (number != null) { startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))); reply("Placing the call.") }
            } else dialPending()
            audioRequest -> if (granted) reply("Microphone permission granted.") else reply("Microphone permission is needed for voice features.")
            notificationRequest -> if (granted) enableWakeWord() else reply("Notifications are needed to show wake-word service status.")
        }
    }

    override fun onInit(result: Int) {
        ttsReady = result == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.getDefault()
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown(); worker.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
