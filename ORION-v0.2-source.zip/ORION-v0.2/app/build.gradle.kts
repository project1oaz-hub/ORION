plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.orion.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.orion.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}

kotlin { jvmToolchain(17) }
