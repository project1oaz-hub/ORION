# EDITH – personal AI assistant (Android)

## Build the APK on GitHub
**Option A – zip, no extracting:** create a repo, upload `EDITH.zip` to the repo root, then add the workflow
(*Add file > Create new file*, name it `.github/workflows/build.yml`, paste the contents of `build.yml`).
The workflow unzips the project and builds it.

**Option B – normal:** extract the zip and upload ALL files (keep `.github/workflows/build.yml`).

Then: Actions > "Build EDITH APK" > wait ~5-8 min > download artifact **EDITH-apk** > install `app-debug.apk`.

In the app: Settings > paste Gemini and/or Groq key, add your details, enable wake word,
allow "Display over other apps" and disable battery optimization.

## v1.1 – new speech pipeline
- **Full-duplex interruptions:** the mic stays open while EDITH talks. Start speaking and her volume ducks
  at once; after ~0.25 s of real speech she stops mid-sentence and answers you. Say "stop", "wait" or
  "never mind" and she just goes quiet. Tap the orb to interrupt manually.
- **Echo handling:** hardware echo canceller + noise suppression + call-audio routing, plus an adaptive
  threshold that learns how loud her own voice is in the mic. Headphones are detected automatically.
  Tune it in Settings > Interruption sensitivity.
- **Better recognition:** own recorder with voice detection (no clipped first words) → Groq Whisper
  large-v3-turbo, then Gemini audio, then offline Vosk. Silence hallucinations filtered, app names fixed
  (WhatsApp, YouTube...), optional language lock, mid-sentence pauses are merged into one request.
- Replies are spoken sentence by sentence so she starts talking sooner.
- "Hey EDITH" now opens a short hands-free conversation with follow-ups and interruptions.

## v1.2 - upgraded tools
- **Opening apps:** spelling-tolerant matching ("whatsap", "insta", "gpay", "yt"), nicknames, generic roles
  ("camera", "browser", "messages", "gallery", "calculator" open whatever app your phone uses), and
  "Did you mean ...?" suggestions when nothing matches.
- **Calling:** fuzzy contact search with nicknames (mom/mummy/amma, dad/papa...), favourites win ties, asks
  "which one?" when several contacts match, picks the mobile/primary number, **WhatsApp voice and video calls**
  ("video call Rahul", "call Mom on WhatsApp"), emergency words ("call the police") open the dialer with the
  local emergency number.
- **Real web search:** EDITH now answers from live information (Gemini + Google Search when you have a Gemini key,
  DuckDuckGo / Wikipedia otherwise), can read a link ("summarize this page"), and checks the **weather**
  (Open-Meteo, no key, "weather here" uses your coarse location).
- **New tools:** contact lookup ("what's Mom's number"), phone status (battery, network, storage), open a link,
  draft an email, share text, copy to clipboard, repeating alarms, more settings pages.
- **Instant commands (no AI wait):** pause/play/next/previous, volume up/down/mute/max/"volume 40",
  "set a timer for 10 minutes".
- Safety: web text is treated as untrusted, page fetching blocks private/local addresses, messages and emails
  are drafts you tap to send.

## v1.3 - offline multilingual speech recognition (English + Malayalam)
- Speech recognition now runs **fully on the phone** with Whisper (whisper.cpp). No audio is sent to Groq, Gemini or any cloud service.
- Understands **English and Malayalam**, detected per sentence (or lock one in Settings > Speech recognition).
  Malayalam app names (വാട്സ്ആപ്പ്, യൂട്യൂബ് ...) are mapped to the English names the app matcher uses; Malayalam "stop" words work for interruptions.
- Three model sizes in Settings: **Fast** (base, ~60 MB), **Balanced** (small, ~190 MB, default), **Accurate** (large-v3-turbo, ~570 MB).
  Bigger = better Malayalam, slower. The model downloads once (Settings > Download speech model, or automatically when wake word is turned on).
- Speed: only the audio that was actually spoken is encoded, the model loads on first use and is freed after 2 min of silence.
- "Hey EDITH" detection still uses the tiny offline Vosk model (English keyword spotting, very light on battery).
- The build now compiles native code (NDK + CMake, arm64 only). The GitHub workflow installs them for you.

## Fixes
Wake word no longer dies silently after a mic error; lost speech callbacks, stuck "Thinking…" state,
possible UI freeze when leaving the camera, TTS cut off at 700 characters, unreadable errors when Gemini
blocks or returns nothing, and a speech-engine leak on exit.

Voice commands: "open WhatsApp", "call Mom", "flashlight on/off", or anything else goes to the AI.
