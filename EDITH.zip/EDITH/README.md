# EDITH – personal AI assistant (Android)

## Build the APK on GitHub
**Option A – zip, no extracting:** create a repo, upload `EDITH.zip` to the repo root, then add the workflow
(*Add file > Create new file*, name it `.github/workflows/build.yml`, paste the contents of `build.yml`).
The workflow unzips the project and builds it.

**Option B – normal:** extract the zip and upload ALL files (keep `.github/workflows/build.yml`).

Then: Actions > "Build EDITH APK" > wait ~5-8 min > download artifact **EDITH-apk** > install `app-debug.apk`.

In the app: Settings > paste Gemini and/or Groq key, add your details, enable wake word,
allow "Display over other apps" and disable battery optimization.

## v1.1 – new speech pipeline
- **Full-duplex interruptions:** the mic stays open while EDITH talks. Start speaking and her volume ducks
  at once; after ~0.25 s of real speech she stops mid-sentence and answers you. Say "stop", "wait" or
  "never mind" and she just goes quiet. Tap the orb to interrupt manually.
- **Echo handling:** hardware echo canceller + noise suppression + call-audio routing, plus an adaptive
  threshold that learns how loud her own voice is in the mic. Headphones are detected automatically.
  Tune it in Settings > Interruption sensitivity.
- **Better recognition:** own recorder with voice detection (no clipped first words) → Groq Whisper
  large-v3-turbo, then Gemini audio, then offline Vosk. Silence hallucinations filtered, app names fixed
  (WhatsApp, YouTube...), optional language lock, mid-sentence pauses are merged into one request.
- Replies are spoken sentence by sentence so she starts talking sooner.
- "Hey EDITH" now opens a short hands-free conversation with follow-ups and interruptions.

## Fixes
Wake word no longer dies silently after a mic error; lost speech callbacks, stuck "Thinking…" state,
possible UI freeze when leaving the camera, TTS cut off at 700 characters, unreadable errors when Gemini
blocks or returns nothing, and a speech-engine leak on exit.

Voice commands: "open WhatsApp", "call Mom", "flashlight on/off", or anything else goes to the AI.
