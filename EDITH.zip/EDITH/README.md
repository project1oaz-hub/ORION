# EDITH – personal AI assistant (Android)

1. Create a GitHub repo, upload ALL files from this folder (keep `.github/workflows/build.yml`).
2. Open the repo > Actions > "Build EDITH APK" > wait ~5-8 min.
3. Download the artifact "EDITH-apk", unzip, install `app-debug.apk`.
4. In the app: Settings > paste Gemini and/or Groq key, add your details, enable wake word,
   allow "Display over other apps" and disable battery optimization.

Voice commands: "open WhatsApp", "call Mom", "flashlight on/off", or anything else goes to the AI.
