package com.edith.assistant

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("edith", Context.MODE_PRIVATE)
    }
    private fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    private fun p(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var provider: String
        get() = s("provider", "gemini")
        set(v) { p("provider", v) }
    var geminiKey: String
        get() = s("gkey")
        set(v) { p("gkey", v) }
    var geminiModel: String
        get() = s("gmodel", "gemini-2.5-flash")
        set(v) { p("gmodel", v) }
    var groqKey: String
        get() = s("qkey")
        set(v) { p("qkey", v) }
    var groqModel: String
        get() = s("qmodel", "llama-3.3-70b-versatile")
        set(v) { p("qmodel", v) }
    var name: String
        get() = s("name")
        set(v) { p("name", v) }
    var about: String
        get() = s("about")
        set(v) { p("about", v) }
    var accent: Int
        get() = sp.getInt("accent", 0xFFA8C7FA.toInt())
        set(v) { sp.edit().putInt("accent", v).apply() }
    var fontScale: Float
        get() = sp.getFloat("fs", 1f)
        set(v) { sp.edit().putFloat("fs", v).apply() }
    var rate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) { sp.edit().putFloat("rate", v).apply() }
    var style: String
        get() = s("style", "balanced")
        set(v) { p("style", v) }
    var dots: Boolean
        get() = sp.getBoolean("dots", true)
        set(v) { sp.edit().putBoolean("dots", v).apply() }
    var personality: String
        get() = s("persona", "dry")
        set(v) { p("persona", v) }
    var wake: Boolean
        get() = sp.getBoolean("wake", false)
        set(v) { sp.edit().putBoolean("wake", v).apply() }
    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }
}
