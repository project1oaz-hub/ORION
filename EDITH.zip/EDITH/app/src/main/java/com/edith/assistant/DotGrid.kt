package com.edith.assistant

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * Interactive dot-grid background. Dots are pushed away from your finger and spring back
 * (stiffness + damping) to their grid position when you lift or move away.
 * Touch is observed on the Initial pass and never consumed, so buttons and scrolling still work.
 */
@Composable
fun DotGridBox(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val density = LocalDensity.current
    val gap = with(density) { 26.dp.toPx() }
    val radius = with(density) { 120.dp.toPx() }
    val dotR = with(density) { 1.5.dp.toPx() }
    var w by remember { mutableStateOf(0) }
    var h by remember { mutableStateOf(0) }
    var touch by remember { mutableStateOf<Offset?>(null) }
    var tick by remember { mutableStateOf(0L) }

    // per dot: homeX, homeY, x, y, vx, vy
    val grid = remember(w, h) {
        if (w == 0 || h == 0) FloatArray(0) else {
            val cols = (w / gap).toInt() + 1
            val rows = (h / gap).toInt() + 1
            val a = FloatArray(cols * rows * 6)
            var k = 0
            for (j in 0 until rows) for (i in 0 until cols) {
                val x = i * gap + gap / 2f
                val y = j * gap + gap / 2f
                a[k] = x; a[k + 1] = y; a[k + 2] = x; a[k + 3] = y
                k += 6
            }
            a
        }
    }

    LaunchedEffect(grid) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { t ->
                if (!Theme.dots) { tick = t; return@withFrameNanos }
                val p = touch
                var k = 0
                while (k < grid.size) {
                    val x = grid[k + 2]; val y = grid[k + 3]
                    var vx = grid[k + 4]; var vy = grid[k + 5]
                    if (p != null) {
                        val dx = x - p.x; val dy = y - p.y
                        val d = sqrt(dx * dx + dy * dy)
                        if (d < radius && d > 0.001f) {
                            val f = 1f - d / radius
                            val push = f * f * 5f
                            vx += dx / d * push; vy += dy / d * push
                        }
                    }
                    vx += (grid[k] - x) * 0.07f      // spring stiffness
                    vy += (grid[k + 1] - y) * 0.07f
                    vx *= 0.84f; vy *= 0.84f         // damping
                    grid[k + 2] = x + vx; grid[k + 3] = y + vy
                    grid[k + 4] = vx; grid[k + 5] = vy
                    k += 6
                }
                tick = t
            }
        }
    }

    Box(
        modifier
            .onSizeChanged { w = it.width; h = it.height }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        touch = e.changes.firstOrNull { it.pressed }?.position
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val frame = tick
            if (!Theme.dots) return@Canvas
            val base = Color(0xFF363839)
            val glow = Theme.accent
            var k = 0
            while (k < grid.size) {
                val x = grid[k + 2]; val y = grid[k + 3]
                val m = (hypot(x - grid[k], y - grid[k + 1]) / (gap * 0.9f)).coerceIn(0f, 1f)
                drawCircle(lerp(base, glow, m), dotR * (1f + m * 0.8f), Offset(x, y))
                k += 6
            }
            if (frame < 0) return@Canvas
        }
        content()
    }
}
