package com.edith.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.core.content.ContextCompat
import androidx.compose.material3.TextButton
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Hands-free conversation: listen -> think -> speak -> listen again. Tap the orb to interrupt. */
@Composable
fun LiveScreen(voice: Voice, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf("listening") }
    var caption by remember { mutableStateOf("") }
    var muted by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { WakeService.pause() }
    DisposableEffect(Unit) { onDispose { WakeService.resume() } }

    fun close() { voice.cancelListen(); voice.stopSpeaking(); onClose() }
    BackHandler(true) { close() }

    LaunchedEffect(muted) {
        var misses = 0
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            hint = Voice.errorText(9); failed = true; muted = true; return@LaunchedEffect
        }
        while (isActive && !muted) {
            state = "listening"
            val heard = suspendCancellableCoroutine<String?> { c ->
                c.invokeOnCancellation { voice.cancelListen() }
                voice.listen { if (c.isActive) c.resume(it) }
            }
            if (heard.isNullOrBlank()) {
                val e = voice.lastError
                hint = Voice.errorText(e)
                if (e != 0 && e != 6 && e != 7) misses++ else misses = 0
                if (misses >= 4) { failed = true; muted = true; break }
                delay(400); continue
            }
            misses = 0; hint = ""
            caption = heard
            state = "thinking"
            val reply = Assistant.respond(ctx, heard, spoken = true)
            caption = reply
            state = "speaking"
            suspendCancellableCoroutine<Unit> { c ->
                c.invokeOnCancellation { voice.stopSpeaking() }
                voice.speak(reply) { if (c.isActive) c.resume(Unit) }
            }
        }
    }

    val inf = rememberInfiniteTransition(label = "orb")
    val speaking = state == "speaking"
    val pulse by inf.animateFloat(
        1f, if (speaking) 1.14f else 1.06f,
        infiniteRepeatable(tween(if (speaking) 700 else 3000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val status = when {
        failed -> "Microphone unavailable. Check permission."
        muted -> "Microphone muted"
        state == "listening" -> "Listening…"
        state == "thinking" -> "Thinking…"
        else -> "Speaking…"
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF0B0B0C)).systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text("LIVE", color = Color(0xFFC4C7C5), fontSize = 16.sp, letterSpacing = 2.sp)
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Box(
                Modifier.size(220.dp).scale(if (muted) 1f else pulse).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color.White, Theme.accent, Color(0xFF9B72CB), Color(0xFFD96570))))
                    .clickable { if (speaking) voice.stopSpeaking() }
            )
            Text(status, color = Color.White, fontSize = 20.sp)
            if (hint.isNotEmpty()) Text(hint, color = Color(0xFF8E918F), fontSize = 13.sp, textAlign = TextAlign.Center)
            if (failed) TextButton(onClick = {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }) { Text("Open app settings", color = Theme.accent) }
            Text(caption, color = Color(0xFFC4C7C5), fontSize = 16.sp, lineHeight = 24.sp, textAlign = TextAlign.Center, maxLines = 6)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            IconButton(onClick = { muted = !muted; failed = false; hint = ""; if (muted) voice.cancelListen() },
                modifier = Modifier.size(64.dp).clip(CircleShape).background(if (muted) Color.White else Color(0xFF282A2C))) {
                Icon(if (muted) Icons.Default.MicOff else Icons.Default.Mic, "Mute", tint = if (muted) Color.Black else Color.White)
            }
            IconButton(onClick = { close() }, modifier = Modifier.size(64.dp).clip(CircleShape).background(Color(0xFFF2B8B5))) {
                Icon(Icons.Default.Close, "End Live", tint = Color(0xFF601410))
            }
        }
    }
}
