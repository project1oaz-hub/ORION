package com.edith.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.locks.ReentrantLock

/** JNI bridge to whisper.cpp (see app/src/main/cpp). */
object WhisperNative {
    private var ok = false
    init { ok = try { System.loadLibrary("edithwhisper"); true } catch (e: Throwable) { false } }
    val available: Boolean get() = ok
    external fun nInit(path: String): Long
    external fun nFree(handle: Long)
    external fun nRun(handle: Long, pcm: FloatArray, threads: Int, lang: String, prompt: String, audioCtx: Int): ByteArray?
}

/** The multilingual Whisper models EDITH can run on the phone. Bigger = more accurate (Malayalam especially), slower. */
object WhisperModels {
    class M(val key: String, val file: String, val label: String, val mb: Int)

    private const val BASE_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"

    val all = listOf(
        M("base", "ggml-base-q5_1.bin", "Fast (base, ~60 MB)", 60),
        M("small", "ggml-small-q5_1.bin", "Balanced (small, ~190 MB)", 190),
        M("turbo", "ggml-large-v3-turbo-q5_0.bin", "Accurate (large-v3-turbo, ~570 MB)", 570)
    )

    fun current(): M = all.firstOrNull { it.key == Prefs.sttModel } ?: all[1]
    fun file(ctx: Context, m: M = current()): File = File(File(ctx.filesDir, "whisper"), m.file)
    fun installed(ctx: Context, m: M = current()): Boolean = file(ctx, m).exists()

    /** Downloads the model (only the finished file ever carries the final name). Returns true if it's ready. */
    @Synchronized
    fun download(ctx: Context, m: M = current(), onProgress: (Int) -> Unit = {}): Boolean {
        val dst = file(ctx, m)
        if (dst.exists()) return true
        dst.parentFile?.mkdirs()
        val part = File(dst.parentFile, m.file + ".part")
        return try {
            val c = URL(BASE_URL + m.file).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            var done = 0L
            var last = -1
            c.inputStream.use { i ->
                part.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
            if (total > 0 && done != total) throw IOException("incomplete download")
            if (done < 10_000_000L) throw IOException("file too small")
            if (!part.renameTo(dst)) throw IOException("couldn't save the model")
            true
        } catch (e: Exception) {
            try { part.delete() } catch (x: Exception) {}
            false
        }
    }
}

/** Offline speech-to-text: Whisper running on the phone's CPU. Loaded on demand, freed again when idle. */
object Whisper {
    private val lock = ReentrantLock()
    private var handle = 0L
    private var loaded = ""
    private val main = Handler(Looper.getMainLooper())
    private val idleTask = Runnable { freeIfIdle() }

    private fun freeNow() {
        if (handle != 0L) { try { WhisperNative.nFree(handle) } catch (e: Throwable) {} }
        handle = 0L
        loaded = ""
    }

    private fun freeIfIdle() {
        if (lock.tryLock()) {
            try { freeNow() } finally { lock.unlock() }
        } else {
            main.postDelayed(idleTask, 30_000)
        }
    }

    /** Free the model's memory right away (e.g. when the phone is low on RAM). */
    fun release() { freeIfIdle() }

    /** Recognises 16 kHz mono 16-bit PCM. Returns the text, or null when nothing was understood. Throws if the engine can't run. */
    fun transcribe(ctx: Context, pcm: ByteArray): String? {
        lock.lock()
        try {
            if (!WhisperNative.available) error("the native speech engine didn't load")
            val m = WhisperModels.current()
            val f = WhisperModels.file(ctx, m)
            if (!f.exists()) error("not installed")
            if (handle == 0L || loaded != m.key) {
                freeNow()
                handle = WhisperNative.nInit(f.absolutePath)
                if (handle == 0L) error("couldn't load the speech model (is the download damaged?)")
                loaded = m.key
            }

            // 16-bit PCM -> float, padded with silence (Whisper wants at least ~1 s)
            val n = pcm.size / 2
            val len = maxOf(n + 4800, 19200)
            val samples = FloatArray(len)
            for (i in 0 until n) {
                val s = (pcm[2 * i].toInt() and 0xFF) or (pcm[2 * i + 1].toInt() shl 8)
                samples[i] = s.toShort() / 32768f
            }

            // Only encode as much audio as there is (50 frames per second), never less than 10 s: big speed-up for short commands
            val frames = (((len / 16000f) * 50f).toInt() + 100).coerceIn(512, 1500)
            val audioCtx = ((frames + 63) / 64) * 64
            val lang = Prefs.sttLang.trim().lowercase().let { if (it == "en" || it == "ml") it else "auto" }
            val prompt = if (lang == "en") Stt.vocab() else ""
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)

            val raw = WhisperNative.nRun(handle, samples, threads, lang, prompt, audioCtx.coerceAtMost(1500))
                ?: error("recognition failed")
            val out = String(raw, Charsets.UTF_8)
            return out.substringAfter('\n', "").trim().ifBlank { null }
        } finally {
            main.removeCallbacks(idleTask)
            main.postDelayed(idleTask, 120_000)
            lock.unlock()
        }
    }
}
