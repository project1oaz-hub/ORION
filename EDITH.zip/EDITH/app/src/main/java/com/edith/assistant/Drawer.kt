package com.edith.assistant

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DrawerItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, null, tint = Color(0xFFE3E3E3))
        Text(label, color = Color(0xFFE3E3E3), fontSize = 15.sp)
    }
}

/** Gemini-style side panel: new chat, saved chats, tools, settings. */
@Composable
fun ChatsDrawer(onClose: () -> Unit, onSettings: () -> Unit, onTools: () -> Unit) {
    BackHandler(true) { onClose() }
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Color(0xAA000000)).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
        ) { onClose() })
        Column(Modifier.fillMaxHeight().width(310.dp).background(Panel).systemBarsPadding().padding(12.dp)) {
            Text("EDITH", color = Color(0xFFE3E3E3), fontSize = 22.sp, modifier = Modifier.padding(12.dp, 8.dp, 12.dp, 14.dp))
            Row(
                Modifier.clip(RoundedCornerShape(24.dp)).background(Bubble)
                    .clickable { ChatStore.newChat(); onClose() }.padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Default.Add, null, tint = Color(0xFFE3E3E3))
                Text("New chat", color = Color(0xFFE3E3E3), fontSize = 15.sp)
            }
            Text("Chats", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(14.dp, 18.dp, 14.dp, 6.dp))
            if (ChatStore.chats.isEmpty()) {
                Text("Your chats will show up here.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(14.dp))
            }
            LazyColumn(Modifier.weight(1f)) {
                items(ChatStore.chats, key = { it.id }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                            .background(if (c.id == ChatStore.currentId) Bubble else Color.Transparent)
                            .clickable { ChatStore.open(c.id); onClose() }.padding(start = 14.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(c.title, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(vertical = 14.dp))
                        IconButton(onClick = { ChatStore.delete(c.id) }) { Icon(Icons.Default.Delete, "Delete chat", tint = Muted) }
                    }
                }
            }
            DrawerItem(Icons.Default.Search, "Username check", onTools)
            DrawerItem(Icons.Default.Settings, "Settings", onSettings)
        }
    }
}
