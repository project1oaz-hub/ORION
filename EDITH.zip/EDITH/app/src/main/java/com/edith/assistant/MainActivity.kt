package com.edith.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var voice: Voice
    private val liveTrigger = androidx.compose.runtime.mutableStateOf(if (false) 1 else 0)

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (Prefs.wake) WakeService.start(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        Prefs.init(this)
        Theme.load()
        if (intent?.getBooleanExtra("live", false) == true) liveTrigger.value = 1
        voice = Voice(applicationContext)

        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray()) else if (Prefs.wake) WakeService.start(this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Theme.accent, background = BG, surface = Panel, onSurface = Color.White
            )) {
                var screen by remember { mutableStateOf(if (liveTrigger.value > 0) "live" else "chat") }
                androidx.compose.runtime.LaunchedEffect(liveTrigger.value) { if (liveTrigger.value > 0) screen = "live" }
                val d = androidx.compose.ui.platform.LocalDensity.current
                androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d.density, d.fontScale * Theme.fontScale)) {
                androidx.compose.material3.ProvideTextStyle(androidx.compose.ui.text.TextStyle(fontFamily = EdithFont)) {
                DotGridBox(Modifier.fillMaxSize().background(BG)) {
                    when (screen) {
                        "chat" -> ChatScreen(voice, onSettings = { screen = "settings" }, onLive = { screen = "live" })
                        "live" -> LiveScreen(voice) { screen = "chat" }
                        else -> SettingsScreen { screen = "chat" }
                    }
                }
                }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("live", false)) liveTrigger.value = liveTrigger.value + 1
    }
}
