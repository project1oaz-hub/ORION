package com.edith.assistant

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Speech recognition for what [Ear] captured.
 *
 * Fully offline: a multilingual Whisper model runs on the phone (see [Whisper]). It understands
 * English and Malayalam (auto-detected per sentence, or locked in Settings). No audio leaves the device.
 * Silence/noise hallucinations are filtered out and common mis-hearings of app names are fixed.
 */
object Stt {
    class Out(val text: String?, val error: String?)

    suspend fun transcribe(ctx: Context, pcm: ByteArray): Out = withContext(Dispatchers.Default) {
        if (!WhisperModels.installed(ctx))
            return@withContext Out(null, "The offline speech model isn't downloaded yet. Open Settings > Speech recognition and tap Download.")
        try {
            Out(clean(Whisper.transcribe(ctx, pcm), pcm), null)
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            Out(null, "Speech recognition failed (${(e.message ?: e.javaClass.simpleName).take(80)}).")
        }
    }

    // ------------------------------------------------------------------ helpers

    fun vocab(): String {
        val extra = if (Prefs.name.isBlank()) "" else ", ${Prefs.name.trim()}"
        return "EDITH, Hey EDITH, WhatsApp, YouTube, Spotify, Instagram, Facebook, Google Maps, flashlight, Comet, Perplexity$extra"
    }

    fun wav(pcm: ByteArray, rate: Int = Ear.RATE): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
        bb.putInt(16); bb.putShort(1.toShort()); bb.putShort(1.toShort())
        bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2.toShort()); bb.putShort(16.toShort())
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun energy(pcm: ByteArray): Float {
        var sum = 0.0
        var n = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val s = (pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)
            val v = s.toShort().toInt()
            sum += (v * v).toDouble()
            n++
            i += 2
        }
        return if (n == 0) 0f else sqrt(sum / n).toFloat()
    }

    private val NOISE_TEXT = setOf(
        "thank you", "thanks for watching", "thank you for watching", "you", "bye", "so", "the end",
        "subtitles by the amaraorg community", "thanks", "നന്ദി"
    )

    private val FIXES = listOf(
        Regex("\\bwhat'?s ?app\\b", RegexOption.IGNORE_CASE) to "WhatsApp",
        Regex("\\bwhats ?up app\\b", RegexOption.IGNORE_CASE) to "WhatsApp",
        Regex("\\binsta gram\\b", RegexOption.IGNORE_CASE) to "Instagram",
        Regex("\\bface book\\b", RegexOption.IGNORE_CASE) to "Facebook",
        Regex("\\byou tube\\b", RegexOption.IGNORE_CASE) to "YouTube",
        Regex("\\bflash light\\b", RegexOption.IGNORE_CASE) to "flashlight",
        Regex("^(hey|hi) (edit|eddie|eddy|edie|edith)\\b", RegexOption.IGNORE_CASE) to "hey EDITH"
    )


    private fun ml(vararg forms: String) = Regex(forms.joinToString("|") { Regex.escape(it) })

    private val ML_FIXES = listOf(
        ml("വാട്സ്ആപ്പ്", "വാട്സാപ്പ്", "വാട്ട്സ്ആപ്പ്", "വാട്ട്സാപ്പ്", "വാട്സ് ആപ്പ്") to "WhatsApp",
        ml("യൂട്യൂബ്") to "YouTube",
        ml("ഇൻസ്റ്റാഗ്രാം", "ഇൻസ്റ്റഗ്രാം") to "Instagram",
        ml("ഫേസ്ബുക്ക്") to "Facebook",
        ml("ഗൂഗിൾ മാപ്സ്") to "Google Maps",
        ml("സ്പോട്ടിഫൈ") to "Spotify",
        ml("ടോർച്ച്", "ഫ്ലാഷ്ലൈറ്റ്") to "flashlight"
    )

    private fun clean(t: String?, pcm: ByteArray): String? {
        var x = (t ?: return null).replace(Regex("\\[[^\\]]*\\]|\\([^)]*\\)|\\*[^*]*\\*"), " ").replace(Regex("\\s+"), " ").trim()
        if (x.isEmpty() || x == ".") return null
        val n = norm(x)
        if (n in NOISE_TEXT && energy(pcm) < 450f) return null
        if (n.isEmpty()) return null
        for ((re, rep) in FIXES) x = re.replace(x, rep)
        for ((re, rep) in ML_FIXES) x = re.replace(x, rep)
        return x
    }

    fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), "").replace(Regex("\\s+"), " ").trim()

    private val STOPS = setOf(
        "stop", "wait", "hold on", "hang on", "okay", "ok", "never mind", "nevermind", "cancel", "quiet",
        "be quiet", "shush", "enough", "thats enough", "shut up", "stop talking", "okay stop", "ok stop", "alright", "got it",
        "നിർത്തൂ", "നിർത്തു", "നിർത്ത്", "മതി", "നിൽക്കൂ", "വേണ്ട"
    )

    /** True for "stop", "wait", "never mind"...: when you cut EDITH off with one of these she just goes quiet. */
    fun isStop(t: String): Boolean = norm(t) in STOPS

    /** True if [heard] is mostly EDITH's own words coming back through the microphone. */
    fun echoOf(heard: String, spoken: String): Boolean {
        val h = norm(heard).split(' ').filter { it.isNotEmpty() }
        if (h.size < 3) return false
        val s = norm(spoken).split(' ').toSet()
        val hit = h.count { it in s }
        return hit.toFloat() / h.size >= 0.8f
    }
}
