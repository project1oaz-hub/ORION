package com.edith.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Speech recognition for what [Ear] captured.
 *
 * Engines, best first: Groq Whisper large-v3-turbo (fast and very accurate, multilingual),
 * Gemini audio understanding, then the offline Vosk model. If one is rate limited or offline,
 * the next one takes over for that sentence. Silence/noise hallucinations are filtered out and
 * common mis-hearings of app names are fixed.
 */
object Stt {
    class Out(val text: String?, val error: String?)

    private const val GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
    private val cooldown = HashMap<String, Long>()

    private fun cool(e: String): Boolean = synchronized(cooldown) { (cooldown[e] ?: 0L) > System.currentTimeMillis() }
    private fun setCool(e: String, ms: Long) { synchronized(cooldown) { cooldown[e] = System.currentTimeMillis() + ms } }

    private fun order(): List<String> {
        val l = ArrayList<String>()
        fun add(x: String) { if (x !in l) l.add(x) }
        when (Prefs.sttEngine) {
            "groq" -> add("groq")
            "gemini" -> add("gemini")
            "offline" -> add("offline")
            else -> {}
        }
        if (Prefs.groqKey.isNotBlank()) add("groq")
        if (Prefs.geminiKey.isNotBlank()) add("gemini")
        add("offline")
        return l
    }

    suspend fun transcribe(ctx: Context, pcm: ByteArray): Out = withContext(Dispatchers.IO) {
        var lastErr: String? = null
        for (e in order()) {
            if (cool(e)) continue
            try {
                val t = when (e) {
                    "groq" -> groq(pcm)
                    "gemini" -> gemini(pcm)
                    else -> offline(ctx, pcm, Prefs.sttEngine == "offline")
                }
                return@withContext Out(clean(t, pcm), null)
            } catch (ex: Exception) {
                val m = ex.message ?: ""
                lastErr = when {
                    m.contains("429") -> "Speech recognition is rate limited. Wait a moment."
                    m.contains("401") || m.contains("403") -> "The $e speech key was rejected. Check it in Settings."
                    m.startsWith("No ") || m.contains("not installed") -> lastErr
                    else -> "Speech recognition failed (${m.take(80)})."
                }
                if (m.contains("429")) setCool(e, 30_000)
                else if (m.contains("401") || m.contains("403")) setCool(e, 300_000)
                else if (m.contains("Unable to resolve") || m.contains("timed out") || m.contains("Failed to connect")) setCool(e, 8_000)
            }
        }
        Out(null, lastErr ?: "No speech recognition engine is ready. Add a Groq or Gemini key in Settings.")
    }

    // ------------------------------------------------------------------ Groq Whisper

    private fun groq(pcm: ByteArray): String? {
        if (Prefs.groqKey.isBlank()) error("No Groq key")
        val wav = wav(pcm)
        return try {
            groqCall(Prefs.sttModel, wav)
        } catch (e: Exception) {
            val m = e.message ?: ""
            if ((m.contains("HTTP 400") || m.contains("HTTP 404")) && m.contains("model", true) && Prefs.sttModel != "whisper-large-v3")
                groqCall("whisper-large-v3", wav)
            else throw e
        }
    }

    private fun groqCall(model: String, wav: ByteArray): String? {
        val boundary = "----edith" + System.nanoTime()
        val out = ByteArrayOutputStream()
        fun field(n: String, v: String) {
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n".toByteArray())
        }
        field("model", model)
        field("response_format", "verbose_json")
        field("temperature", "0")
        val lang = Prefs.sttLang.trim().lowercase().substringBefore('-')
        if (lang.length in 2..3) field("language", lang)
        field("prompt", vocab())
        out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n".toByteArray())
        out.write(wav)
        out.write("\r\n--$boundary--\r\n".toByteArray())

        val c = URL(GROQ_URL).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer ${Prefs.groqKey}")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { it.write(out.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) error("HTTP $code: ${txt.take(200)}")

        val j = JSONObject(txt)
        val segs = j.optJSONArray("segments")
        if (segs != null && segs.length() > 0) {
            val sb = StringBuilder()
            for (i in 0 until segs.length()) {
                val s = segs.getJSONObject(i)
                // Whisper invents text for silence; its own confidence numbers expose that
                if (s.optDouble("no_speech_prob", 0.0) > 0.6 && s.optDouble("avg_logprob", 0.0) < -0.8) continue
                sb.append(s.optString("text")).append(' ')
            }
            return sb.toString().trim().ifBlank { null }
        }
        return j.optString("text").trim().ifBlank { null }
    }

    // ------------------------------------------------------------------ Gemini audio

    private fun gemini(pcm: ByteArray): String? {
        if (Prefs.geminiKey.isBlank()) error("No Gemini key")
        return try {
            geminiCall(pcm)
        } catch (e: Exception) {
            val m = e.message ?: ""
            if (m.contains("HTTP 404")) {
                val ids = runCatching { runBlocking { Ai.models("gemini") } }.getOrDefault(emptyList())
                val b = Ai.best("gemini", ids)
                if (b != null && b != Prefs.geminiModel) { Prefs.geminiModel = b; return geminiCall(pcm) }
            }
            throw e
        }
    }

    private fun geminiCall(pcm: ByteArray): String? {
        val b64 = android.util.Base64.encodeToString(wav(pcm), android.util.Base64.NO_WRAP)
        val prompt = "Transcribe this audio exactly as spoken, in the language that is spoken. It is a voice command or question " +
            "for a phone assistant called EDITH. Words that may appear: ${vocab()}. " +
            "Reply with only the transcript, no quotes or notes. If there is no intelligible speech reply with exactly: [none]"
        val parts = JSONArray().put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", b64)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0))
        val res = Ai.post(
            "https://generativelanguage.googleapis.com/v1beta/models/${Prefs.geminiModel}:generateContent",
            body.toString(), mapOf("x-goog-api-key" to Prefs.geminiKey)
        )
        val t = Ai.geminiText(res)
        return if (t.contains("[none]", true)) null else t
    }

    // ------------------------------------------------------------------ Offline (Vosk)

    private fun offline(ctx: Context, pcm: ByteArray, download: Boolean): String? {
        val m = ModelManager.model(ctx, download) ?: error("No offline model installed")
        val r = Recognizer(m, 16000f)
        try {
            r.acceptWaveForm(pcm, pcm.size)
            return JSONObject(r.finalResult).optString("text").trim().ifBlank { null }
        } finally {
            r.close()
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun vocab(): String {
        val extra = if (Prefs.name.isBlank()) "" else ", ${Prefs.name.trim()}"
        return "EDITH, Hey EDITH, WhatsApp, YouTube, Spotify, Instagram, Facebook, Google Maps, flashlight, Comet, Perplexity$extra"
    }

    fun wav(pcm: ByteArray, rate: Int = Ear.RATE): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
        bb.putInt(16); bb.putShort(1.toShort()); bb.putShort(1.toShort())
        bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2.toShort()); bb.putShort(16.toShort())
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    private fun energy(pcm: ByteArray): Float {
        var sum = 0.0
        var n = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val s = (pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)
            val v = s.toShort().toInt()
            sum += (v * v).toDouble()
            n++
            i += 2
        }
        return if (n == 0) 0f else sqrt(sum / n).toFloat()
    }

    private val NOISE_TEXT = setOf(
        "thank you", "thanks for watching", "thank you for watching", "you", "bye", "so", "the end",
        "subtitles by the amaraorg community", "thanks"
    )

    private val FIXES = listOf(
        Regex("\\bwhat'?s ?app\\b", RegexOption.IGNORE_CASE) to "WhatsApp",
        Regex("\\bwhats ?up app\\b", RegexOption.IGNORE_CASE) to "WhatsApp",
        Regex("\\binsta gram\\b", RegexOption.IGNORE_CASE) to "Instagram",
        Regex("\\bface book\\b", RegexOption.IGNORE_CASE) to "Facebook",
        Regex("\\byou tube\\b", RegexOption.IGNORE_CASE) to "YouTube",
        Regex("\\bflash light\\b", RegexOption.IGNORE_CASE) to "flashlight",
        Regex("^(hey|hi) (edit|eddie|eddy|edie|edith)\\b", RegexOption.IGNORE_CASE) to "hey EDITH"
    )

    private fun clean(t: String?, pcm: ByteArray): String? {
        var x = t?.trim() ?: return null
        if (x.isEmpty() || x == ".") return null
        val n = norm(x)
        if (n in NOISE_TEXT && energy(pcm) < 450f) return null
        if (n.isEmpty()) return null
        for ((re, rep) in FIXES) x = re.replace(x, rep)
        return x
    }

    fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), "").replace(Regex("\\s+"), " ").trim()

    private val STOPS = setOf(
        "stop", "wait", "hold on", "hang on", "okay", "ok", "never mind", "nevermind", "cancel", "quiet",
        "be quiet", "shush", "enough", "thats enough", "shut up", "stop talking", "okay stop", "ok stop", "alright", "got it"
    )

    /** True for "stop", "wait", "never mind"...: when you cut EDITH off with one of these she just goes quiet. */
    fun isStop(t: String): Boolean = norm(t) in STOPS

    /** True if [heard] is mostly EDITH's own words coming back through the microphone. */
    fun echoOf(heard: String, spoken: String): Boolean {
        val h = norm(heard).split(' ').filter { it.isNotEmpty() }
        if (h.size < 3) return false
        val s = norm(spoken).split(' ').toSet()
        val hit = h.count { it in s }
        return hit.toFloat() / h.size >= 0.8f
    }
}
