package com.edith.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONObject
import androidx.core.content.ContextCompat

object Actions {
    private var torchOn = false

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Returns a reply if the text was a device command, else null. */
    fun handle(ctx: Context, raw: String): String? {
        var t = raw.lowercase().trim().trimEnd('.', '!', '?')
        t = t.replace(Regex("^((hey )?edith[, ]*|please |can you |could you |will you )+"), "").trim()
        if (t.length < 40 && Regex("\\b(flash ?light|torch)\\b").containsMatchIn(t)) return torch(ctx, t)
        quick(ctx, t)?.let { return it }
        usernameCommand(ctx, t)?.let { return it }
        smartCommands(ctx, t)?.let { return it }
        Regex("^(video call|whatsapp video call|whatsapp call|whats app call|call|phone|dial|ring)\\s+(.+?)(?:\\s+(?:on|via|using|through|with)\\s+(whats ?app|phone|mobile|sim|normal call))?$").find(t)?.let {
            val head = it.groupValues[1]
            val wa = head.contains("whats") || it.groupValues[3].contains("whats") || head.startsWith("video")
            return call(ctx, it.groupValues[2], if (wa) "whatsapp" else "phone", head.contains("video"))
        }
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let { return open(ctx, it.groupValues[2]) }
        return null
    }

    private val STOP = setOf("my", "me", "your", "the", "a", "an", "his", "her", "their", "this", "that", "our", "user", "everyone", "someone")

    private fun spokenHandle(s: String): String {
        var x = s.lowercase().trim().trim('\'', '"', '\u2018', '\u2019', '\u201C', '\u201D')
        x = x.replace(" underscore ", "_").replace(" dot ", ".").replace(" dash ", "-").replace(" hyphen ", "-")
        return x.removePrefix("@").replace(" ", "")
    }

    /** "check the username xyz" / "show me xyz profile" opens the Username check screen with xyz filled in. */
    private fun usernameCommand(ctx: Context, t: String): String? {
        val explicit = Regex("^(?:check|search|find|look ?up|show me|show|run)\\s+(?:the\\s+)?(?:username|user name|handle)\\s+(.+?)(?:'s)?(?:\\s+(?:profiles?|accounts?|footprint))?$").find(t)
        val single = Regex("^show me\\s+(\\S+?)(?:'s)?\\s+(?:profiles?|accounts?)$").find(t)
        val raw = explicit?.groupValues?.get(1) ?: single?.groupValues?.get(1) ?: return null
        if (explicit == null) {
            // "show me X profile" is a username only when it is quoted, @-prefixed or has digits/underscores/dots.
            // Plain words (e.g. a famous person's name) go to the AI instead.
            val looksLikeHandle = raw.firstOrNull() in listOf('\'', '"', '\u2018', '\u201C', '@') || raw.any { it.isDigit() || it == '_' || it == '.' }
            if (!looksLikeHandle || raw.lowercase() in STOP) return null
        }
        val name = spokenHandle(raw)
        if (!Osint.VALID.matches(name)) return "That doesn't look like a valid username. Usernames can use letters, numbers, dots, dashes and underscores."
        if (Osint.liveActive) {
            Osint.liveQuery = Osint.LiveReq(name, System.nanoTime())
            return "Checking $name on public sites. Results will show on screen."
        }
        Osint.pendingUser = name
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("osint", name))
        } catch (e: Exception) {}
        return "Opening the username check for $name. Tap Search once the spelling looks right."
    }

    /** Natural phrasings: "get me on instagram", "let me talk to mom", "search messi on youtube", "search messi" (in the current app). */
    private fun smartCommands(ctx: Context, t: String): String? {
        if (Regex("^(?:what(?:'s| is) (?:this|that|in front of me)|what am i (?:looking|pointing) at|identify this|scan this|look at this|tell me what this is|what do you see)$").containsMatchIn(t)) {
            if (Vision.liveCamera) return null   // Live already attaches the camera frame; the AI answers from it
            if (Osint.liveActive) {
                Vision.liveAsk = Vision.LiveAsk(Vision.DEFAULT, System.nanoTime())
                return "Let me take a look."
            }
            Vision.pendingPrompt = Vision.DEFAULT
            try {
                ctx.startActivity(Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("camera", true))
            } catch (e: Exception) {}
            return "Opening the camera."
        }
        Regex("^(?:search for|search|find|look up)\\s+(.+?)\\s+(?:on|in)\\s+(youtube|spotify|google maps|maps|google|play store|reddit|wikipedia|amazon|comet)$").find(t)?.let {
            val key = Phone.appKey(it.groupValues[2]).ifBlank { "google" }
            return Phone.inAppSearch(ctx, key, it.groupValues[1]).msg
        }
        Regex("^play\\s+(.+?)\\s+(?:on|in)\\s+(youtube|spotify)$").find(t)?.let {
            return Phone.inAppSearch(ctx, it.groupValues[2], it.groupValues[1], true).msg
        }
        Regex("^(?:search for|search|look up)\\s+(.+)$").find(t)?.let {
            val key = Phone.appKey(Phone.currentApp())
            if (key.isNotEmpty()) return Phone.inAppSearch(ctx, key, it.groupValues[1]).msg
        }
        Regex("^(?:let me (?:talk|speak) to|i (?:want|wanna|would like|'d like) to (?:talk|speak) to|(?:talk|speak) to|connect me (?:to|with)|put me through to|get me through to|ring up|call up|make a call to|give a call to)\\s+(.+)$").find(t)?.let {
            val n = it.groupValues[1].trim()
            if (n.any { c -> c.isLetter() }) {
                if (!has(ctx, Manifest.permission.READ_CONTACTS)) return call(ctx, n)
                if (Contacts.who(ctx, n).error?.startsWith("I couldn't find") == true) return null
            }
            return call(ctx, n)
        }
        Regex("^(?:run|fire up|bring up|go to|take me to|get me on|get me onto|get me to|switch to|jump to|pull up)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(t)?.let {
            val r = open(ctx, it.groupValues[1])
            return if (r.startsWith("Opening") || r.startsWith("I couldn't open")) r else null
        }
        return null
    }

    private fun torch(ctx: Context, t: String): String {
        val on = when {
            Regex("\\b(off|disable|stop)\\b").containsMatchIn(t) -> false
            Regex("\\b(on|enable|start)\\b").containsMatchIn(t) -> true
            else -> !torchOn
        }
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone doesn't have a flashlight."
        return try {
            cm.setTorchMode(id, on)
            torchOn = on
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't control the flashlight."
        }
    }

    // ------------------------------------------------------------------ quick local commands (no AI round trip)

    private val PAUSE = Regex("^(?:pause|pause (?:the )?(?:music|song|video|playback|it)|stop (?:the )?(?:music|song|playback))$")
    private val PLAY = Regex("^(?:play|resume|resume (?:the )?(?:music|song|video|playback)|continue (?:the )?(?:music|song|playback))$")
    private val NEXT = Regex("^(?:next|skip|next (?:song|track)|skip (?:this |the )?(?:song|track)|play next)$")
    private val PREV = Regex("^(?:previous|previous (?:song|track)|go back (?:a |one )?(?:song|track)|play previous)$")
    private val VOL_UP = Regex("^(?:volume up|(?:turn|crank|pump) (?:the )?(?:volume )?up|turn it up|louder|(?:increase|raise) (?:the )?volume)$")
    private val VOL_DOWN = Regex("^(?:volume down|(?:turn|bring) (?:the )?(?:volume )?down|turn it down|quieter|(?:decrease|lower|reduce) (?:the )?volume)$")
    private val MUTE = Regex("^(?:mute|silence|mute (?:the )?(?:phone|sound|volume))$")
    private val VOL_MAX = Regex("^(?:max volume|full volume|volume (?:to )?(?:max|full))$")
    private val VOL_SET = Regex("^(?:set |change )?(?:the )?volume (?:to |at )?(\\d{1,3}) ?(?:%|percent)?$")

    private fun act(ctx: Context, vararg kv: Pair<String, Any>): Boolean {
        val j = JSONObject()
        for ((k, v) in kv) j.put(k, v)
        return Phone.run(ctx, j).ok
    }

    private fun quick(ctx: Context, t: String): String? {
        if (t.length > 60) return null
        when {
            PAUSE.matches(t) -> return if (act(ctx, "type" to "media", "cmd" to "pause")) "Paused." else null
            PLAY.matches(t) -> return if (act(ctx, "type" to "media", "cmd" to "play")) "Playing." else null
            NEXT.matches(t) -> return if (act(ctx, "type" to "media", "cmd" to "next")) "Next." else null
            PREV.matches(t) -> return if (act(ctx, "type" to "media", "cmd" to "previous")) "Previous." else null
            VOL_UP.matches(t) -> return if (act(ctx, "type" to "volume", "delta" to 15)) "Louder." else null
            VOL_DOWN.matches(t) -> return if (act(ctx, "type" to "volume", "delta" to -15)) "Quieter." else null
            MUTE.matches(t) -> return if (act(ctx, "type" to "volume", "level" to 0)) "Muted." else null
            VOL_MAX.matches(t) -> return if (act(ctx, "type" to "volume", "level" to 100)) "Volume at maximum." else null
        }
        VOL_SET.find(t)?.let {
            val lv = it.groupValues[1].toInt().coerceIn(0, 100)
            return if (act(ctx, "type" to "volume", "level" to lv)) "Volume set to $lv percent." else null
        }
        if (t.contains("timer") && !Regex("\\b(cancel|stop|delete|remove|clear)\\b").containsMatchIn(t)) {
            val sec = duration(t)
            if (sec > 0) {
                return if (act(ctx, "type" to "timer", "seconds" to sec, "label" to "")) "Timer set for ${spokenDuration(sec)}." else null
            }
        }
        return null
    }

    private fun duration(t: String): Int {
        var s = 0.0
        var found = false
        for (m in Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)\\b").findAll(t)) {
            val n = m.groupValues[1].toDouble()
            val u = m.groupValues[2]
            s += when { u.startsWith("h") -> n * 3600; u.startsWith("m") -> n * 60; else -> n }
            found = true
        }
        if (!found) {
            when {
                Regex("\\bhalf an hour\\b").containsMatchIn(t) -> s = 1800.0
                Regex("\\b(?:an|one|a) hour\\b").containsMatchIn(t) -> s = 3600.0
                Regex("\\b(?:a|one) minute\\b").containsMatchIn(t) -> s = 60.0
            }
        }
        return s.toInt()
    }

    private fun spokenDuration(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val r = sec % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h hour" + if (h > 1) "s" else "")
        if (m > 0) parts.add("$m minute" + if (m > 1) "s" else "")
        if (r > 0) parts.add("$r second" + if (r > 1) "s" else "")
        return parts.joinToString(" ")
    }

    // ------------------------------------------------------------------ contacts / calling

    internal fun lookup(ctx: Context, name: String): String? =
        Contacts.who(ctx, name).let { if (it.error == null) it.number else null }

    private fun emergency(n: String): String? {
        val l = n.lowercase().trim()
        if (l !in setOf("police", "the police", "ambulance", "an ambulance", "fire brigade", "the fire brigade", "fire department", "emergency", "emergency services", "emergency number")) return null
        return when (java.util.Locale.getDefault().country) {
            "US", "CA" -> "911"
            "GB" -> "999"
            "AU" -> "000"
            else -> "112"
        }
    }

    /** Calls a contact or number. [via] "whatsapp" places a WhatsApp voice/video call. */
    fun call(ctx: Context, name: String, via: String = "phone", video: Boolean = false): String {
        val n = name.trim().trim('.', ',', '!', '?')
        emergency(n)?.let { num ->
            return try {
                ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Opening the dialer with $num. Press call to connect."
            } catch (e: Exception) { "I couldn't open the dialer." }
        }
        val w = Contacts.who(ctx, n)
        w.error?.let { return it }
        val shown = if (w.name.any { it.isLetter() }) w.name else w.number
        if (via == "whatsapp") {
            if (Contacts.whatsappCall(ctx, w.id, video)) return "Calling $shown on WhatsApp."
            val digits = w.number.filter { it.isDigit() }
            return try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits")).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Opening the WhatsApp chat with $shown. Tap the call button."
            } catch (e: Exception) { "I couldn't open WhatsApp for $shown." }
        }
        val action = if (has(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return try {
            ctx.startActivity(Intent(action, Uri.parse("tel:" + Uri.encode(w.number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Calling $shown."
        } catch (e: Exception) {
            "I couldn't place the call."
        }
    }

    // ------------------------------------------------------------------ apps

    /** (label, package) of the installed launcher app best matching [name]. */
    fun findApp(ctx: Context, name: String): Pair<String, String>? {
        val q = AppIndex.resolve(name)
        val top = AppIndex.rank(ctx, q).firstOrNull() ?: return null
        return if (top.first >= 0.72f) top.second.label to top.second.pkg else null
    }

    private fun launch(ctx: Context, a: AppEntry): String {
        val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "I can't open ${a.label}."
        return try {
            ctx.startActivity(i)
            Phone.noteApp(a.label)
            "Opening ${a.label}."
        } catch (e: Exception) {
            "I couldn't open ${a.label}. Enable 'Display over other apps' for EDITH in Settings."
        }
    }

    fun open(ctx: Context, name: String): String {
        val shown = name.trim().replaceFirstChar { it.uppercase() }
        val q = AppIndex.resolve(name)
        val ranked = AppIndex.rank(ctx, q)
        val top = ranked.firstOrNull()
        // 1) a clear match among the installed apps
        if (top != null && top.first >= 0.9f) return launch(ctx, top.second)
        // 2) a generic role ("camera", "browser", "messages"...) opens whatever app the phone uses for it
        if (AppIndex.openGeneric(ctx, Fuzzy.norm(q))) return "Opening $shown."
        // 3) a close, spelling-tolerant match
        if (top != null && top.first >= 0.72f) return launch(ctx, top.second)
        val near = ranked.filter { it.first >= 0.5f }.take(3).map { it.second.label }
        return "I couldn't find an app called $name." + if (near.isEmpty()) "" else " Did you mean " + near.joinToString(" or ") + "?"
    }
}

class AppEntry(val label: String, val pkg: String)

/** The phone's launcher apps, cached briefly, with forgiving name matching. */
object AppIndex {
    private var cache: List<AppEntry> = emptyList()
    private var at = 0L

    private val ALIAS = mapOf(
        "insta" to "instagram", "ig" to "instagram", "wa" to "whatsapp", "yt" to "youtube", "fb" to "facebook",
        "gpay" to "google pay", "googlepay" to "google pay", "playstore" to "play store", "gmaps" to "maps",
        "calc" to "calculator", "chromebrowser" to "chrome", "tiktok" to "tiktok", "snap" to "snapchat",
        "gmail" to "gmail", "settings" to "settings", "setting" to "settings"
    )

    fun resolve(name: String): String {
        val q = name.lowercase().trim().trimEnd('.', '!', '?').removePrefix("the ").removeSuffix(" app").removeSuffix(" application").trim()
        return ALIAS[Fuzzy.norm(q)] ?: q
    }

    fun all(ctx: Context): List<AppEntry> {
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - at < 30_000L) return cache
        val pm = ctx.packageManager
        val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
        cache = l
        at = now
        return l
    }

    /** Apps sorted best match first (shorter names win ties). */
    fun rank(ctx: Context, q: String): List<Pair<Float, AppEntry>> =
        all(ctx).map { Fuzzy.score(q, it.label) to it }
            .sortedWith(compareByDescending<Pair<Float, AppEntry>> { it.first }.thenBy { it.second.label.length })

    fun openGeneric(ctx: Context, key: String): Boolean {
        val i: Intent = when (key) {
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "dialer", "phone", "keypad" -> Intent(Intent.ACTION_DIAL)
            "browser", "webbrowser" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
            "calculator" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
            "calendar" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
            "contacts" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS)
            "email", "mail" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_EMAIL)
            "gallery", "photos" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
            "maps" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS)
            "messages", "messaging", "sms", "textmessages" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
            "music" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            "files", "filemanager" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_FILES)
            else -> return false
        }
        return try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Phone.noteApp(key)
            true
        } catch (e: Exception) { false }
    }
}
