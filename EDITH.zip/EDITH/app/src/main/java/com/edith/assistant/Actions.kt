package com.edith.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

object Actions {
    private var torchOn = false

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Returns a reply if the text was a device command, else null. */
    fun handle(ctx: Context, raw: String): String? {
        var t = raw.lowercase().trim().trimEnd('.', '!', '?')
        t = t.replace(Regex("^((hey )?edith[, ]*|please |can you |could you |will you )+"), "").trim()
        if (t.length < 40 && Regex("\\b(flash ?light|torch)\\b").containsMatchIn(t)) return torch(ctx, t)
        Regex("^(call|phone|dial|ring)\\s+(.+)$").find(t)?.let { return call(ctx, it.groupValues[2]) }
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let { return open(ctx, it.groupValues[2]) }
        return null
    }

    private fun torch(ctx: Context, t: String): String {
        val on = when {
            Regex("\\b(off|disable|stop)\\b").containsMatchIn(t) -> false
            Regex("\\b(on|enable|start)\\b").containsMatchIn(t) -> true
            else -> !torchOn
        }
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone doesn't have a flashlight."
        return try {
            cm.setTorchMode(id, on)
            torchOn = on
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't control the flashlight."
        }
    }

    internal fun lookup(ctx: Context, name: String): String? {
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    private fun call(ctx: Context, name: String): String {
        val n = name.trim()
        val number: String
        if (n.none { it.isLetter() } && n.count { it.isDigit() } >= 5) {
            number = n.filter { it.isDigit() || it == '+' }
        } else {
            if (!has(ctx, Manifest.permission.READ_CONTACTS)) return "Please grant contacts permission to EDITH."
            number = lookup(ctx, n) ?: return "I couldn't find $n in your contacts."
        }
        val action = if (has(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return try {
            ctx.startActivity(Intent(action, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Calling $n."
        } catch (e: Exception) {
            "I couldn't place the call."
        }
    }

    fun open(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val q = name.lowercase().trim().removePrefix("the ").removeSuffix(" app").trim()
        val hit = apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(q) }
            ?: apps.firstOrNull { it.first.lowercase().contains(q) }
            ?: return "I couldn't find an app called $name."
        val i = pm.getLaunchIntentForPackage(hit.second)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: return "I can't open ${hit.first}."
        return try {
            ctx.startActivity(i)
            "Opening ${hit.first}."
        } catch (e: Exception) {
            "I couldn't open ${hit.first}. Enable 'Display over other apps' for EDITH in Settings."
        }
    }
}
