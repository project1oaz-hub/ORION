package com.edith.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.sqrt

/** One finished thing the user said: 16 kHz mono 16-bit PCM. [barged] = they cut EDITH off to say it. */
class Utt(val pcm: ByteArray, val barged: Boolean)

/**
 * Puts the phone's audio into "call" mode while EDITH is listening, so the hardware echo canceller
 * can remove EDITH's own voice from the microphone. Restores everything afterwards.
 */
object AudioRoute {
    private var saved: IntArray? = null

    fun headsetPresent(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return try {
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
                when (it.type) {
                    AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    AudioDeviceInfo.TYPE_USB_HEADSET -> true
                    else -> false
                }
            }
        } catch (e: Exception) { false }
    }

    @Suppress("DEPRECATION")
    @Synchronized
    fun enter(ctx: Context) {
        if (saved != null) return
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            saved = intArrayOf(am.mode, if (am.isSpeakerphoneOn) 1 else 0, am.getStreamVolume(AudioManager.STREAM_VOICE_CALL))
            if (headsetPresent(ctx)) return
            // keep the loudness the user is used to: map the media volume onto the call volume
            val mMax = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val mCur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val cMax = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL).coerceAtLeast(1)
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= 31) {
                val spk = am.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (spk != null) am.setCommunicationDevice(spk) else am.isSpeakerphoneOn = true
            } else am.isSpeakerphoneOn = true
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, (mCur * cMax / mMax).coerceIn(1, cMax), 0)
        } catch (e: Exception) {}
    }

    @Suppress("DEPRECATION")
    @Synchronized
    fun exit(ctx: Context) {
        val s = saved ?: return
        saved = null
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
            am.isSpeakerphoneOn = s[1] == 1
            am.mode = s[0]
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, s[2], 0)
        } catch (e: Exception) {}
    }
}

/**
 * EDITH's always-open ear (full duplex).
 *
 * It keeps the microphone running while EDITH talks. Voice activity detection cuts the audio into
 * utterances (with a short pre-roll so the first syllable is never lost). If you start talking over
 * EDITH, her volume ducks right away and, once the speech is confirmed, she stops mid-sentence and
 * your words are delivered as a normal utterance. Echo of her own voice is handled by the hardware
 * echo canceller plus an adaptive threshold that learns how loud her voice is in the microphone.
 */
class Ear(private val ctx: Context, private val voice: Voice) {
    companion object {
        const val RATE = 16000
        const val FRAME = 320            // 20 ms
        private const val PREROLL = 40   // 800 ms kept before the speech is confirmed
        private const val START_FRAMES = 6
        private const val DUCK_FRAMES = 5
        private const val CONFIRM_FRAMES = 12
        private const val END_SILENCE = 36
        private const val MAX_FRAMES = 750
        private const val MIN_VOICED = 10
    }

    private val main = Handler(Looper.getMainLooper())
    private val queue = ConcurrentLinkedQueue<Utt>()
    private val queued = AtomicInteger(0)
    private val fx = ArrayList<AudioEffect>()
    @Volatile private var running = false
    @Volatile private var routed = false
    @Volatile private var headset = false
    private var rec: AudioRecord? = null
    private var thread: Thread? = null

    /** True while the user is in the middle of saying something. */
    @Volatile var userTalking = false
        private set

    /** Goes up by one every time the user starts a new utterance. */
    @Volatile var startCount = 0
        private set

    /** Smoothed microphone level (0 to about 8000) for animations. */
    @Volatile var level = 0f
        private set

    val isRunning: Boolean get() = running

    /** Starts listening. Returns null on success, or a message explaining why the microphone couldn't open. */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun start(): String? {
        if (running) return null
        if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            return Voice.errorText(9)
        queue.clear(); queued.set(0)
        headset = AudioRoute.headsetPresent(ctx)
        if (Prefs.echoGuard) { AudioRoute.enter(ctx); routed = true; voice.comm = true }
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { release(); return "This phone's microphone doesn't support 16 kHz recording." }
        var r: AudioRecord? = null
        for (src in intArrayOf(MediaRecorder.AudioSource.VOICE_COMMUNICATION, MediaRecorder.AudioSource.MIC)) {
            try {
                val x = AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, FRAME * 2 * 16))
                if (x.state == AudioRecord.STATE_INITIALIZED) { r = x; break } else x.release()
            } catch (e: Exception) {}
        }
        if (r == null) { release(); return "Couldn't open the microphone. Another app may be using it." }
        attachEffects(r.audioSessionId)
        try {
            r.startRecording()
        } catch (e: Exception) {
            try { r.release() } catch (e2: Exception) {}
            release()
            return "Couldn't start the microphone."
        }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            try { r.release() } catch (e: Exception) {}
            release()
            return "Couldn't start the microphone. Another app may be using it."
        }
        rec = r
        running = true
        val rr = r
        thread = Thread({ loop(rr) }, "edith-ear").also { it.start() }
        return null
    }

    @Synchronized
    fun stop() {
        running = false
        val t = thread
        thread = null
        try { t?.join(600) } catch (e: Exception) {}
        val r = rec
        rec = null
        if (r != null) {
            try { r.stop() } catch (e: Exception) {}
            for (e in fx) try { e.release() } catch (x: Exception) {}
            fx.clear()
            try { r.release() } catch (e: Exception) {}
        }
        userTalking = false
        level = 0f
        release()
    }

    private fun release() {
        if (routed) { routed = false; voice.comm = false; AudioRoute.exit(ctx) }
    }

    private fun attachEffects(id: Int) {
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(id)?.let { it.setEnabled(true); fx.add(it) } } catch (e: Exception) {}
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(id)?.let { it.setEnabled(true); fx.add(it) } } catch (e: Exception) {}
        try { if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(id)?.let { it.setEnabled(true); fx.add(it) } } catch (e: Exception) {}
    }

    /** Next finished utterance, or null if none is waiting. */
    fun poll(): Utt? {
        val u = queue.poll()
        if (u != null) queued.decrementAndGet()
        return u
    }

    fun pending(): Boolean = queued.get() > 0

    fun drain() { queue.clear(); queued.set(0) }

    /** Waits for the next utterance. Returns null on timeout, on [abort], or if the microphone stopped. */
    suspend fun next(timeoutMs: Long = Long.MAX_VALUE, abort: () -> Boolean = { false }): Utt? {
        val end = if (timeoutMs == Long.MAX_VALUE) Long.MAX_VALUE else SystemClock.elapsedRealtime() + timeoutMs
        while (true) {
            val u = poll()
            if (u != null) return u
            if (!running || abort() || SystemClock.elapsedRealtime() >= end) return null
            delay(25)
        }
    }

    private fun writeFrame(out: ByteArrayOutputStream, f: ShortArray) {
        val b = ByteArray(f.size * 2)
        for (i in f.indices) {
            val s = f[i].toInt()
            b[i * 2] = (s and 0xFF).toByte()
            b[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
        }
        out.write(b, 0, b.size)
    }

    private fun loop(r: AudioRecord) {
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) {}
        val buf = ShortArray(FRAME)
        val ring = ArrayDeque<ShortArray>()
        var utt: ByteArrayOutputStream? = null
        var inSpeech = false
        var barged = false
        var hot = 0
        var silence = 0
        var frames = 0
        var voiced = 0
        var noise = 120f
        var echo = 0f
        var audFrames = 0
        var wasAudible = false
        var ducked = false
        val sens = when (Prefs.bargeSens) { "low" -> 1.5f; "high" -> 0.7f; else -> 1.0f }
        val canBarge = Prefs.fullDuplex

        while (running) {
            var got = 0
            while (got < FRAME && running) {
                val n = try { r.read(buf, got, FRAME - got) } catch (e: Exception) { -1 }
                if (n < 0) { running = false; break }
                if (n == 0) { try { Thread.sleep(5) } catch (e: Exception) {}; continue }
                got += n
            }
            if (got < FRAME) break

            var sum = 0.0
            for (i in 0 until FRAME) { val s = buf[i].toInt(); sum += (s * s).toDouble() }
            val rms = sqrt(sum / FRAME).toFloat()
            level = level * 0.7f + rms * 0.3f

            val busy = voice.busy
            val audible = voice.audible
            if (audible) {
                if (!wasAudible) { audFrames = 0; echo = max(rms, noise) }
                audFrames++
            }
            wasAudible = audible

            val idleThr = max(noise * 3f, 300f)
            val playThr = max(max(echo * 2.4f, noise * 4f), 600f) * sens * (if (headset) 0.6f else 1f)
            var voicedNow = if (audible) (audFrames >= 10 && rms > playThr) else rms > idleThr
            if (busy && !canBarge) voicedNow = false

            if (audible && rms < playThr) {
                val a = if (audFrames < 15) 0.25f else 0.03f
                echo = echo * (1f - a) + rms * a
            }

            if (!inSpeech) {
                ring.addLast(buf.copyOf())
                if (ring.size > PREROLL) ring.removeFirst()
                if (voicedNow) hot++ else hot = max(0, hot - 2)
                if (!voicedNow && !audible) noise = (noise * 0.98f + rms * 0.02f).coerceIn(40f, 2500f)

                if (!busy) ducked = false
                if (busy && hot >= DUCK_FRAMES && !ducked) { ducked = true; main.post { voice.duck(true) } }
                if (busy && hot == 0 && ducked) { ducked = false; main.post { voice.duck(false) } }

                val needed = if (busy) CONFIRM_FRAMES else START_FRAMES
                if (hot >= needed) {
                    inSpeech = true
                    barged = busy
                    silence = 0
                    voiced = hot
                    frames = ring.size
                    val o = ByteArrayOutputStream()
                    for (f in ring) writeFrame(o, f)
                    utt = o
                    ring.clear()
                    userTalking = true
                    startCount++
                    if (busy) main.post { voice.stopSpeaking() }
                    ducked = false
                }
            } else {
                val o = utt
                if (o != null) writeFrame(o, buf)
                frames++
                val stillVoiced = if (audible) voicedNow else rms > idleThr * 0.6f
                if (stillVoiced) { silence = 0; voiced++ } else silence++
                if (silence >= END_SILENCE || frames >= MAX_FRAMES) {
                    if (o != null && voiced >= MIN_VOICED) {
                        var bytes = o.toByteArray()
                        val trim = max(0, silence - 10) * FRAME * 2
                        if (trim > 0 && bytes.size - trim > FRAME * 2 * 5) bytes = bytes.copyOf(bytes.size - trim)
                        queue.add(Utt(bytes, barged))
                        queued.incrementAndGet()
                    }
                    inSpeech = false
                    userTalking = false
                    utt = null
                    hot = 0; silence = 0; frames = 0; voiced = 0; barged = false
                    ring.clear()
                }
            }
        }
        userTalking = false
    }
}
