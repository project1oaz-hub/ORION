package com.edith.assistant

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import org.json.JSONObject

data class Msg(val role: String, val text: String)

object Assistant {
    val history = mutableStateListOf<Msg>()
    var busy by mutableStateOf(false)
    // models sometimes write [[{'type': 'screen'}]] (no "do:", single quotes): accept that too (org.json reads single quotes)
    private val TAG = Regex("\\[\\[\\s*(?:do\\s*:)?\\s*(\\{.*?\\})\\s*\\]\\]", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    // anything that still looks like a tag but couldn't be parsed is hidden rather than shown to the user
    private val STRAY = Regex("\\[\\[.*?\\]\\]", RegexOption.DOT_MATCHES_ALL)

    /** Call on the main thread. */
    suspend fun respond(ctx: Context, text: String, spoken: Boolean = false, image: ByteArray? = null): String {
        ChatStore.init(ctx)
        history.add(Msg("user", text))
        busy = true
        val reply = try {
            Actions.handle(ctx, text) ?: converse(ctx, spoken, image)
        } catch (e: kotlinx.coroutines.CancellationException) {
            // cancelled mid-thought: don't leave an unanswered message behind
            if (history.lastOrNull()?.role == "user") history.removeAt(history.lastIndex)
            busy = false
            throw e
        } catch (e: Exception) {
            "Sorry, something went wrong. ${e.message}"
        }
        history.add(Msg("assistant", reply))
        busy = false
        ChatStore.saveCurrent(ctx)
        return reply
    }

    /** Ask the AI; run any action tags it emits; for screen actions, loop (max 8 steps) so it can see and continue. */
    private suspend fun converse(ctx: Context, spoken: Boolean, image: ByteArray?): String {
        val convo = history.takeLast(20).toMutableList()
        var last = ""
        val problems = mutableListOf<String>()
        var steps = 0
        while (true) {
            val raw = try {
                Ai.chat(convo, spoken, if (steps == 0) image else null)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                return "Sorry, I couldn't reach the AI. ${e.message}"
            }
            val tags = TAG.findAll(raw).map { it.groupValues[1] }.toList()
            val clean = raw.replace(TAG, "").replace(STRAY, "").trim()
            if (clean.isNotBlank()) last = clean
            if (tags.isEmpty()) break
            val results = StringBuilder()
            var more = false
            var opened = false
            var needObs = false
            var screenish = false
            var gotData = false
            for (t in tags) {
                try {
                    val j = JSONObject(t)
                    val type = j.optString("type")
                    val r = when {
                        type == "screen" -> Phone.screen()
                        type in Tools.types -> Tools.run(ctx, j)
                        else -> Phone.run(ctx, j)
                    }
                    results.append(r.msg).append('\n')
                    // data tools (web, weather...) report errors back to the AI, which explains them itself
                    if (!r.ok && type !in Tools.types) problems.add(r.msg)
                    if (type in Tools.types) { more = true; gotData = true }
                    if (type in Phone.screenTypes) { more = true; screenish = true }
                    if (type in Phone.screenTypes && type != "screen") needObs = true
                    if (type == "open") opened = true
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    results.append("Bad action.\n")
                }
            }
            if (!more || ++steps >= 8) break
            if (screenish) delay(if (opened) 1800L else 900L)
            convo.add(Msg("assistant", raw))
            convo.add(Msg("user", "[system] Action results: $results" + (if (needObs) "\nCurrent screen:\n${Phone.observe()}" else "") + "\n" + (if (gotData) "\nAnswer the user from this data in a short spoken-style reply. Do not read out URLs." else "") + "\nContinue the task, or give a short final reply with no action tags if finished."))
        }
        var out = last.ifBlank { "Done." }
        if (problems.isNotEmpty()) out += "\n" + problems.joinToString(" ")
        return out
    }
}
