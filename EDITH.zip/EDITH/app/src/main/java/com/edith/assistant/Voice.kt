package com.edith.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

private object SpeechEnd
private class SpeechFail(val index: Int)

/**
 * EDITH's voice. Speaks replies sentence by sentence (the next sentence is synthesised while the
 * current one plays, so she starts talking sooner), can be ducked or stopped instantly when you
 * interrupt her, and keeps the classic one-shot Android recogniser as a fallback listener.
 */
class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var initDone = false
    private var waiting: (() -> Unit)? = null
    private var tts: TextToSpeech? = null
    private var current: SpeechRecognizer? = null
    private var listenCb: ((String?) -> Unit)? = null
    private var pendingDone: (() -> Unit)? = null
    @Volatile private var speakId = 0
    @Volatile private var track: AudioTrack? = null
    @Volatile private var natBlockedUntil = 0L
    var lastError = 0

    /** True from the moment a reply is requested until it has finished or been stopped. */
    @Volatile var busy = false

    /** True only while sound is actually coming out of the speaker. */
    @Volatile var audible = false

    /** Set by [Ear] while the microphone is open in full-duplex mode: plays through the call audio path. */
    @Volatile var comm = false

    /** Plain text of what EDITH most recently said (used to spot her own echo). */
    @Volatile var lastSpoken = ""

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.language = Locale.getDefault()
            main.post { initDone = true; val w = waiting; waiting = null; w?.invoke() }
        }
    }

    companion object {
        fun errorText(c: Int): String = when (c) {
            -1 -> "No speech recognition service found. Install or enable the Google app."
            1 -> "Network timeout. Speech recognition needs internet."
            2 -> "Network error. Check your connection."
            3 -> "Audio problem. Another app may be using the microphone."
            4 -> "Speech server error. Try again."
            5 -> "Speech service error."
            6 -> "I didn't hear anything."
            7 -> "I couldn't understand that."
            8 -> "Speech recogniser is busy. Try again."
            9 -> "Microphone permission is missing. Allow it in app settings."
            else -> "Speech error $c"
        }
    }

    private fun finish() {
        busy = false
        audible = false
        val d = pendingDone
        pendingDone = null
        d?.invoke()
    }

    private fun stopQuiet() {
        speakId++
        waiting = null
        audible = false
        try { tts?.stop() } catch (e: Exception) {}
        val t = track
        track = null
        if (t != null) {
            try { t.pause(); t.flush() } catch (e: Exception) {}
            try { t.stop() } catch (e: Exception) {}
            try { t.release() } catch (e: Exception) {}
        }
    }

    /** Lowers EDITH's volume while you start talking over her (only for the natural voice). */
    fun duck(on: Boolean) {
        try { track?.setVolume(if (on) 0.2f else 1f) } catch (e: Exception) {}
    }

    /** Speaks text; [done] fires once when finished OR interrupted. [fast] forces the instant phone voice. */
    fun speak(text: String, fast: Boolean = false, done: () -> Unit = {}) {
        val prev = pendingDone
        stopQuiet()
        pendingDone = done
        busy = true
        val id = speakId
        if (prev != null) main.post { prev() }
        val clean = text.replace(Regex("[*_#`]"), "").replace(EMOJI, "").replace(Regex("[ \\t]{2,}"), " ").trim()
        lastSpoken = clean
        if (clean.isEmpty()) { finish(); return }
        val useNatural = !fast && Prefs.naturalVoice && Prefs.geminiKey.isNotBlank() && System.currentTimeMillis() >= natBlockedUntil
        if (useNatural) natural(clean, id) else sys(clean, id)
    }

    fun stopSpeaking() { stopQuiet(); finish() }

    fun shutdown() {
        stopQuiet()
        busy = false
        pendingDone = null
        try { current?.destroy() } catch (e: Exception) {}
        current = null
        try { tts?.shutdown() } catch (e: Exception) {}
    }

    // ------------------------------------------------------------------ system voice

    private fun sys(text: String, id: Int) {
        if (id != speakId) return
        if (!initDone) { waiting = { sys(text, id) }; return }
        val t = tts
        if (t == null || !ready) { finish(); return }
        val uid = id.toString()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) { main.post { if (id == speakId && u == uid) audible = true } }
            override fun onDone(u: String?) { main.post { if (id == speakId && u == uid) finish() } }
            override fun onStop(u: String?, interrupted: Boolean) { main.post { if (id == speakId && u == uid) finish() } }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { main.post { if (id == speakId && u == uid) finish() } }
        })
        t.setAudioAttributes(attrs())
        t.setSpeechRate(Prefs.rate)
        t.setPitch(Prefs.pitch)
        if (t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, uid) == TextToSpeech.ERROR) finish()
    }

    private fun attrs(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(if (comm) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    // ------------------------------------------------------------------ natural voice (Gemini TTS), streamed

    private fun chunks(text: String): List<String> {
        val sentences = text.split(Regex("(?<=[.!?\u2026])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (s in sentences) {
            if (cur.isNotEmpty() && cur.length + s.length > 200) { out.add(cur.toString()); cur.setLength(0) }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(s)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun natural(text: String, id: Int) {
        val all = chunks(text)
        val head = ArrayList<String>()
        var n = 0
        var i = 0
        while (i < all.size && n < 1200) { head.add(all[i]); n += all[i].length; i++ }
        val tail = all.drop(i).joinToString(" ")
        val q = LinkedBlockingQueue<Any>(2)
        Thread { produce(q, head, id) }.start()
        Thread { playLoop(q, head, tail, id) }.start()
    }

    private fun offer(q: LinkedBlockingQueue<Any>, x: Any, id: Int): Boolean {
        while (id == speakId) {
            try { if (q.offer(x, 100, TimeUnit.MILLISECONDS)) return true } catch (e: InterruptedException) { return false }
        }
        return false
    }

    private fun produce(q: LinkedBlockingQueue<Any>, head: List<String>, id: Int) {
        var idx = 0
        for (c in head) {
            if (id != speakId) return
            val pcm = try {
                runBlocking { Ai.tts(c) }
            } catch (e: Exception) {
                val m = e.message ?: ""
                if (m.contains("429") || m.contains("quota", true)) natBlockedUntil = System.currentTimeMillis() + 45_000
                null
            }
            if (pcm == null) { offer(q, SpeechFail(idx), id); return }
            if (!offer(q, pcm, id)) return
            idx++
        }
        offer(q, SpeechEnd, id)
    }

    private fun makeTrack(rate: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(attrs())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min * 4, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun playLoop(q: LinkedBlockingQueue<Any>, head: List<String>, tail: String, id: Int) {
        var t: AudioTrack? = null
        var frames = 0L
        var rate = 24000
        var failAt = -1
        try {
            while (id == speakId) {
                val item = q.poll(100, TimeUnit.MILLISECONDS) ?: continue
                if (item is Pcm) {
                    if (t == null) {
                        rate = item.rate
                        val nt = makeTrack(rate)
                        t = nt
                        track = nt
                        if (id != speakId) { track = null; try { nt.release() } catch (e: Exception) {}; return }
                        nt.play()
                        audible = true
                    }
                    val tr = t
                    var off = 0
                    while (tr != null && off < item.bytes.size && id == speakId) {
                        val w = tr.write(item.bytes, off, item.bytes.size - off)
                        if (w < 0) break
                        if (w == 0) Thread.sleep(5)
                        off += w
                    }
                    frames += item.bytes.size / 2
                } else if (item is SpeechFail) {
                    failAt = item.index
                    break
                } else break
            }
            if (id != speakId) return
            val tr = t
            if (tr != null) {
                // let the audio that is already buffered finish playing
                val deadline = System.currentTimeMillis() + frames * 1000L / rate + 2500
                while (id == speakId && System.currentTimeMillis() < deadline) {
                    val pos = try { tr.playbackHeadPosition.toLong() } catch (e: Exception) { frames }
                    if (pos >= frames) break
                    Thread.sleep(20)
                }
            }
            if (id != speakId) return
            val remaining = if (failAt >= 0) head.drop(failAt).joinToString(" ") + (if (tail.isNotBlank()) " $tail" else "") else tail
            main.post {
                if (id == speakId) {
                    val cur = track
                    track = null
                    if (cur != null) {
                        try { cur.stop() } catch (e: Exception) {}
                        try { cur.release() } catch (e: Exception) {}
                    }
                    audible = false
                    if (remaining.isNotBlank()) sys(remaining, id) else finish()
                }
            }
        } catch (e: Exception) {
            // anything went wrong with the streamed audio: say the whole reply with the phone voice instead
            main.post {
                if (id == speakId) {
                    val cur = track
                    track = null
                    if (cur != null) { try { cur.release() } catch (x: Exception) {} }
                    audible = false
                    sys(lastSpoken, id)
                }
            }
        }
    }

    // ------------------------------------------------------------------ classic one-shot recogniser (fallback)

    fun cancelListen() {
        main.post {
            val cb = listenCb
            listenCb = null
            try { current?.destroy() } catch (e: Exception) {}
            current = null
            if (cb != null) { lastError = 0; cb(null) }
        }
    }

    /** One-shot speech recognition. Callback gets null on failure/silence; see [lastError]. */
    fun listen(onResult: (String?) -> Unit) { main.post { start(0, onResult) } }

    /** Language for the phone's own recogniser: follows the Settings choice, otherwise the phone's language. */
    private fun deviceLang(): String {
        val def = Locale.getDefault()
        return when (Prefs.sttLang) {
            "ml" -> "ml-IN"
            "en" -> if (def.language == "en") def.toLanguageTag() else "en-IN"
            else -> def.toLanguageTag()
        }
    }

    private fun bias(): ArrayList<String> {
        val l = arrayListOf("EDITH", "Hey EDITH", "WhatsApp", "YouTube", "Spotify", "Instagram", "flashlight", "Google Maps")
        if (Prefs.name.isNotBlank()) l.add(Prefs.name.trim())
        return l
    }

    private fun start(i: Int, onResult: (String?) -> Unit) {
        val comps = listOf<ComponentName?>(null) + listOfNotNull(Recognizers.find(ctx))
        if (i >= comps.size) { lastError = -1; onResult(null); return }
        if (comps[i] == null && !SpeechRecognizer.isRecognitionAvailable(ctx)) { start(i + 1, onResult); return }
        val comp = comps[i]
        val r = if (comp != null) SpeechRecognizer.createSpeechRecognizer(ctx, comp) else SpeechRecognizer.createSpeechRecognizer(ctx)
        current = r
        listenCb = onResult
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val conf = b?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                var t = list?.firstOrNull()
                if (list != null && conf != null && conf.size == list.size && list.size > 1) {
                    var best = 0
                    for (k in conf.indices) if (conf[k] > conf[best]) best = k
                    t = list[best]
                }
                r.destroy(); if (current === r) current = null
                lastError = if (t.isNullOrBlank()) 7 else 0
                listenCb = null
                onResult(t)
            }
            override fun onError(e: Int) {
                r.destroy(); if (current === r) current = null
                if (e == SpeechRecognizer.ERROR_CLIENT && i + 1 < comps.size) start(i + 1, onResult)
                else { lastError = e; listenCb = null; onResult(null) }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, deviceLang())
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
        if (Build.VERSION.SDK_INT >= 33) intent.putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, bias())
        r.startListening(intent)
    }
}

/** Speaks and waits until finished or interrupted. Cancelling the coroutine stops the speech. */
suspend fun Voice.speakAwait(text: String, fast: Boolean = false) {
    suspendCancellableCoroutine<Unit> { c ->
        c.invokeOnCancellation { stopSpeaking() }
        speak(text, fast) { if (c.isActive) c.resume(Unit) }
    }
}

/** Emoji, pictographs and their joiners/modifiers: shown on screen, never read aloud. */
private val EMOJI = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2300}-\\x{23FF}\\x{2600}-\\x{27BF}\\x{2B00}-\\x{2BFF}\\x{203C}\\x{2049}\\x{200D}\\x{FE0F}\\x{20E3}]")
