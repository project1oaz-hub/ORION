package com.edith.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

class Voice(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var tts: TextToSpeech? = null
    private var current: SpeechRecognizer? = null
    private var utterance = ""

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.language = Locale.getDefault()
        }
    }

    /** Speaks text; [done] fires once when finished OR interrupted. */
    fun speak(text: String, done: () -> Unit = {}) {
        val t = tts
        if (t == null || !ready) { done(); return }
        val id = UUID.randomUUID().toString()
        utterance = id
        var fired = false
        fun fin(u: String?) { if (u == id && !fired) { fired = true; main.post { done() } } }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { fin(u) }
            override fun onStop(u: String?, interrupted: Boolean) { fin(u) }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { fin(u) }
        })
        t.setSpeechRate(Prefs.rate)
        t.speak(text.replace(Regex("[*_#`]"), "").take(3500), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stopSpeaking() { tts?.stop() }
    fun shutdown() { tts?.shutdown() }

    fun cancelListen() {
        main.post { try { current?.destroy() } catch (e: Exception) {}; current = null }
    }

    var lastError = 0

    companion object {
        fun errorText(c: Int): String = when (c) {
            -1 -> "No speech recognition service found. Install or enable the Google app."
            1 -> "Network timeout. Speech recognition needs internet."
            2 -> "Network error. Check your connection."
            3 -> "Audio problem. Another app may be using the microphone."
            4 -> "Speech server error. Try again."
            5 -> "Speech service error."
            6 -> "I didn't hear anything."
            7 -> "I couldn't understand that."
            8 -> "Speech recogniser is busy. Try again."
            9 -> "Microphone permission is missing. Allow it in app settings."
            else -> "Speech error $c"
        }
    }

    /** One-shot speech recognition. Callback gets null on failure/silence; see [lastError]. */
    fun listen(onResult: (String?) -> Unit) { main.post { start(0, onResult) } }

    private fun start(i: Int, onResult: (String?) -> Unit) {
        val comps = listOf<ComponentName?>(null) + listOfNotNull(Recognizers.find(ctx))
        if (i >= comps.size) { lastError = -1; onResult(null); return }
        if (comps[i] == null && !SpeechRecognizer.isRecognitionAvailable(ctx)) { start(i + 1, onResult); return }
        val comp = comps[i]
        val r = if (comp != null) SpeechRecognizer.createSpeechRecognizer(ctx, comp) else SpeechRecognizer.createSpeechRecognizer(ctx)
        current = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                r.destroy(); if (current === r) current = null
                lastError = if (t.isNullOrBlank()) 7 else 0
                onResult(t)
            }
            override fun onError(e: Int) {
                r.destroy(); if (current === r) current = null
                if (e == SpeechRecognizer.ERROR_CLIENT && i + 1 < comps.size) start(i + 1, onResult)
                else { lastError = e; onResult(null) }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        )
    }
}
