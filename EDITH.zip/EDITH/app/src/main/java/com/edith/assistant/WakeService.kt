package com.edith.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import kotlin.coroutines.resume

class WakeService : Service(), RecognitionListener {
    companion object {
        fun start(ctx: Context): Boolean {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
            return true
        }
        @Volatile var instance: WakeService? = null
        fun pause() { instance?.pauseMic() }
        fun resume() { instance?.resumeMic() }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var model: Model? = null
    private var speech: SpeechService? = null
    private lateinit var voice: Voice
    private var busy = false
    private var started = false
    private var paused = false

    fun pauseMic() { paused = true; speech?.shutdown(); speech = null }
    fun resumeMic() { paused = false; if (model != null && speech == null && !busy) listen() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        instance = this
        voice = Voice(applicationContext)
        val ch = NotificationChannel("edith", "EDITH", NotificationManager.IMPORTANCE_MIN)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        ServiceCompat.startForeground(
            this, 1, notif("Starting…"),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!started) { started = true; load() }
        return START_STICKY
    }

    private fun load() {
        scope.launch {
            note("Downloading voice model (~40 MB)…")
            val dir = withContext(Dispatchers.IO) { ModelManager.ensure(this@WakeService) }
            if (dir == null) {
                note("Voice model download failed. Check internet, then toggle wake word.")
                started = false
                return@launch
            }
            model = withContext(Dispatchers.IO) { ModelManager.model(this@WakeService, true) }
            if (model == null) {
                note("Couldn't load the voice model. Toggle wake word to retry.")
                started = false
                return@launch
            }
            note("Listening for \"Hey EDITH\"")
            listen()
            // the offline Whisper model (English + Malayalam) is needed to understand what you say after the wake word
            if (!Prefs.deviceStt && !WhisperModels.installed(this@WakeService)) {
                var last = -10
                val ok = withContext(Dispatchers.IO) {
                    WhisperModels.download(this@WakeService) { p ->
                        if (p >= last + 5) { last = p; note("Downloading speech model… $p%") }
                    }
                }
                note(if (ok) "Listening for \"Hey EDITH\"" else "Speech model download failed. Open Settings > Speech recognition to retry.")
            }
        }
    }

    private fun listen() {
        busy = false
        if (paused) return
        val m = model ?: return
        try {
            speech?.shutdown()
            speech = null
            val rec = Recognizer(m, 16000f, "[\"hey edith\", \"hey edit\", \"[unk]\"]")
            speech = SpeechService(rec, 16000f)
            speech?.startListening(this)
        } catch (e: Exception) {
            note("Mic error: ${e.message}")
        }
    }

    private fun check(h: String?) {
        val t = h ?: return
        if (!paused && !busy && t.contains("hey ed")) wake()
    }

    private fun wake() {
        busy = true
        speech?.shutdown()
        speech = null
        scope.launch {
            try {
                session()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                note("Voice error: ${e.message}")
            } finally {
                voice.stopSpeaking()
                if (instance === this@WakeService) listen()
            }
        }
    }

    /**
     * "Hey EDITH" starts a short hands-free conversation: she answers, you can interrupt her
     * mid-sentence, and she keeps listening for a follow-up for a few seconds before going back to sleep.
     */
    private suspend fun session() {
        voice.speakAwait("Yes?", true)
        val ear = Ear(applicationContext, voice)
        val err: String? = if (Prefs.deviceStt) "" else ear.start()
        try {
            if (err != null) {
                // microphone engine unavailable: classic single question and answer
                val t = suspendCancellableCoroutine<String?> { c ->
                    c.invokeOnCancellation { voice.cancelListen() }
                    voice.listen { if (c.isActive) c.resume(it) }
                }
                if (t.isNullOrBlank()) return
                voice.speakAwait(Assistant.respond(this, t, spoken = true))
                return
            }
            var first = true
            var misses = 0
            while (misses < 3) {
                val u = ear.next(if (first) 7000L else 6000L) ?: break
                val r = Stt.transcribe(applicationContext, u.pcm)
                val text = r.text.orEmpty().trim()
                if (text.isBlank() || (u.barged && Stt.echoOf(text, voice.lastSpoken))) { misses++; continue }
                if (u.barged && Stt.isStop(text)) { continue }
                first = false
                misses = 0
                val reply = Assistant.respond(this, text, spoken = true)
                voice.speakAwait(reply)
            }
        } finally {
            ear.stop()
        }
    }

    override fun onPartialResult(h: String?) { check(h) }
    override fun onResult(h: String?) { check(h) }
    override fun onFinalResult(h: String?) {}
    override fun onError(e: Exception?) { restartSoon() }
    override fun onTimeout() { restartSoon() }

    /** The wake-word recogniser died (mic taken by another app, etc.): bring it back after a moment. */
    private fun restartSoon() {
        if (paused || busy || model == null) return
        speech?.shutdown()
        speech = null
        scope.launch {
            delay(1200)
            if (!paused && !busy && speech == null) listen()
        }
    }

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "edith")
            .setSmallIcon(R.drawable.ic_edith).setContentTitle("EDITH").setContentText(text)
            .setOngoing(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_MIN).build()
    }

    private fun note(t: String) {
        getSystemService(NotificationManager::class.java).notify(1, notif(t))
    }

    override fun onDestroy() {
        instance = null
        scope.cancel()
        speech?.shutdown()
        voice.shutdown()
        super.onDestroy()
    }
}
