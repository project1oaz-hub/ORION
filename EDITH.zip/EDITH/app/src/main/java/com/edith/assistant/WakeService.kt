package com.edith.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

class WakeService : Service(), RecognitionListener {
    companion object {
        fun start(ctx: Context): Boolean {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
            return true
        }
        @Volatile var instance: WakeService? = null
        fun pause() { instance?.pauseMic() }
        fun resume() { instance?.resumeMic() }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var model: Model? = null
    private var speech: SpeechService? = null
    private lateinit var voice: Voice
    private var busy = false
    private var started = false
    private var paused = false

    fun pauseMic() { paused = true; speech?.shutdown(); speech = null }
    fun resumeMic() { paused = false; if (model != null && speech == null && !busy) listen() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        instance = this
        voice = Voice(applicationContext)
        val ch = NotificationChannel("edith", "EDITH", NotificationManager.IMPORTANCE_MIN)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        ServiceCompat.startForeground(
            this, 1, notif("Starting…"),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!started) { started = true; load() }
        return START_STICKY
    }

    private fun load() {
        scope.launch {
            note("Downloading voice model (~40 MB)…")
            val dir = withContext(Dispatchers.IO) { ModelManager.ensure(this@WakeService) }
            if (dir == null) {
                note("Voice model download failed. Check internet, then toggle wake word.")
                started = false
                return@launch
            }
            model = withContext(Dispatchers.IO) { Model(dir.absolutePath) }
            note("Listening for \"Hey EDITH\"")
            listen()
        }
    }

    private fun listen() {
        busy = false
        if (paused) return
        try {
            val rec = Recognizer(model, 16000f, "[\"hey edith\", \"hey edit\", \"[unk]\"]")
            speech = SpeechService(rec, 16000f)
            speech?.startListening(this)
        } catch (e: Exception) {
            note("Mic error: ${e.message}")
        }
    }

    private fun check(h: String?) {
        val t = h ?: return
        if (!paused && !busy && t.contains("hey ed")) wake()
    }

    private fun wake() {
        busy = true
        speech?.shutdown()
        speech = null
        voice.speak("Yes?") {
            voice.listen { t ->
                if (t.isNullOrBlank()) listen() else scope.launch {
                    val r = Assistant.respond(this@WakeService, t, spoken = true)
                    voice.speak(r) { listen() }
                }
            }
        }
    }

    override fun onPartialResult(h: String?) { check(h) }
    override fun onResult(h: String?) { check(h) }
    override fun onFinalResult(h: String?) {}
    override fun onError(e: Exception?) {}
    override fun onTimeout() {}

    private fun notif(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "edith")
            .setSmallIcon(R.drawable.ic_edith).setContentTitle("EDITH").setContentText(text)
            .setOngoing(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_MIN).build()
    }

    private fun note(t: String) {
        getSystemService(NotificationManager::class.java).notify(1, notif(t))
    }

    override fun onDestroy() {
        instance = null
        scope.cancel()
        speech?.shutdown()
        model?.close()
        voice.shutdown()
        super.onDestroy()
    }
}
