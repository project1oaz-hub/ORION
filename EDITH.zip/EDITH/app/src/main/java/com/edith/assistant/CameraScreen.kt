package com.edith.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.hypot

private fun cardinal(h: Float): String =
    arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")[(((h + 22.5f) / 45f).toInt()) % 8]

/** EDITH's visual sense: ask about what the camera sees, with a heads-up display (compass, horizon, stats, live tags). */
@Composable
fun CameraScreen(voice: Voice, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    BackHandler(true) { voice.stopSpeaking(); onBack() }

    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var liveScan by remember { mutableStateOf(false) }
    var tags by remember { mutableStateOf<List<String>>(emptyList()) }
    var heading by remember { mutableStateOf(0f) }
    var pitch by remember { mutableStateOf(0f) }
    var roll by remember { mutableStateOf(0f) }
    var clock by remember { mutableStateOf("") }
    var battery by remember { mutableStateOf(0) }
    var camError by remember { mutableStateOf("") }

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    // camera
    DisposableEffect(granted) {
        val future = ProcessCameraProvider.getInstance(ctx)
        if (granted) {
            future.addListener({
                try {
                    val provider = future.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                } catch (e: Exception) { camError = "Camera error: ${e.message}" }
            }, ContextCompat.getMainExecutor(ctx))
        }
        onDispose { try { if (future.isDone) future.get().unbindAll() } catch (e: Exception) {} }
    }

    // orientation sensors (compass heading, camera pitch, horizon roll)
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val r = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(r, e.values)
                // camera looks along -Z of the phone; r maps phone axes to world (east, north, up)
                val east = -r[2]; val north = -r[5]; val up = -r[8]
                heading = ((Math.toDegrees(atan2(east.toDouble(), north.toDouble())) + 360.0) % 360.0).toFloat()
                pitch = Math.toDegrees(asin(up.coerceIn(-1f, 1f).toDouble())).toFloat()
                roll = Math.toDegrees(atan2(r[6].toDouble(), r[7].toDouble())).toFloat()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }

    // clock + battery
    LaunchedEffect(Unit) {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (isActive) {
            clock = fmt.format(Date())
            battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            delay(1000)
        }
    }

    fun grab(): ByteArray? {
        val b = previewView.bitmap ?: return null
        val k = 1024f / maxOf(b.width, b.height)
        val sc = if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true) else b
        val out = ByteArrayOutputStream()
        sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return out.toByteArray()
    }

    fun ask(q: String) {
        if (busy) return
        val jpg = grab()
        if (jpg == null) { answer = "The camera isn't ready yet. Try again in a second."; return }
        busy = true
        answer = ""
        scope.launch {
            answer = try { Ai.vision(q.ifBlank { Vision.DEFAULT }, jpg) } catch (e: Exception) { "Sorry. ${e.message}" }
            busy = false
            if (Prefs.speak) voice.speak(answer)
        }
    }

    // a question that came from a voice/chat command
    LaunchedEffect(granted) {
        if (granted) {
            val p = Vision.pendingPrompt
            if (p != null) { Vision.pendingPrompt = null; delay(1500); ask(p) }
        }
    }

    // live scan: a few labels every few seconds
    LaunchedEffect(liveScan, granted) {
        while (liveScan && granted && isActive) {
            delay(4000)
            if (!busy) {
                val jpg = grab()
                if (jpg != null) tags = try { Ai.labels(jpg) } catch (e: Exception) { emptyList() }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (granted) AndroidView({ previewView }, Modifier.fillMaxSize())
        else Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("EDITH needs camera permission to see.", color = Color.White)
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
        }

        // heads-up display
        Canvas(Modifier.fillMaxSize()) {
            val a = Theme.accent
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val r = minOf(w, h) * 0.22f
            val len = r * 0.35f
            val sw = 3.dp.toPx()
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(a, Offset(x, y), Offset(x + dx * len, y), sw)
                drawLine(a, Offset(x, y), Offset(x, y + dy * len), sw)
            }
            corner(cx - r, cy - r, 1f, 1f); corner(cx + r, cy - r, -1f, 1f)
            corner(cx - r, cy + r, 1f, -1f); corner(cx + r, cy + r, -1f, -1f)
            val arm = 12.dp.toPx()
            drawLine(a.copy(alpha = 0.8f), Offset(cx - arm, cy), Offset(cx + arm, cy), 2.dp.toPx())
            drawLine(a.copy(alpha = 0.8f), Offset(cx, cy - arm), Offset(cx, cy + arm), 2.dp.toPx())

            // artificial horizon: shifts with camera pitch, tilts with phone roll
            val hy = cy + pitch * (h / 90f)
            rotate(roll, Offset(cx, cy)) {
                drawLine(Color.White.copy(alpha = 0.55f), Offset(cx - w * 0.38f, hy), Offset(cx - w * 0.08f, hy), 2.dp.toPx())
                drawLine(Color.White.copy(alpha = 0.55f), Offset(cx + w * 0.08f, hy), Offset(cx + w * 0.38f, hy), 2.dp.toPx())
            }

            // compass ring: red marker points to north
            val rc = Offset(w - 52.dp.toPx(), 150.dp.toPx())
            val rr = 28.dp.toPx()
            drawCircle(Color.White.copy(alpha = 0.5f), rr, rc, style = Stroke(2.dp.toPx()))
            rotate(-heading, rc) {
                val p = Path().apply {
                    moveTo(rc.x, rc.y - rr)
                    lineTo(rc.x - 6.dp.toPx(), rc.y - rr + 14.dp.toPx())
                    lineTo(rc.x + 6.dp.toPx(), rc.y - rr + 14.dp.toPx())
                    close()
                }
                drawPath(p, Color(0xFFF28B82))
            }
            drawCircle(a, 3.dp.toPx(), rc)
        }

        Column(Modifier.align(Alignment.TopStart).fillMaxWidth().systemBarsPadding().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { voice.stopSpeaking(); onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                Text("VISUAL SENSE", color = Color.White, fontSize = 14.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                Text("Live scan", color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.width(6.dp))
                Switch(checked = liveScan, onCheckedChange = { liveScan = it; if (!it) tags = emptyList() })
            }
            Text("$clock  ·  $battery%  ·  ${cardinal(heading)} ${heading.toInt()}°  ·  tilt ${pitch.toInt()}°",
                color = Theme.accent, fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp, top = 4.dp))
            if (camError.isNotEmpty()) Text(camError, color = Color(0xFFF28B82), fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp))
            tags.forEach { t ->
                Surface(
                    shape = RoundedCornerShape(12.dp), color = Color(0x99000000), border = BorderStroke(1.dp, Theme.accent),
                    modifier = Modifier.padding(start = 12.dp, top = 6.dp)
                ) { Text(t, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) }
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().imePadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (busy || answer.isNotEmpty()) {
                Surface(shape = RoundedCornerShape(20.dp), color = Color(0xE61E1F20)) {
                    Text(
                        if (busy) "Looking…" else answer, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp,
                        modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()).padding(16.dp)
                    )
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Identify" to "Identify what is in view and describe it briefly.",
                    "Read text" to "Read out all the text you can see, exactly.",
                    "Explain error" to "There may be an error message or code here. Read it, explain what it means and how to fix it.",
                    "Summarize" to "Summarize this document or page in a few sentences."
                ).forEach { (label, q) ->
                    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xE61E1F20), modifier = Modifier.clickable { ask(q) }) {
                        Text(label, color = Theme.accent, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                    }
                }
            }
            Surface(shape = RoundedCornerShape(32.dp), color = Color(0xE61E1F20)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = prompt, onValueChange = { prompt = it },
                        placeholder = { Text("Ask about what you see", color = Muted) },
                        modifier = Modifier.weight(1f), maxLines = 2,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Theme.accent
                        )
                    )
                    IconButton(onClick = {
                        voice.stopSpeaking()
                        WakeService.pause()
                        voice.listen { t -> WakeService.resume(); if (t != null) ask(t) }
                    }) { Icon(Icons.Default.Mic, "Ask by voice", tint = Theme.accent) }
                    IconButton(onClick = { ask(prompt); prompt = "" }) { Icon(Icons.AutoMirrored.Filled.Send, "Ask", tint = Theme.accent) }
                }
            }
        }
    }
}
