package com.edith.assistant

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

/** Executes the action tags the AI emits. Everything here only acts on the user's request. */
object Phone {
    data class Res(val ok: Boolean, val msg: String)
    private fun ok(m: String = "Done.") = Res(true, m)
    private fun no(m: String) = Res(false, m)
    private fun go(ctx: Context, i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    val screenTypes = setOf("observe", "tap", "type", "scroll", "global", "open")

    fun observe(): String = EdithAccessibilityService.instance?.dump() ?: "Screen access is off."

    fun run(ctx: Context, j: JSONObject): Res = try { exec(ctx, j) } catch (e: Exception) { no("That didn't work: ${e.message}") }

    private fun exec(ctx: Context, j: JSONObject): Res {
        val type = j.optString("type")
        if (type in setOf("observe", "tap", "type", "scroll", "global")) {
            val s = EdithAccessibilityService.instance
            if (s == null) {
                go(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return no("Turn on EDITH under Accessibility settings, then ask again.")
            }
            return when (type) {
                "observe" -> ok(s.dump())
                "tap" -> s.tap(j.optInt("index", -1), j.optString("text")).let { Res(it == "Tapped.", it) }
                "type" -> s.type(j.optString("text"), j.optInt("index", -1)).let { Res(it == "Typed.", it) }
                "scroll" -> s.scroll(j.optString("dir", "down")).let { Res(it == "Scrolled.", it) }
                else -> s.global(j.optString("cmd")).let { Res(it == "Done.", it) }
            }
        }
        return when (type) {
            "open" -> Actions.open(ctx, j.optString("app")).let { Res(it.startsWith("Opening"), it) }
            "alarm" -> alarm(ctx, j.getInt("hour"), j.optInt("minute", 0), j.optString("label"))
            "timer" -> timer(ctx, j.getInt("seconds"), j.optString("label"))
            "reminder" -> reminder(ctx, j)
            "calendar" -> calendar(ctx, j)
            "maps" -> maps(ctx, j.getString("destination"), j.optString("mode", "drive"))
            "search" -> {
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(j.getString("query")))))
                ok("Searching.")
            }
            "camera" -> {
                go(ctx, Intent(if (j.optString("mode") == "video") MediaStore.INTENT_ACTION_VIDEO_CAMERA else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                ok("Camera open.")
            }
            "media" -> media(ctx, j.optString("cmd"))
            "volume" -> volume(ctx, j)
            "brightness" -> brightness(ctx, j.getInt("level"))
            "message" -> message(ctx, j.optString("app", "sms"), j.optString("to"), j.optString("text"))
            "dnd" -> dnd(ctx, j.optBoolean("on", true))
            "settings" -> settings(ctx, j.optString("page"))
            else -> no("I don't know that action.")
        }
    }

    private fun alarm(ctx: Context, h: Int, m: Int, label: String): Res {
        go(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return ok("Alarm set.")
    }

    private fun timer(ctx: Context, sec: Int, label: String): Res {
        go(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec.coerceIn(1, 86400))
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return ok("Timer started.")
    }

    private fun millis(iso: String): Long =
        LocalDateTime.parse(iso).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun reminder(ctx: Context, j: JSONObject): Res {
        val at = LocalDateTime.parse(j.getString("at"))
        val text = j.optString("text", "Reminder")
        val ms = millis(j.getString("at"))
        if (ms - System.currentTimeMillis() > 24L * 3600 * 1000) {
            return calendar(ctx, JSONObject().put("title", text).put("start", j.getString("at"))
                .put("end", at.plusMinutes(15).toString()))
        }
        return alarm(ctx, at.hour, at.minute, "Reminder: $text")
    }

    private fun calendar(ctx: Context, j: JSONObject): Res {
        val start = LocalDateTime.parse(j.getString("start"))
        val end = if (j.has("end")) LocalDateTime.parse(j.getString("end")) else start.plusHours(1)
        val z = ZoneId.systemDefault()
        go(ctx, Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, j.optString("title"))
            .putExtra(CalendarContract.Events.EVENT_LOCATION, j.optString("location"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.atZone(z).toInstant().toEpochMilli())
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end.atZone(z).toInstant().toEpochMilli()))
        return ok("Event is ready in your calendar. Tap Save to confirm.")
    }

    private fun maps(ctx: Context, dest: String, mode: String): Res {
        val m = when (mode) { "walk" -> "w"; "bike" -> "b"; else -> "d" }
        return try {
            go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=" + m))
                .setPackage("com.google.android.apps.maps"))
            ok("Navigation started.")
        } catch (e: Exception) {
            go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(dest))))
            ok("Opening directions.")
        }
    }

    private fun media(ctx: Context, cmd: String): Res {
        val code = when (cmd) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok("Done.")
    }

    private fun volume(ctx: Context, j: JSONObject): Res {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val target = if (j.has("level")) j.getInt("level") * max / 100 else cur + j.optInt("delta", 0) * max / 100
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target.coerceIn(0, max), AudioManager.FLAG_SHOW_UI)
        return ok("Volume changed.")
    }

    private fun brightness(ctx: Context, level: Int): Res {
        if (!Settings.System.canWrite(ctx)) {
            go(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return no("I need permission to change brightness. Allow it, then ask again.")
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (level * 255 / 100).coerceIn(1, 255))
        return ok("Brightness changed.")
    }

    private fun message(ctx: Context, app: String, to: String, text: String): Res {
        val number: String = if (to.none { it.isLetter() } && to.count { it.isDigit() } >= 5) to.filter { it.isDigit() || it == '+' }
        else {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                return no("Please grant contacts permission to EDITH.")
            Actions.lookup(ctx, to) ?: return no("I couldn't find $to in your contacts.")
        }
        if (app == "whatsapp") {
            val n = number.filter { it.isDigit() }
            val uri = Uri.parse("https://wa.me/$n?text=" + Uri.encode(text))
            try { go(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")) }
            catch (e: Exception) { go(ctx, Intent(Intent.ACTION_VIEW, uri)) }
        } else {
            go(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text))
        }
        return ok("Message drafted. Tap send to deliver it.")
    }

    private fun dnd(ctx: Context, on: Boolean): Res {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            go(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return no("I need Do Not Disturb access. Allow EDITH, then ask again.")
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        return ok(if (on) "Do Not Disturb on." else "Do Not Disturb off.")
    }

    private fun settings(ctx: Context, page: String): Res {
        val a = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        go(ctx, Intent(a))
        return ok("Opening settings.")
    }
}
