package com.edith.assistant

import android.Manifest
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.time.LocalDateTime
import java.util.Locale
import java.time.ZoneId

/** Executes the action tags the AI emits. Everything here only acts on the user's request. */
object Phone {
    data class Res(val ok: Boolean, val msg: String)
    private fun ok(m: String = "Done.") = Res(true, m)
    private fun no(m: String) = Res(false, m)
    private fun go(ctx: Context, i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    val screenTypes = setOf("observe", "tap", "type", "scroll", "global", "open", "submit", "screen")

    @Volatile private var lastApp = ""
    @Volatile private var lastAppAt = 0L
    fun noteApp(label: String) { lastApp = label; lastAppAt = System.currentTimeMillis() }

    /** The app the user is in (via screen access) or most recently opened through EDITH. */
    fun currentApp(): String {
        val fg = EdithAccessibilityService.instance?.foregroundApp()
        if (!fg.isNullOrBlank()) return fg
        return if (System.currentTimeMillis() - lastAppAt < 15 * 60_000L) lastApp else ""
    }

    fun appKey(label: String): String {
        val l = label.lowercase()
        return when {
            "youtube" in l -> "youtube"
            "spotify" in l -> "spotify"
            "comet" in l -> "comet"
            "maps" in l -> "maps"
            "play store" in l -> "playstore"
            "chrome" in l || l == "google" -> "google"
            "wikipedia" in l -> "wikipedia"
            "reddit" in l -> "reddit"
            "amazon" in l -> "amazon"
            else -> ""
        }
    }

    /** Reads the current screen as text; falls back to a screenshot description for image-only screens. */
    suspend fun screen(): Res {
        val s = EdithAccessibilityService.instance ?: return no("Turn on EDITH under Accessibility settings so I can read the screen.")
        val text = s.readScreen()
        if (text.length >= 60) return ok("Screen text:\n$text")
        val jpg = s.screenshotJpeg()
        if (jpg != null) {
            return try { ok("Screen description:\n" + Ai.vision("Describe everything readable or important on this screen.", jpg)) }
            catch (e: Exception) { no("I couldn't analyse the screenshot: ${e.message}") }
        }
        return if (text.isNotBlank()) ok("Screen text:\n$text")
        else no("I couldn't read anything on the screen. Open the page first, then call me with Hey EDITH or the assistant gesture.")
    }

    /** Searches inside an app using its own deep links, so nothing needs to be tapped. */
    fun inAppSearch(ctx: Context, key: String, q: String, play: Boolean = false): Res {
        val enc = Uri.encode(q)
        fun view(uri: String, pkg: String? = null): Boolean = try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            if (pkg != null) i.setPackage(pkg)
            go(ctx, i); true
        } catch (e: Exception) { false }
        when (key) {
            "youtube" -> {
                try {
                    go(ctx, Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q))
                    return ok("Searching YouTube for $q.")
                } catch (e: Exception) {}
                view("https://www.youtube.com/results?search_query=$enc")
                return ok("Searching YouTube for $q.")
            }
            "spotify" -> {
                if (play) {
                    try {
                        go(ctx, Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).setPackage("com.spotify.music")
                            .putExtra(android.app.SearchManager.QUERY, q))
                        return ok("Playing $q on Spotify.")
                    } catch (e: Exception) {}
                }
                if (!view("spotify:search:$enc")) view("https://open.spotify.com/search/$enc")
                return ok("Searching Spotify for $q.")
            }
            "comet" -> {
                val pkg = Actions.findApp(ctx, "comet")?.second ?: return no("I couldn't find Comet on this phone.")
                if (!view("https://www.perplexity.ai/search?q=$enc", pkg)) return no("Comet wouldn't open that search.")
                return ok("Searching Comet for $q.")
            }
            "maps" -> { if (!view("geo:0,0?q=$enc", "com.google.android.apps.maps")) view("https://www.google.com/maps/search/?api=1&query=$enc") }
            "playstore" -> { if (!view("market://search?q=$enc")) view("https://play.google.com/store/search?q=$enc") }
            "wikipedia" -> view("https://en.wikipedia.org/wiki/Special:Search?search=$enc")
            "reddit" -> view("https://www.reddit.com/search/?q=$enc")
            "amazon" -> view("https://www.amazon." + (if (Locale.getDefault().country == "IN") "in" else "com") + "/s?k=$enc")
            else -> view("https://www.google.com/search?q=$enc")
        }
        return ok("Searching for $q.")
    }

    fun observe(): String = EdithAccessibilityService.instance?.dump() ?: "Screen access is off."

    fun run(ctx: Context, j: JSONObject): Res = try { exec(ctx, j) } catch (e: Exception) { no("That didn't work: ${e.message}") }

    private fun exec(ctx: Context, j: JSONObject): Res {
        val type = j.optString("type")
        if (type in setOf("observe", "tap", "type", "scroll", "global", "submit")) {
            val s = EdithAccessibilityService.instance
            if (s == null) {
                go(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return no("Turn on EDITH under Accessibility settings, then ask again.")
            }
            return when (type) {
                "observe" -> ok(s.dump())
                "tap" -> s.tap(j.optInt("index", -1), j.optString("text")).let { Res(it == "Tapped.", it) }
                "type" -> s.type(j.optString("text"), j.optInt("index", -1)).let { Res(it == "Typed.", it) }
                "scroll" -> s.scroll(j.optString("dir", "down")).let { Res(it == "Scrolled.", it) }
                "submit" -> s.submit().let { Res(it == "Submitted." || it == "Tapped.", it) }
                else -> s.global(j.optString("cmd")).let { Res(it == "Done.", it) }
            }
        }
        return when (type) {
            "open" -> Actions.open(ctx, j.optString("app")).let { Res(it.startsWith("Opening"), it) }
            "camera_look" -> {
                val q = j.optString("prompt").ifBlank { Vision.DEFAULT }
                if (Vision.liveCamera) return ok("Looking.")
                if (Osint.liveActive) {
                    Vision.liveAsk = Vision.LiveAsk(q, System.nanoTime())
                    return ok("Looking.")
                }
                Vision.pendingPrompt = q
                go(ctx, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("camera", true))
                ok("Opening the camera.")
            }
            "call" -> Actions.call(ctx, j.optString("to"), j.optString("via", "phone").lowercase(), j.optBoolean("video", false))
                .let { Res(it.startsWith("Calling") || it.startsWith("Opening"), it) }
            "url" -> openUrl(ctx, j.optString("url"))
            "email" -> email(ctx, j)
            "share" -> share(ctx, j.optString("text"))
            "copy" -> copy(ctx, j.optString("text"))
            "flashlight" -> ok(Actions.handle(ctx, if (!j.has("on")) "toggle flashlight" else if (j.optBoolean("on")) "flashlight on" else "flashlight off") ?: "Done.")
            "app_search" -> inAppSearch(ctx, j.optString("app").lowercase(), j.optString("query"), j.optBoolean("play", false))
            "alarm" -> alarm(ctx, j.getInt("hour"), j.optInt("minute", 0), j.optString("label"), j.optJSONArray("days"))
            "timer" -> timer(ctx, j.getInt("seconds"), j.optString("label"))
            "reminder" -> reminder(ctx, j)
            "calendar" -> calendar(ctx, j)
            "maps" -> maps(ctx, j.getString("destination"), j.optString("mode", "drive"))
            "search" -> {
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(j.getString("query")))))
                ok("Searching.")
            }
            "camera" -> {
                go(ctx, Intent(if (j.optString("mode") == "video") MediaStore.INTENT_ACTION_VIDEO_CAMERA else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                ok("Camera open.")
            }
            "media" -> media(ctx, j.optString("cmd"))
            "volume" -> volume(ctx, j)
            "brightness" -> brightness(ctx, j.getInt("level"))
            "message" -> message(ctx, j.optString("app", "sms"), j.optString("to"), j.optString("text"))
            "dnd" -> dnd(ctx, j.optBoolean("on", true))
            "settings" -> settings(ctx, j.optString("page"))
            "profile" -> profile(j)
            else -> no("I don't know that action.")
        }
    }

    private fun alarm(ctx: Context, h: Int, m: Int, label: String, days: org.json.JSONArray? = null): Res {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h.coerceIn(0, 23)).putExtra(AlarmClock.EXTRA_MINUTES, m.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (days != null && days.length() > 0) {
            val d = ArrayList<Int>()
            for (k in 0 until days.length()) {
                val n = days.optString(k).lowercase().take(3)
                val c = when (n) {
                    "sun" -> java.util.Calendar.SUNDAY
                    "mon" -> java.util.Calendar.MONDAY
                    "tue" -> java.util.Calendar.TUESDAY
                    "wed" -> java.util.Calendar.WEDNESDAY
                    "thu" -> java.util.Calendar.THURSDAY
                    "fri" -> java.util.Calendar.FRIDAY
                    "sat" -> java.util.Calendar.SATURDAY
                    else -> -1
                }
                if (c > 0 && c !in d) d.add(c)
            }
            if (d.isNotEmpty()) i.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, d)
        }
        go(ctx, i)
        return ok("Alarm set for " + String.format(Locale.getDefault(), "%02d:%02d", h, m) + ".")
    }

    private fun timer(ctx: Context, sec: Int, label: String): Res {
        go(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec.coerceIn(1, 86400))
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return ok("Timer started.")
    }

    private fun millis(iso: String): Long =
        LocalDateTime.parse(iso).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun reminder(ctx: Context, j: JSONObject): Res {
        val at = LocalDateTime.parse(j.getString("at"))
        val text = j.optString("text", "Reminder")
        val ms = millis(j.getString("at"))
        if (ms - System.currentTimeMillis() > 24L * 3600 * 1000) {
            return calendar(ctx, JSONObject().put("title", text).put("start", j.getString("at"))
                .put("end", at.plusMinutes(15).toString()))
        }
        return alarm(ctx, at.hour, at.minute, "Reminder: $text")
    }

    private fun calendar(ctx: Context, j: JSONObject): Res {
        val start = LocalDateTime.parse(j.getString("start"))
        val end = if (j.has("end")) LocalDateTime.parse(j.getString("end")) else start.plusHours(1)
        val z = ZoneId.systemDefault()
        go(ctx, Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, j.optString("title"))
            .putExtra(CalendarContract.Events.EVENT_LOCATION, j.optString("location"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.atZone(z).toInstant().toEpochMilli())
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end.atZone(z).toInstant().toEpochMilli()))
        return ok("Event is ready in your calendar. Tap Save to confirm.")
    }

    private fun maps(ctx: Context, dest: String, mode: String): Res {
        val m = when (mode) { "walk" -> "w"; "bike" -> "b"; else -> "d" }
        return try {
            go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=" + m))
                .setPackage("com.google.android.apps.maps"))
            ok("Navigation started.")
        } catch (e: Exception) {
            go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(dest))))
            ok("Opening directions.")
        }
    }

    private fun media(ctx: Context, cmd: String): Res {
        val code = when (cmd) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ok("Done.")
    }

    private fun volume(ctx: Context, j: JSONObject): Res {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val target = if (j.has("level")) j.getInt("level") * max / 100 else cur + j.optInt("delta", 0) * max / 100
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target.coerceIn(0, max), AudioManager.FLAG_SHOW_UI)
        return ok("Volume changed.")
    }

    private fun brightness(ctx: Context, level: Int): Res {
        if (!Settings.System.canWrite(ctx)) {
            go(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return no("I need permission to change brightness. Allow it, then ask again.")
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (level * 255 / 100).coerceIn(1, 255))
        return ok("Brightness changed.")
    }

    private fun message(ctx: Context, app: String, to: String, text: String): Res {
        val w = Contacts.who(ctx, to)
        if (w.error != null) return no(w.error)
        val number = w.number
        if (app.lowercase().contains("whats")) {
            val n = number.filter { it.isDigit() }
            val uri = Uri.parse("https://wa.me/$n?text=" + Uri.encode(text))
            try { go(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")) }
            catch (e: Exception) { go(ctx, Intent(Intent.ACTION_VIEW, uri)) }
        } else {
            go(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text))
        }
        return ok("Message to ${w.name} is drafted. Tap send to deliver it.")
    }

    private fun openUrl(ctx: Context, url: String): Res {
        val u = url.trim().let { if (it.startsWith("http://") || it.startsWith("https://")) it else "https://$it" }
        if (u.length < 9 || !u.contains('.')) return no("That doesn't look like a web address.")
        go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        return ok("Opening the link.")
    }

    private fun email(ctx: Context, j: JSONObject): Res {
        val to = j.optString("to").trim()
        val address: String
        var who = to
        if (to.contains('@')) address = to else if (to.isEmpty()) address = "" else {
            val w = Contacts.who(ctx, to)
            if (w.error != null) return no(w.error)
            who = w.name
            address = Contacts.email(ctx, w.id) ?: return no("${w.name} has no email address saved.")
        }
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_SUBJECT, j.optString("subject"))
            .putExtra(Intent.EXTRA_TEXT, j.optString("body"))
        if (address.isNotEmpty()) i.putExtra(Intent.EXTRA_EMAIL, arrayOf(address))
        go(ctx, i)
        return ok(if (who.isEmpty()) "Email drafted. Tap send to deliver it." else "Email to $who is drafted. Tap send to deliver it.")
    }

    private fun share(ctx: Context, text: String): Res {
        if (text.isBlank()) return no("There's nothing to share.")
        go(ctx, Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share with"))
        return ok("Choose where to share it.")
    }

    private fun copy(ctx: Context, text: String): Res {
        if (text.isBlank()) return no("There's nothing to copy.")
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("EDITH", text))
        return ok("Copied.")
    }

    private fun dnd(ctx: Context, on: Boolean): Res {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            go(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return no("I need Do Not Disturb access. Allow EDITH, then ask again.")
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        return ok(if (on) "Do Not Disturb on." else "Do Not Disturb off.")
    }

    /** Profile card for a well-known public figure: official handles (from the AI) turned into links. */
    private fun profile(j: JSONObject): Res {
        val name = j.optString("name").trim()
        if (name.isEmpty()) return no("Which public figure do you mean?")
        val links = mutableListOf<Osint.ProfileLink>()
        links.add(Osint.ProfileLink("Wikipedia", "https://en.wikipedia.org/wiki/Special:Search?search=" + Uri.encode(name)))
        links.add(Osint.ProfileLink("Latest news", "https://www.google.com/search?tbm=nws&q=" + Uri.encode(name)))
        val arr = j.optJSONArray("accounts")
        if (arr != null) {
            for (i in 0 until minOf(arr.length(), 10)) {
                val a = arr.getJSONObject(i)
                val site = a.optString("site").lowercase()
                val h = a.optString("handle").trim().removePrefix("@")
                if (!Regex("^[A-Za-z0-9._-]{1,50}$").matches(h)) continue
                val url = when (site) {
                    "instagram" -> "https://www.instagram.com/$h"
                    "x", "twitter" -> "https://x.com/$h"
                    "youtube" -> "https://www.youtube.com/@$h"
                    "facebook" -> "https://www.facebook.com/$h"
                    "tiktok" -> "https://www.tiktok.com/@$h"
                    "threads" -> "https://www.threads.net/@$h"
                    "github" -> "https://github.com/$h"
                    "twitch" -> "https://www.twitch.tv/$h"
                    "reddit" -> "https://www.reddit.com/user/$h"
                    "linkedin" -> "https://www.linkedin.com/in/$h"
                    else -> null
                } ?: continue
                links.add(Osint.ProfileLink(site.replaceFirstChar { it.uppercase() }, url))
            }
        }
        Osint.card = Osint.Card(name, links)
        return ok("Showing public profiles for $name.")
    }

    private fun settings(ctx: Context, page: String): Res {
        val a = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            "internet", "mobile data" -> if (android.os.Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val i = Intent(a)
        if (page == "notifications") i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        go(ctx, i)
        return ok("Opening settings.")
    }
}
