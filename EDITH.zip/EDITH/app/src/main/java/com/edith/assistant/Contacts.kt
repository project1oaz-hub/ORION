package com.edith.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import kotlin.math.max
import kotlin.math.min

/** Forgiving text matching, so "whatsap", "instagrm" or "Rahool" still find the right app or contact. */
object Fuzzy {
    fun norm(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun words(s: String): List<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }

    fun dist(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun sim(a: String, b: String): Float {
        val m = max(a.length, b.length)
        return if (m == 0) 1f else 1f - dist(a, b).toFloat() / m
    }

    /** Rough "sounds like" key: first letter plus the consonants, repeats collapsed. */
    private fun sound(s: String): String {
        if (s.isEmpty()) return ""
        val t = s.replace("ph", "f").replace("ck", "k").replace("q", "k").replace("x", "ks")
        val sb = StringBuilder().append(t[0])
        for (i in 1 until t.length) {
            val ch = t[i]
            if (ch in "aeiouyhw") continue
            if (sb.last() != ch) sb.append(ch)
        }
        return sb.toString()
    }

    /** 0..1: how well [cand] (a contact or app name) matches what the user said, [query]. */
    fun score(query: String, cand: String): Float {
        val q = norm(query)
        val c = norm(cand)
        if (q.isEmpty() || c.isEmpty()) return 0f
        if (q == c) return 1f
        val ws = words(cand)
        if (ws.any { it == q }) return 0.93f
        if (c.startsWith(q) && q.length >= 2) return 0.9f
        if (ws.any { it.startsWith(q) } && q.length >= 2) return 0.86f
        if (q.startsWith(c) && c.length >= 3) return 0.8f
        if (q.length >= 3 && c.contains(q)) return 0.76f
        var best = sim(q, c) * 0.88f
        for (w in ws) best = max(best, sim(q, w) * 0.88f)
        val sq = sound(q)
        if (sq.length >= 3 && (sound(c) == sq || ws.any { sound(it) == sq })) best = max(best, 0.72f)
        return best
    }
}

object Contacts {
    class Entry(val id: Long, val name: String, val number: String, val type: Int, val primary: Boolean, val starred: Boolean)

    /** Result of resolving "mom" / "Rahul" / "+91..." to one number. [error] is set when it can't be done. */
    class Who(val name: String, val number: String, val id: Long, val error: String?)

    private var cache: List<Entry> = emptyList()
    private var cachedAt = 0L

    private val KIN = listOf(
        setOf("mom", "mother", "mummy", "mommy", "mama", "maa", "amma", "mum", "mumma", "mam"),
        setOf("dad", "father", "papa", "pappa", "daddy", "abba", "appa", "baba", "pa"),
        setOf("brother", "bro", "bhai", "bhaiya", "anna"),
        setOf("sister", "sis", "didi", "behen", "akka"),
        setOf("wife", "wifey", "biwi"),
        setOf("husband", "hubby", "hubs"),
        setOf("grandma", "granny", "nani", "dadi", "grandmother"),
        setOf("grandpa", "grandfather", "nana", "dada", "grandad")
    )

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun all(ctx: Context): List<Entry> {
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - cachedAt < 60_000L) return cache
        val out = ArrayList<Entry>()
        val k = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val c = ctx.contentResolver.query(
            k,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY,
                ContactsContract.CommonDataKinds.Phone.STARRED
            ), null, null, null
        ) ?: return cache
        c.use {
            while (it.moveToNext() && out.size < 6000) {
                val num = it.getString(2) ?: continue
                out.add(Entry(it.getLong(0), it.getString(1) ?: "", num, it.getInt(3), it.getInt(4) != 0, it.getInt(5) != 0))
            }
        }
        cache = out
        cachedAt = now
        return out
    }

    private fun alternatives(query: String): List<String> {
        val q = Fuzzy.norm(query.removeSuffix("'s").removeSuffix("\u2019s"))
        for (g in KIN) if (q in g) return g.toList()
        return listOf(query)
    }

    private fun cleanNumber(n: String) = n.filter { it.isDigit() || it == '+' }

    private fun bestNumber(list: List<Entry>): Entry =
        list.firstOrNull { it.primary }
            ?: list.firstOrNull { it.type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE }
            ?: list.first()

    /** Resolves a spoken name or number to a single phone number. */
    fun who(ctx: Context, raw: String): Who {
        val n = raw.trim().trim('.', ',', '!', '?')
        if (n.isEmpty()) return Who("", "", -1, "Who should I contact?")
        if (n.none { it.isLetter() } && n.count { it.isDigit() } >= 5) {
            val num = cleanNumber(n)
            return Who(num, num, -1, null)
        }
        if (!hasPermission(ctx)) return Who(n, "", -1, "Please grant contacts permission to EDITH.")
        val entries = all(ctx)
        val alts = alternatives(n)
        val byContact = entries.groupBy { it.id }
        // best score per contact
        val scored = ArrayList<Pair<Float, Long>>()
        for ((id, list) in byContact) {
            val name = list.first().name
            var s = 0f
            for (a in alts) s = max(s, Fuzzy.score(a, name))
            if (s >= 0.7f) scored.add(s to id)
        }
        if (scored.isEmpty()) return Who(n, "", -1, "I couldn't find $n in your contacts.")
        scored.sortByDescending { it.first }
        val top = scored[0].first
        var tied = scored.filter { it.first >= top - 0.04f }
        if (tied.size > 1) {
            val fav = tied.filter { byContact[it.second]!!.first().starred }
            if (fav.size == 1) tied = fav
        }
        if (tied.size > 1) {
            val names = tied.take(4).map { byContact[it.second]!!.first().name }.distinct()
            if (names.size > 1) {
                val list = names.dropLast(1).joinToString(", ") + " or " + names.last()
                return Who(n, "", -1, "I found several contacts matching $n: $list. Which one do you mean?")
            }
        }
        val list = byContact[tied[0].second]!!
        val e = bestNumber(list)
        return Who(e.name, cleanNumber(e.number), e.id, null)
    }

    /** All numbers and the email of the best-matching contact, for "what's Mom's number". */
    fun describe(ctx: Context, name: String): String {
        val w = who(ctx, name)
        if (w.error != null) return w.error
        val nums = all(ctx).filter { it.id == w.id }.map { cleanNumber(it.number) }.distinct()
        val mail = email(ctx, w.id)
        return "${w.name}: " + nums.joinToString(", ") + (if (mail != null) "; email $mail" else "")
    }

    fun email(ctx: Context, contactId: Long): String? {
        if (contactId < 0 || !hasPermission(ctx)) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS),
            "${ContactsContract.CommonDataKinds.Email.CONTACT_ID}=?", arrayOf(contactId.toString()), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    /** Starts a WhatsApp voice or video call to a contact that has WhatsApp. False if it isn't possible. */
    fun whatsappCall(ctx: Context, contactId: Long, video: Boolean): Boolean {
        if (contactId < 0 || !hasPermission(ctx)) return false
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call" else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        val c = ctx.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID),
            "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.Data.CONTACT_ID}=?",
            arrayOf(mime, contactId.toString()), null
        ) ?: return false
        val dataId = c.use { if (it.moveToFirst()) it.getLong(0) else -1L }
        if (dataId < 0) return false
        return try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse("content://com.android.contacts/data/$dataId"), mime)
                    .setPackage("com.whatsapp")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: Exception) { false }
    }
}
