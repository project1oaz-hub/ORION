package com.edith.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/** Makes EDITH selectable as the phone's default digital assistant. */
class EdithVoiceService : VoiceInteractionService()

class EdithSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = EdithSession(this)
}

/** Power-button / corner-swipe / "assistant" gesture opens EDITH straight into Live. */
class EdithSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(context, MainActivity::class.java).putExtra("live", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startAssistantActivity(i) } catch (e: Exception) {
            try { context.startActivity(i) } catch (e2: Exception) {}
        }
        hide()
    }
}

object Recognizers {
    /** The real speech recognizer on the phone (never EDITH's own stand-in). */
    fun find(ctx: Context): ComponentName? {
        val list = ctx.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            .map { it.serviceInfo }.filter { it.packageName != ctx.packageName }
        val pick = list.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" }
            ?: list.firstOrNull() ?: return null
        return ComponentName(pick.packageName, pick.name)
    }
}

/**
 * Android makes the default assistant's recognition service the system recognizer, so this one
 * forwards everything to the phone's real recognizer. Other apps' voice typing keeps working.
 */
class EdithRecognitionService : RecognitionService() {
    private val main = Handler(Looper.getMainLooper())
    private var inner: SpeechRecognizer? = null

    override fun onStartListening(intent: Intent, cb: Callback) {
        main.post {
            val comp = Recognizers.find(this)
            if (comp == null) { cb.error(SpeechRecognizer.ERROR_CLIENT); return@post }
            val r = SpeechRecognizer.createSpeechRecognizer(this, comp)
            inner = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(b: Bundle?) { cb.readyForSpeech(b ?: Bundle()) }
                override fun onBeginningOfSpeech() { cb.beginningOfSpeech() }
                override fun onRmsChanged(v: Float) { cb.rmsChanged(v) }
                override fun onBufferReceived(b: ByteArray?) { if (b != null) cb.bufferReceived(b) }
                override fun onEndOfSpeech() { cb.endOfSpeech() }
                override fun onError(e: Int) { cb.error(e) }
                override fun onResults(b: Bundle?) { cb.results(b ?: Bundle()) }
                override fun onPartialResults(b: Bundle?) { cb.partialResults(b ?: Bundle()) }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(intent)
        }
    }

    override fun onStopListening(cb: Callback) { main.post { inner?.stopListening() } }

    override fun onCancel(cb: Callback) {
        main.post { inner?.cancel(); inner?.destroy(); inner = null }
    }
}
