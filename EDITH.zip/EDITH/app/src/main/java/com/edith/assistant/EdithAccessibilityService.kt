package com.edith.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Gives EDITH hands: press, type, scroll, global buttons, and a readable list of what's on screen. */
class EdithAccessibilityService : AccessibilityService() {
    companion object { var instance: EdithAccessibilityService? = null }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    fun global(cmd: String): String {
        val a = when (cmd) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quicksettings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> return "Unknown button."
        }
        return if (performGlobalAction(a)) "Done." else "That didn't work on this phone."
    }

    fun dump(): String {
        val root = rootInActiveWindow ?: return "No screen content available."
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        walk(root, list, sb)
        nodes = list
        return if (sb.isEmpty()) "The screen has no readable content." else sb.toString().take(4000)
    }

    private fun walk(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (out.size >= 80) return
        val t = (n.text ?: n.contentDescription)?.toString()
        if ((!t.isNullOrBlank() || n.isClickable || n.isEditable) && n.isVisibleToUser) {
            sb.append("[").append(out.size).append("] ").append(t?.take(60) ?: "(no label)")
            if (n.isEditable) sb.append(" {input}") else if (n.isClickable) sb.append(" {tap}")
            sb.append('\n')
            out.add(n)
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, out, sb) }
    }

    fun tap(index: Int, text: String): String {
        var n: AccessibilityNodeInfo? = if (index >= 0) nodes.getOrNull(index) else null
        if (n == null && text.isNotBlank()) n = rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull()
        if (n == null) return "I couldn't find that on the screen."
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        return if ((c ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)) "Tapped." else "The tap didn't work."
    }

    fun type(text: String, index: Int): String {
        val n = (if (index >= 0) nodes.getOrNull(index) else null)
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return "No text field is selected."
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "Typed." else "I couldn't type there."
    }

    fun scroll(dir: String): String {
        val r = rootInActiveWindow ?: return "No screen content available."
        val n = findScrollable(r) ?: return "Nothing on screen can scroll."
        val a = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return if (n.performAction(a)) "Scrolled." else "I couldn't scroll."
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }
}
