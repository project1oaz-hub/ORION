package com.edith.assistant

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val BG = Color(0xFF131314)
val Panel = Color(0xFF1E1F20)
val Bubble = Color(0xFF282A2C)
val Muted = Color(0xFF8E918F)
val EdithFont = androidx.compose.ui.text.font.FontFamily.Serif // closest to Georgia on Android
object Theme {
    var accent by mutableStateOf(Color(0xFFA8C7FA))
    var fontScale by mutableStateOf(1f)
    var dots by mutableStateOf(true)
    fun load() { accent = Color(Prefs.accent); fontScale = Prefs.fontScale; dots = Prefs.dots }
}
val Accent = Brush.linearGradient(listOf(Color(0xFF4285F4), Color(0xFF9B72CB), Color(0xFFD96570)))

@Composable
fun Grad(text: String, size: Int, weight: FontWeight = FontWeight.Bold) {
    Text(text, style = TextStyle(brush = Accent, fontSize = size.sp, fontWeight = weight))
}

@Composable
fun ChatScreen(voice: Voice, onSettings: () -> Unit, onLive: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var prov by remember { mutableStateOf(Prefs.provider) }
    val list = rememberLazyListState()
    val msgs = Assistant.history

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    fun send(t: String) {
        if (t.isBlank() || Assistant.busy) return
        input = ""
        scope.launch {
            val r = Assistant.respond(ctx, t.trim())
            if (Prefs.speak) voice.speak(r)
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("EDITH", color = Color(0xFFE3E3E3), fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp))
            Spacer(Modifier.weight(1f))
            Box {
                TextButton(onClick = { menu = true }) {
                    Text(if (prov == "groq") "Groq ▾" else "Gemini ▾", color = Theme.accent)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Gemini") }, onClick = { Prefs.provider = "gemini"; prov = "gemini"; menu = false })
                    DropdownMenuItem(text = { Text("Groq") }, onClick = { Prefs.provider = "groq"; prov = "groq"; menu = false })
                }
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Muted) }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                Column(Modifier.padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Spacer(Modifier.height(24.dp))
                    Grad("Hello" + if (Prefs.name.isBlank()) "" else ", ${Prefs.name}", 44, FontWeight.Medium)
                    Text("How can I help today?", color = Color(0xFF5F6368), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                LazyColumn(state = list, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(msgs) { m ->
                        if (m.role == "user") {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Surface(color = Bubble, shape = RoundedCornerShape(20.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                                    Text(m.text, color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                                }
                            }
                        } else {
                            Text(m.text, color = Color(0xFFE3E3E3), fontSize = 16.sp, lineHeight = 24.sp)
                        }
                    }
                    if (Assistant.busy) item { Grad("Thinking…", 16, FontWeight.Medium) }
                }
            }
        }

        Surface(shape = RoundedCornerShape(32.dp), color = Panel, modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text(if (listening) "Listening…" else "Ask EDITH", color = Muted) },
                    modifier = Modifier.weight(1f), maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Theme.accent
                    )
                )
                if (input.isNotBlank()) {
                    IconButton(onClick = { send(input) }) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Theme.accent) }
                } else {
                    IconButton(onClick = {
                        voice.stopSpeaking()
                        listening = true
                        WakeService.pause()
                        voice.listen { t ->
                            WakeService.resume()
                            listening = false
                            if (t != null) send(t) else Toast.makeText(ctx, Voice.errorText(voice.lastError), Toast.LENGTH_LONG).show()
                        }
                    }) { Icon(Icons.Default.Mic, "Speak", tint = if (listening) Color(0xFFD96570) else Theme.accent) }
                }
                IconButton(onClick = onLive, modifier = Modifier.padding(end = 2.dp).size(48.dp).clip(CircleShape).background(Theme.accent)) {
                    Icon(Icons.Default.GraphicEq, "Live", tint = Color(0xFF131314))
                }
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, lines: Int = 1, secret: Boolean = false, onChange: (String) -> Unit) {
    var v by remember { mutableStateOf(value) }
    OutlinedTextField(
        value = v, onValueChange = { v = it; onChange(it) }, label = { Text(label) },
        singleLine = lines == 1, minLines = lines, maxLines = if (lines == 1) 1 else 8,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedBorderColor = Theme.accent, unfocusedBorderColor = Color(0xFF444746),
            focusedLabelColor = Theme.accent, unfocusedLabelColor = Muted
        )
    )
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var found by remember { mutableStateOf<List<String>>(emptyList()) }
    var modelMsg by remember { mutableStateOf("") }
    var rev by remember { mutableStateOf(0) }
    BackHandler(true) { onBack() }
    var prov by remember { mutableStateOf(Prefs.provider) }
    var wake by remember { mutableStateOf(Prefs.wake) }
    var speak by remember { mutableStateOf(Prefs.speak) }
    var rate by remember { mutableStateOf(Prefs.rate) }
    var style by remember { mutableStateOf(Prefs.style) }
    var persona by remember { mutableStateOf(Prefs.personality) }

    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Grad("Settings", 22)
        }
        Text("Accent colour", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(0xFFA8C7FA, 0xFFD0BCFF, 0xFFFFB1C8, 0xFF81C995, 0xFFFDD663, 0xFF7FD7DC).forEach { c ->
                val col = Color(c)
                Box(Modifier.size(40.dp).clip(CircleShape).background(col)
                    .border(if (Theme.accent == col) 3.dp else 0.dp, Color.White, CircleShape)
                    .clickable { Theme.accent = col; Prefs.accent = col.toArgb() })
            }
        }
        Text("Text size", color = Muted)
        Slider(value = Theme.fontScale, onValueChange = { Theme.fontScale = it; Prefs.fontScale = it }, valueRange = 0.85f..1.3f)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Interactive dot background", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = Theme.dots, onCheckedChange = { Theme.dots = it; Prefs.dots = it })
        }
        Text("Speaking speed", color = Muted)
        Slider(value = rate, onValueChange = { rate = it; Prefs.rate = it }, valueRange = 0.6f..1.6f)
        Text("Reply style", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("concise", "balanced", "detailed").forEach { s ->
                FilterChip(selected = style == s, onClick = { style = s; Prefs.style = s }, label = { Text(s.replaceFirstChar { it.uppercase() }) })
            }
        }
        Text("Personality", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("serious" to "Serious", "dry" to "Dry wit", "playful" to "Playful").forEach { (k, label) ->
                FilterChip(selected = persona == k, onClick = { persona = k; Prefs.personality = k }, label = { Text(label) })
            }
        }
        OutlinedButton(onClick = { Assistant.history.clear() }, modifier = Modifier.fillMaxWidth()) { Text("Clear current chat") }

        Text("Phone control", color = Muted)
        OutlinedButton(onClick = {
            try { ctx.startActivity(Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS)) }
            catch (e: Exception) { ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
        }, modifier = Modifier.fillMaxWidth()) { Text("Set EDITH as default assistant") }
        OutlinedButton(onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Enable full screen control (Accessibility)") }
        OutlinedButton(onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }, modifier = Modifier.fillMaxWidth()) { Text("Allow changing brightness") }
        OutlinedButton(onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Allow Do Not Disturb control") }
        Text("AI provider", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = prov == "gemini", onClick = { prov = "gemini"; Prefs.provider = "gemini" }, label = { Text("Gemini") })
            FilterChip(selected = prov == "groq", onClick = { prov = "groq"; Prefs.provider = "groq" }, label = { Text("Groq") })
        }
        key(rev) {
            Field("Gemini API key", Prefs.geminiKey, secret = true) { Prefs.geminiKey = it.trim() }
            Field("Gemini model", Prefs.geminiModel) { Prefs.geminiModel = it.trim() }
            Field("Groq API key", Prefs.groqKey, secret = true) { Prefs.groqKey = it.trim() }
            Field("Groq model", Prefs.groqModel) { Prefs.groqModel = it.trim() }
        }
        OutlinedButton(onClick = {
            scope.launch {
                modelMsg = "Checking…"
                try {
                    found = Ai.models(prov)
                    modelMsg = "${found.size} models available. Tap one to use it."
                } catch (e: Exception) { modelMsg = e.message ?: "Couldn't load models." }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Find available models") }
        if (modelMsg.isNotEmpty()) Text(modelMsg, color = Muted, fontSize = 13.sp)
        found.take(30).forEach { id ->
            Text(id, color = Theme.accent, modifier = Modifier.fillMaxWidth().clickable {
                if (prov == "groq") Prefs.groqModel = id else Prefs.geminiModel = id
                rev++
            }.padding(vertical = 10.dp))
        }

        Text("About you (EDITH uses this when relevant)", color = Muted)
        Field("Your name", Prefs.name) { Prefs.name = it }
        Field("Personal details (birthday, job, family, preferences, routines…)", Prefs.about, lines = 5) { Prefs.about = it }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Wake word “Hey EDITH”", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = wake, onCheckedChange = {
                wake = it; Prefs.wake = it
                if (it) {
                    if (!WakeService.start(ctx)) Toast.makeText(ctx, "Grant microphone permission first", Toast.LENGTH_LONG).show()
                } else WakeService.stop(ctx)
            })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Speak replies aloud", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = speak, onCheckedChange = { speak = it; Prefs.speak = it })
        }
        Button(onClick = {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }, modifier = Modifier.fillMaxWidth()) { Text("Allow “Display over other apps” (needed to open apps by voice)") }
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, modifier = Modifier.fillMaxWidth()) { Text("Disable battery optimization (keeps wake word alive)") }
        Spacer(Modifier.height(24.dp))
    }
}
