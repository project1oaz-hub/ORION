package com.edith.assistant

import android.content.Context
import org.vosk.Model
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the small offline Vosk speech model used for "Hey EDITH" and as the offline speech fallback. */
object ModelManager {
    private const val NAME = "vosk-model-small-en-us-0.15"
    @Volatile private var shared: Model? = null

    fun installed(ctx: Context): Boolean = File(File(ctx.filesDir, NAME), "am/final.mdl").exists()

    /** The loaded model, shared by the wake word and offline recognition. Null if it isn't installed (and [download] is false). */
    @Synchronized
    fun model(ctx: Context, download: Boolean): Model? {
        shared?.let { return it }
        val dir = if (installed(ctx)) File(ctx.filesDir, NAME) else if (download) ensure(ctx) else null
        if (dir == null) return null
        return try { Model(dir.absolutePath).also { shared = it } } catch (e: Throwable) { null }
    }

    fun ensure(ctx: Context): File? {
        val dir = File(ctx.filesDir, NAME)
        if (File(dir, "am/final.mdl").exists()) return dir
        val zip = File(ctx.cacheDir, "model.zip")
        return try {
            URL("https://alphacephei.com/vosk/models/$NAME.zip").openStream().use { i ->
                zip.outputStream().use { o -> i.copyTo(o) }
            }
            val root = ctx.filesDir.canonicalPath
            ZipInputStream(zip.inputStream().buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = File(ctx.filesDir, e.name)
                    if (!f.canonicalPath.startsWith(root)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { z.copyTo(it) }
                    }
                    e = z.nextEntry
                }
            }
            if (File(dir, "am/final.mdl").exists()) dir else null
        } catch (e: Exception) {
            // remove a half-downloaded model so the next try starts clean
            try { dir.deleteRecursively() } catch (x: Exception) {}
            null
        } finally {
            try { zip.delete() } catch (x: Exception) {}
        }
    }
}
