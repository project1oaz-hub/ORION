package com.edith.assistant

import android.content.Context
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the small offline Vosk speech model used ONLY for detecting "Hey EDITH". */
object ModelManager {
    private const val NAME = "vosk-model-small-en-us-0.15"

    fun ensure(ctx: Context): File? {
        val dir = File(ctx.filesDir, NAME)
        if (File(dir, "am/final.mdl").exists()) return dir
        return try {
            val zip = File(ctx.cacheDir, "model.zip")
            URL("https://alphacephei.com/vosk/models/$NAME.zip").openStream().use { i ->
                zip.outputStream().use { o -> i.copyTo(o) }
            }
            val root = ctx.filesDir.canonicalPath
            ZipInputStream(zip.inputStream().buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = File(ctx.filesDir, e.name)
                    if (!f.canonicalPath.startsWith(root)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { z.copyTo(it) }
                    }
                    e = z.nextEntry
                }
            }
            zip.delete()
            if (File(dir, "am/final.mdl").exists()) dir else null
        } catch (e: Exception) {
            null
        }
    }
}
