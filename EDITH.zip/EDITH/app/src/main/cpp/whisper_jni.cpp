#include <jni.h>
#include <string>
#include <vector>
#include "whisper.h"

/*
 * Thin JNI bridge to whisper.cpp (on-device, multilingual Whisper).
 * Kotlin side: com.edith.assistant.WhisperNative
 */

static whisper_full_params make_params(int threads, const std::string &lang, const std::string &prompt, int audio_ctx) {
    whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.n_threads = threads;
    p.language = lang.c_str();
    p.translate = false;
    p.detect_language = false;
    p.print_progress = false;
    p.print_realtime = false;
    p.print_timestamps = false;
    p.print_special = false;
    p.no_context = true;
    p.single_segment = false;
    p.suppress_blank = true;
    p.temperature = 0.0f;
    p.temperature_inc = 0.0f;   // no slow re-decoding passes
    p.no_speech_thold = 0.6f;
    p.audio_ctx = audio_ctx;    // shorter encoder window for short commands = much faster
    p.initial_prompt = prompt.empty() ? nullptr : prompt.c_str();
    p.greedy.best_of = 1;
    return p;
}

static bool run(whisper_context *ctx, const float *pcm, int n, int threads, const std::string &lang,
                const std::string &prompt, int audio_ctx, std::string &text, std::string &used) {
    whisper_full_params p = make_params(threads, lang, prompt, audio_ctx);
    if (whisper_full(ctx, p, pcm, n) != 0) return false;
    int id = whisper_full_lang_id(ctx);
    const char *ls = id >= 0 ? whisper_lang_str(id) : nullptr;
    used = ls ? ls : lang;
    text.clear();
    int segs = whisper_full_n_segments(ctx);
    for (int i = 0; i < segs; i++) {
        if (whisper_full_get_segment_no_speech_prob(ctx, i) > 0.7f) continue;
        const char *t = whisper_full_get_segment_text(ctx, i);
        if (t) { text += t; text += ' '; }
    }
    return true;
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_edith_assistant_WhisperNative_nInit(JNIEnv *env, jobject, jstring path) {
    const char *cp = env->GetStringUTFChars(path, nullptr);
    std::string p(cp ? cp : "");
    if (cp) env->ReleaseStringUTFChars(path, cp);
    whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    whisper_context *ctx = whisper_init_from_file_with_params(p.c_str(), cparams);
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_edith_assistant_WhisperNative_nFree(JNIEnv *, jobject, jlong handle) {
    auto *ctx = reinterpret_cast<whisper_context *>(handle);
    if (ctx) whisper_free(ctx);
}

/* Returns UTF-8 bytes: "<language>\n<text>", or null on failure. lang is "en", "ml" or "auto" (English/Malayalam only). */
JNIEXPORT jbyteArray JNICALL
Java_com_edith_assistant_WhisperNative_nRun(JNIEnv *env, jobject, jlong handle, jfloatArray pcm, jint threads,
                                            jstring jlang, jstring jprompt, jint audioCtx) {
    auto *ctx = reinterpret_cast<whisper_context *>(handle);
    if (!ctx) return nullptr;

    const char *l = env->GetStringUTFChars(jlang, nullptr);
    std::string lang(l ? l : "auto");
    if (l) env->ReleaseStringUTFChars(jlang, l);
    const char *pr = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(pr ? pr : "");
    if (pr) env->ReleaseStringUTFChars(jprompt, pr);

    jsize n = env->GetArrayLength(pcm);
    std::vector<float> samples(n);
    env->GetFloatArrayRegion(pcm, 0, n, samples.data());

    std::string text, used;
    bool ok = run(ctx, samples.data(), (int) n, threads, lang, prompt, audioCtx, text, used);

    // Auto mode only accepts English or Malayalam. If Whisper guessed something else, pick the likelier of the two.
    if (ok && lang == "auto" && used != "en" && used != "ml") {
        std::string pick = "en";
        std::vector<float> probs(whisper_lang_max_id() + 1, 0.0f);
        if (whisper_pcm_to_mel(ctx, samples.data(), (int) n, threads) == 0 &&
            whisper_lang_auto_detect(ctx, 0, threads, probs.data()) >= 0) {
            int en = whisper_lang_id("en"), ml = whisper_lang_id("ml");
            if (en >= 0 && ml >= 0 && probs[ml] > probs[en]) pick = "ml";
        }
        std::string p2 = pick == "en" ? prompt : std::string();
        ok = run(ctx, samples.data(), (int) n, threads, pick, p2, audioCtx, text, used);
    }
    if (!ok) return nullptr;

    std::string out = used + "\n" + text;
    jbyteArray arr = env->NewByteArray((jsize) out.size());
    env->SetByteArrayRegion(arr, 0, (jsize) out.size(), reinterpret_cast<const jbyte *>(out.data()));
    return arr;
}

}
